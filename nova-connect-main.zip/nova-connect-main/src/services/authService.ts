
import { supabase } from '@/lib/supabase-client';
import { User, UserRole } from '@/types/user';
import { authSignIn, authSignOut, authSignUp } from '@/services/auth';
import { ProfileResponse } from '@/mocks/profiles/types';

/**
 * Export authentication methods from the appropriate service
 */
export { 
  authSignIn,
  authSignOut,
  authSignUp
};

/**
 * Fetch a user's profile from Supabase
 */
export const fetchUserProfile = async (userId: string, ignoreErrors = false): Promise<ProfileResponse['data'] | null> => {
  try {
    console.log(`Fetching profile for user with ID: ${userId}`);
    
    // Special handling for skyguard_user_id - try to get by email first
    if (userId === 'skyguard_user_id' || userId === 'craftsman_user_id') {
      console.log("Special ID detected, attempting to fetch by email");
      
      const { data: profileByEmail, error: emailError } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', 'skyguard.couv@gmail.com')
        .maybeSingle();
      
      if (profileByEmail) {
        console.log("Found profile by email:", profileByEmail);
        return {
          id: profileByEmail.id,
          email: profileByEmail.email,
          role: profileByEmail.role as UserRole,
          first_name: profileByEmail.first_name || '',
          last_name: profileByEmail.last_name || '',
          created_at: profileByEmail.created_at,
          // Include other properties as needed
          address: profileByEmail.address || '',
          avatar_url: profileByEmail.avatar_url || '',
          bio: profileByEmail.bio || '',
          city: profileByEmail.city || '',
          postal_code: profileByEmail.postal_code || '',
          phone_number: profileByEmail.phone_number || '',
          rating: profileByEmail.rating || 0,
          completed_projects: profileByEmail.completed_projects || 0,
          updated_at: profileByEmail.updated_at || profileByEmail.created_at
        };
      } else {
        console.log("No profile found by email, error:", emailError);
      }
    }
    
    // Normal profile fetch by user ID
    const { data: profiles, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();
    
    if (error && !ignoreErrors) {
      throw error;
    }
    
    if (!profiles) {
      console.log("No profile found for user ID:", userId);
      return null;
    }
    
    console.log("Profile found:", profiles);
    
    return {
      id: profiles.id,
      email: profiles.email,
      role: profiles.role as UserRole,
      first_name: profiles.first_name || '',
      last_name: profiles.last_name || '',
      created_at: profiles.created_at,
      // Include other properties
      address: profiles.address || '',
      avatar_url: profiles.avatar_url || '',
      bio: profiles.bio || '',
      city: profiles.city || '',
      postal_code: profiles.postal_code || '',
      phone_number: profiles.phone_number || '',
      rating: profiles.rating || 0,
      completed_projects: profiles.completed_projects || 0,
      updated_at: profiles.updated_at || profiles.created_at
    };
  } catch (error) {
    if (!ignoreErrors) {
      console.error("Error fetching user profile:", error);
      throw error;
    }
    console.warn("Error fetching user profile (ignored):", error);
    return null;
  }
};

/**
 * Update a user's role in Supabase
 */
export const updateUserRole = async (userId: string, newRole: UserRole, currentUserRole: UserRole): Promise<any> => {
  try {
    console.log(`Updating user ${userId} role to ${newRole}`);
    
    // Only admins can update roles
    if (currentUserRole !== 'admin') {
      throw new Error('Only administrators can update user roles');
    }
    
    // Try to use RPC first (more secure)
    try {
      const { data, error } = await supabase.rpc('admin_update_user_role', {
        p_user_id: userId,
        p_role: newRole
      });
      
      if (error) {
        console.error("Error using RPC to update role:", error);
        throw error;
      }
      
      console.log("Role updated successfully via RPC:", data);
      return data;
    } catch (rpcError) {
      console.error("RPC error, falling back to direct update:", rpcError);
      
      // Fallback: Direct update
      const { data, error } = await supabase
        .from('profiles')
        .update({ role: newRole })
        .eq('id', userId);
      
      if (error) {
        throw error;
      }
      
      return data;
    }
  } catch (error) {
    console.error("Error updating user role:", error);
    throw error;
  }
};
