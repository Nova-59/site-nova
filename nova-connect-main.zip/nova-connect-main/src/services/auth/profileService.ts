
import { supabase } from '@/lib/supabase-client';
import { UserRole } from '@/types/user';
import { checkSupabaseInitialization } from './utils';
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL } from './constants';

/**
 * Creates a user profile in Supabase
 */
export const createUserProfile = async (userId: string, email: string, role: UserRole) => {
  try {
    let safeRole: UserRole = role;
    
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      safeRole = 'admin';
    } else if (email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
      safeRole = 'craftsman';
    }
    
    if (safeRole === 'guest') {
      safeRole = 'homeowner';
      console.log(`Remapping 'guest' role to 'homeowner' for user ${userId}`);
    }
    
    localStorage.setItem('tempUserRole_' + userId, JSON.stringify({
      role: safeRole,
      email: email
    }));
    console.log(`Rôle temporaire ${safeRole} stocké pour l'utilisateur ${userId}`);
    
    console.log(`Creating user profile with role: ${safeRole} in Supabase`);
    
    const { error } = await supabase
      .from('profiles')
      .insert({
        id: userId,
        email: email,
        role: safeRole,
        created_at: new Date().toISOString(),
      })
      .eq('id', userId);
      
    if (error) {
      console.error('Error creating profile in Supabase:', error);
      throw new Error(`Échec de création du profil dans Supabase: ${error.message}`);
    }
    
    console.log("Profil créé avec succès dans Supabase");
    return { error: null };
  } catch (error) {
    console.error('Error creating profile in Supabase:', error);
    throw error;
  }
};

/**
 * Fetches a user profile from Supabase
 */
export const fetchUserProfile = async (userId: string) => {
  try {
    console.log("Tentative prioritaire de récupération du profil utilisateur via Supabase");
    
    const isInitialized = await checkSupabaseInitialization();
    if (!isInitialized) {
      console.warn('Tentative de récupération du profil alors que Supabase n\'est pas initialisé');
      throw new Error('Supabase n\'est pas encore initialisé');
    }
    
    const { data: profileData, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
      
    if (error) {
      console.error('Error fetching profile from Supabase:', error);
      try {
        const localUser = localStorage.getItem('tempUserRole_' + userId);
        if (localUser) {
          const parsedUser = JSON.parse(localUser);
          console.log("Récupération du rôle temporaire stocké localement:", parsedUser.role);
          
          const tempProfile = {
            id: userId,
            role: parsedUser.role,
            email: parsedUser.email || '',
            created_at: new Date().toISOString()
          };
          
          try {
            console.log("Tentative de création du profil avec le rôle stocké:", parsedUser.role);
            await createUserProfile(userId, parsedUser.email || '', parsedUser.role);
          } catch (createError) {
            console.error("Erreur lors de la création du profil:", createError);
          }
          
          return tempProfile;
        }
      } catch (e) {
        console.error("Erreur lors de la récupération du rôle stocké localement:", e);
      }
      
      throw new Error(`Échec de récupération du profil Supabase: ${error.message}`);
    }
    
    if (profileData && profileData.role === 'guest') {
      try {
        const localUser = localStorage.getItem('tempUserRole_' + userId);
        if (localUser) {
          const parsedUser = JSON.parse(localUser);
          console.log("Profil trouvé avec rôle 'guest', mise à jour avec le rôle stocké:", parsedUser.role);
          
          const { error: updateError } = await supabase
            .from('profiles')
            .update({ role: parsedUser.role })
            .eq('id', userId);
            
          if (!updateError) {
            profileData.role = parsedUser.role;
            console.log("Profil mis à jour avec le rôle:", parsedUser.role);
            
            localStorage.removeItem('tempUserRole_' + userId);
          } else {
            console.error("Erreur lors de la mise à jour du rôle dans Supabase:", updateError);
          }
        }
      } catch (e) {
        console.error("Erreur lors de la mise à jour du rôle:", e);
      }
    }
    
    console.log("Succès: Profil récupéré depuis Supabase:", profileData);
    return profileData;
  } catch (error) {
    console.error('Error fetching profile from Supabase:', error);
    throw error;
  }
};
