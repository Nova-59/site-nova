
import { supabase, cleanAuthData } from '@/lib/supabase-client';
import { UserRole } from '@/types/user';
import { checkSupabaseInitialization, validateCredentials } from './utils';
import { createUserProfile } from './profileService';
import { ADMIN_EMAIL } from './constants';

/**
 * Handles user registration with Supabase
 */
export const authSignUp = async (email: string, password: string, role: UserRole) => {
  try {
    if (!email || !password) {
      return { 
        error: new Error("L'email et le mot de passe sont requis"), 
        user: null 
      };
    }
    
    const validation = validateCredentials(email, password, true);
    if (!validation.valid) {
      return { error: validation.error, user: null };
    }
    
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      console.error("Attempted to register using the admin email");
      return { 
        error: new Error("Cette adresse email n'est pas disponible pour l'inscription"), 
        user: null 
      };
    }
    
    cleanAuthData();
    
    const isInitialized = await checkSupabaseInitialization();
    if (!isInitialized) {
      console.error("Le service d'authentification n'est pas prêt pour l'inscription");
      return { 
        error: new Error("Le service d'authentification n'est pas encore prêt, veuillez réessayer"), 
        user: null 
      };
    }
    
    console.log("Tentative d'inscription avec Supabase:", email);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) {
      console.error("Supabase Auth Error:", error);
      
      if (error.message.includes('email already')) {
        return { error: new Error('Cette adresse email est déjà utilisée'), user: null };
      } else if (error.message.includes('invalid email')) {
        return { error: new Error('Format d\'email invalide'), user: null };
      } else if (error.message.includes('password')) {
        return { error: new Error('Le mot de passe ne respecte pas les critères de sécurité'), user: null };
      }
      
      return { error, user: null };
    }

    if (!data.user) {
      return { error: new Error('Utilisateur non créé ou vérifiez votre email pour confirmer'), user: null };
    }

    console.log("Inscription réussie avec Supabase:", data.user);
    
    try {
      await createUserProfile(data.user.id, email, role);
      console.log(`Profil utilisateur créé avec le rôle: ${role}`);
    } catch (profileError) {
      console.error("Erreur lors de la création du profil:", profileError);
    }
    
    return { error: null, user: data.user };
  } catch (error) {
    console.error('Signup error:', error);
    return { error: error as Error, user: null };
  }
};
