
import { supabase } from '@/lib/supabase-client';
import { UserRole } from '@/types/user';
import { checkSupabaseInitialization, delay } from './utils';

/**
 * Handles user role updates in Supabase
 */
export const updateUserRole = async (userId: string, newRole: UserRole, currentUserRole: UserRole) => {
  try {
    if (currentUserRole !== 'admin') {
      console.error("Tentative non autorisée de modification de rôle par un non-admin");
      throw new Error("Seuls les administrateurs peuvent modifier les rôles des utilisateurs");
    }
    
    if (newRole === 'guest') {
      newRole = 'homeowner';
      console.log(`Remapping requested 'guest' role to 'homeowner' for security`);
    }
    
    console.log(`Service: Tentative de mise à jour du rôle dans SUPABASE pour l'utilisateur ${userId} vers ${newRole}`);
    
    const isInitialized = await checkSupabaseInitialization();
    if (!isInitialized) {
      console.error("Supabase n'est pas initialisé pour la mise à jour du rôle");
      throw new Error("Le service de base de données n'est pas prêt");
    }
    
    let sessionObtained = false;
    let attempts = 0;
    let session = null;
    
    while (!sessionObtained && attempts < 3) {
      attempts++;
      console.log(`Tentative ${attempts}/3 d'obtention d'une session valide`);
      
      try {
        await delay(700 * attempts);
        
        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        
        if (sessionError) {
          console.error(`Erreur de session (tentative ${attempts}):`, sessionError);
          continue;
        }
        
        if (sessionData && sessionData.session) {
          console.log("Session valide obtenue:", !!sessionData.session.access_token);
          session = sessionData.session;
          sessionObtained = true;
          break;
        } else {
          console.warn(`Pas de session active (tentative ${attempts})`);
          
          try {
            const { data: refreshData, error: refreshError } = await supabase.auth.refreshSession();
            
            if (refreshError) {
              console.error("Erreur lors du rafraîchissement:", refreshError);
            } else if (refreshData.session) {
              console.log("Session rafraîchie avec succès");
              session = refreshData.session;
              sessionObtained = true;
              
              await delay(1000);
              break;
            }
          } catch (refreshEx) {
            console.error("Exception lors du rafraîchissement:", refreshEx);
          }
        }
      } catch (e) {
        console.error(`Exception lors de la vérification de session (tentative ${attempts}):`, e);
      }
    }
    
    if (!sessionObtained || !session) {
      console.error("Échec d'obtention d'une session après 3 tentatives");
      throw new Error("Session non disponible pour effectuer la mise à jour");
    }
    
    console.log("Session valide confirmée avec accessToken:", !!session.access_token);
    
    try {
      console.log("Tentative de mise à jour via RPC...");
      const { data: rpcData, error: rpcError } = await supabase
        .rpc('admin_update_user_role', { 
          p_user_id: userId, 
          p_role: newRole 
        });
        
      if (!rpcError) {
        console.log("Mise à jour réussie via RPC");
        
        try {
          const currentUserStr = localStorage.getItem('currentUser');
          if (currentUserStr) {
            const currentUser = JSON.parse(currentUserStr);
            if (currentUser.id === userId) {
              currentUser.role = newRole;
              localStorage.setItem('currentUser', JSON.stringify(currentUser));
              console.log("LocalStorage également mis à jour pour l'utilisateur courant");
            }
          }
        } catch (localError) {
          console.warn("Échec de mise à jour du localStorage, mais la mise à jour Supabase a réussi", localError);
        }
        
        return { error: null };
      }
      
      console.warn("RPC failed, falling back to direct update:", rpcError);
    } catch (rpcException) {
      console.warn("RPC exception, falling back to direct update:", rpcException);
    }
    
    await delay(500);
    
    const { data, error } = await supabase
      .from('profiles')
      .update({ 
        role: newRole, 
        updated_at: new Date().toISOString() 
      })
      .eq('id', userId);
    
    if (error) {
      console.error('Erreur lors de la mise à jour du rôle dans Supabase:', error);
      throw new Error(`Échec de mise à jour du rôle dans Supabase: ${error.message}`);
    }
    
    console.log(`Rôle mis à jour avec succès dans Supabase vers ${newRole}`, data);
    
    try {
      const currentUserStr = localStorage.getItem('currentUser');
      if (currentUserStr) {
        const currentUser = JSON.parse(currentUserStr);
        if (currentUser.id === userId) {
          currentUser.role = newRole;
          localStorage.setItem('currentUser', JSON.stringify(currentUser));
          console.log("LocalStorage également mis à jour pour l'utilisateur courant");
        }
      }
    } catch (localError) {
      console.warn("Échec de mise à jour du localStorage, mais la mise à jour Supabase a réussi", localError);
    }
    
    return { error: null };
  } catch (error) {
    console.error('Erreur lors de la mise à jour du rôle:', error);
    throw error;
  }
};
