
import { supabase, cleanAuthData } from '@/lib/supabase-client';
import { delay } from './utils';

/**
 * Handles user logout from Supabase
 */
export const authSignOut = async () => {
  console.log("Tentative de déconnexion avec Supabase...");
  try {
    cleanAuthData();
    
    console.log("Appel à supabase.auth.signOut avec portée globale");
    const { error } = await supabase.auth.signOut({
      scope: 'global'
    });
    
    if (error) {
      console.error('Erreur de déconnexion Supabase:', error);
      throw new Error(`Échec de déconnexion: ${error.message}`);
    }
    
    const { data: sessionData } = await supabase.auth.getSession();
    console.log("Session après déconnexion:", sessionData);
    
    if (sessionData && sessionData.session) {
      console.warn("La session existe toujours après tentative de déconnexion. Nettoyage supplémentaire.");
      document.cookie = "sb-access-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      document.cookie = "sb-refresh-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      document.cookie = "supabase-auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      
      await supabase.auth.signOut({ scope: 'global' });
    }
    
    if (typeof window !== 'undefined') {
      console.log("Forçage du rafraîchissement de la page pour déconnexion complète");
      setTimeout(() => {
        window.location.href = '/auth';
      }, 300);
    }
    
    console.log("Déconnexion Supabase réussie");
    return { error: null };
  } catch (error) {
    console.error('Erreur de déconnexion:', error);
    if (typeof window !== 'undefined') {
      setTimeout(() => {
        window.location.href = '/auth';
      }, 300);
    }
    throw error;
  }
};
