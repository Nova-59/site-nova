
import { supabase, isSupabaseReady, cleanAuthData } from '@/lib/supabase-client';
import { ADMIN_EMAIL } from './constants';

/**
 * Checks if Supabase is initialized and ready to use
 */
export const checkSupabaseInitialization = async (): Promise<boolean> => {
  return await isSupabaseReady(1500);
};

/**
 * Helper function to wait for a specified duration
 */
export const delay = (ms: number): Promise<void> => {
  return new Promise(resolve => setTimeout(resolve, ms));
};

/**
 * Validate email and password format/requirements
 */
export const validateCredentials = (
  email: string, 
  password?: string, 
  isSignup = false
): { valid: boolean, error?: Error } => {
  if (!email) {
    return { 
      valid: false, 
      error: new Error("L'email est requis") 
    };
  }
  
  if (password && isSignup && password.length < 6) {
    return { 
      valid: false, 
      error: new Error("Le mot de passe doit contenir au moins 6 caractères") 
    };
  }
  
  if (isSignup && email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
    return { 
      valid: false, 
      error: new Error("Cette adresse email n'est pas disponible pour l'inscription") 
    };
  }
  
  return { valid: true };
};
