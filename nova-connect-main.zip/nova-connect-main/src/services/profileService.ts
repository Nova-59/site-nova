
import { UserProfile, UserProfileFormValues, User } from "@/types/user";
import { useAuth } from "@/contexts/AuthContext";

// Mock storage key
const PROFILES_STORAGE_KEY = "user_profiles";

// Get all profiles from localStorage
export const getAllProfiles = (): UserProfile[] => {
  const profilesJson = localStorage.getItem(PROFILES_STORAGE_KEY);
  return profilesJson ? JSON.parse(profilesJson) : [];
};

// Save all profiles to localStorage
const saveAllProfiles = (profiles: UserProfile[]): void => {
  localStorage.setItem(PROFILES_STORAGE_KEY, JSON.stringify(profiles));
};

// Get current user's profile
export const getCurrentUserProfile = (): UserProfile | null => {
  const currentUserJson = localStorage.getItem('currentUser');
  if (!currentUserJson) return null;
  
  const currentUser = JSON.parse(currentUserJson);
  const profiles = getAllProfiles();
  let userProfile = profiles.find(profile => profile.id === currentUser.id);
  
  if (!userProfile) {
    // Create a new profile for the user
    userProfile = {
      id: currentUser.id,
      email: currentUser.email,
      role: currentUser.role,
      createdAt: new Date(),
      firstName: currentUser.firstName || "",
      lastName: currentUser.lastName || "",
      phoneNumber: "",
      address: "",
      city: "",
      postalCode: "",
      bio: "",
      rating: 0,
      completedProjects: 0,
    };
    
    profiles.push(userProfile);
    saveAllProfiles(profiles);
  }
  
  return userProfile;
};

// Update user profile
export const updateUserProfile = async (
  profileData: UserProfileFormValues
): Promise<UserProfile> => {
  const currentUserJson = localStorage.getItem('currentUser');
  if (!currentUserJson) {
    throw new Error("User not logged in");
  }
  
  const currentUser = JSON.parse(currentUserJson);
  
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const profiles = getAllProfiles();
  const profileIndex = profiles.findIndex(p => p.id === currentUser.id);
  
  if (profileIndex >= 0) {
    // Update existing profile
    profiles[profileIndex] = {
      ...profiles[profileIndex],
      ...profileData,
      updatedAt: new Date()
    };
  } else {
    // Create new profile
    profiles.push({
      id: currentUser.id,
      email: currentUser.email,
      role: currentUser.role,
      ...profileData,
      createdAt: new Date(),
      updatedAt: new Date()
    });
  }
  
  saveAllProfiles(profiles);
  
  // Also update currentUser in localStorage
  const updatedUser = {
    ...currentUser,
    firstName: profileData.firstName,
    lastName: profileData.lastName
  };
  localStorage.setItem('currentUser', JSON.stringify(updatedUser));
  
  return getCurrentUserProfile() as UserProfile;
};

// Upload avatar
export const uploadAvatar = async (file: File): Promise<string> => {
  // In a real app, this would upload to a server or cloud storage
  // For now, we'll use a data URL
  
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = () => {
      const currentUserJson = localStorage.getItem('currentUser');
      if (!currentUserJson) {
        reject(new Error("User not logged in"));
        return;
      }
      
      const currentUser = JSON.parse(currentUserJson);
      const profiles = getAllProfiles();
      const profileIndex = profiles.findIndex(p => p.id === currentUser.id);
      
      if (profileIndex >= 0) {
        profiles[profileIndex].avatarUrl = reader.result as string;
        profiles[profileIndex].updatedAt = new Date();
      } else {
        profiles.push({
          id: currentUser.id,
          email: currentUser.email,
          role: currentUser.role,
          avatarUrl: reader.result as string,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
      
      saveAllProfiles(profiles);
      
      // Also update currentUser in localStorage
      currentUser.avatarUrl = reader.result as string;
      localStorage.setItem('currentUser', JSON.stringify(currentUser));
      
      resolve(reader.result as string);
    };
    
    reader.onerror = () => {
      reject(new Error("Failed to read file"));
    };
    
    reader.readAsDataURL(file);
  });
};
