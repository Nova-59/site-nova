
/**
 * Types pour la gestion des utilisateurs
 */

export type UserRole = 'homeowner' | 'craftsman' | 'admin' | 'estimator' | 'guest';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  firstName?: string;
  lastName?: string;
  createdAt: Date;
  updatedAt?: Date;
  phoneNumber?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  bio?: string;
  avatarUrl?: string;
  rating?: number;
  completedProjects?: number;
  name?: string; // Ajout de la propriété name manquante
}

// Type complet d'utilisateur avec toutes les informations de profil
export interface AppUser extends User {}

// Ajout des types manquants
export interface UserProfile {
  id: string;
  email: string;
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  bio?: string;
  avatarUrl?: string;
  createdAt: Date;
  updatedAt?: Date;
  role?: UserRole;
  rating?: number;
  completedProjects?: number;
}

// Type pour les valeurs de formulaire de profil utilisateur
export interface UserProfileFormValues {
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  address?: string;
  city?: string;
  postalCode?: string;
  bio?: string;
}
