
export type ProjectStatus = 
  | "pending" 
  | "verified" 
  | "assigned" 
  | "in_progress" 
  | "completed" 
  | "cancelled";

export type ProjectCategory = 
  | "plumbing" 
  | "electrical" 
  | "carpentry" 
  | "painting" 
  | "flooring" 
  | "roofing" 
  | "masonry" 
  | "landscaping" 
  | "renovation" 
  | "other";

export interface ProjectImage {
  id: string;
  url: string;
  alt: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  shortDescription: string;
  category: ProjectCategory;
  location: {
    city: string;
    postalCode: string;
    region: string;
  };
  budget: {
    min: number;
    max: number;
    currency: string;
  };
  images: ProjectImage[];
  status: ProjectStatus;
  createdAt: string;
  startDate: string | null;
  endDate: string | null;
  ownerId: string;
  estimatorId: string; // Maintenant obligatoire pour tous les projets publiés
  approvedById: string; // Administrateur qui a approuvé le projet
  approvedAt: string | null; // Date d'approbation
  craftsmanId?: string; // Optionnel car assigné après publication
  isPublished: boolean;
}
