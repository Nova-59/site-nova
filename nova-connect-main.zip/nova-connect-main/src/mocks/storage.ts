
// Mock pour les fonctionnalités de stockage
export const mockStorage = {
  from: (bucket: string) => ({
    upload: (path: string, file: File) => {
      console.log(`[Mock] Upload to ${bucket}/${path}`);
      return Promise.resolve({ 
        data: { path: `mock-url-for-${path}` }, 
        error: null 
      });
    },
    getPublicUrl: (path: string) => ({
      data: { publicUrl: `mock-public-url-for-${path}` }
    })
  })
};
