import { User, UserRole } from '@/types/user';
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL, CRAFTSMAN_PASSWORD } from '@/services/auth/constants';

// Admin and craftsman credentials for testing
export const ADMIN_PASSWORD = 'Emmamaury1905*';

// Define a common type for mock user objects to ensure consistency
interface MockUserData {
  id: string;
  email: string;
  role?: UserRole;
  created_at: string;
  first_name?: string;
  last_name?: string;
}

export const mockAuth = {
  signInWithPassword: ({ email, password }: { email: string; password: string }) => {
    console.log(`[Mock] Login attempt with ${email}`);
    
    // Special handling for admin account
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      if (password === ADMIN_PASSWORD || process.env.NODE_ENV !== 'production') {
        const adminUser: MockUserData = { 
          id: 'admin_user_id', 
          email: ADMIN_EMAIL, 
          created_at: new Date().toISOString(),
          first_name: 'Admin',
          last_name: 'User',
          role: 'admin'
        };
        
        localStorage.setItem('mockUser', JSON.stringify(adminUser));
        
        return Promise.resolve({ 
          data: { 
            user: adminUser, 
            session: { user: adminUser } 
          }, 
          error: null 
        });
      } else {
        return Promise.resolve({
          data: { user: null },
          error: { message: 'Mot de passe incorrect' }
        });
      }
    }
    
    // Check if email is the special craftsman email but respect the existing role
    if (email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
      let existingRole: UserRole = 'homeowner';
      
      try {
        // Check if there's a profile in localStorage
        const profiles = JSON.parse(localStorage.getItem('mockProfiles') || '[]');
        const userProfile = profiles.find((p: any) => 
          p.email && p.email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()
        );
        
        if (userProfile && userProfile.role) {
          existingRole = userProfile.role;
          console.log("[Mock] Found existing profile with role:", existingRole);
        }
      } catch (e) {
        console.error("[Mock] Error checking existing profile:", e);
      }
      
      // Accept any password in dev mode or the correct password
      if (password === CRAFTSMAN_PASSWORD || password === 'password123' || process.env.NODE_ENV !== 'production') {
        const craftsmanUser: MockUserData = { 
          id: 'skyguard_user_id', 
          email: CRAFTSMAN_EMAIL, 
          role: existingRole,
          first_name: 'SkyGuard',
          last_name: 'Couverture',
          created_at: new Date().toISOString() 
        };
        
        localStorage.setItem('mockUser', JSON.stringify(craftsmanUser));
        
        console.log("[Mock] Login successful for skyguard with role:", existingRole);
        
        return Promise.resolve({ 
          data: { 
            user: craftsmanUser, 
            session: { user: craftsmanUser } 
          }, 
          error: null 
        });
      } else {
        console.log("[Mock] Login failed - wrong password provided");
        return Promise.resolve({
          data: { user: null },
          error: { message: 'Mot de passe incorrect' }
        });
      }
    }
    
    // Create a unique user ID based on email to ensure consistency
    const userId = `user_${email.replace(/[^a-zA-Z0-9]/g, '_')}`;
    
    // Create mock user with the provided email
    const mockUser: MockUserData = { 
      id: userId, 
      email, 
      created_at: new Date().toISOString(),
      first_name: '',
      last_name: '',
      role: 'homeowner' // Default role
    };
    
    // Store the mock user in localStorage to maintain the session
    localStorage.setItem('mockUser', JSON.stringify(mockUser));
    
    return Promise.resolve({ 
      data: { 
        user: mockUser, 
        session: { user: mockUser } 
      }, 
      error: null 
    });
  },
  
  signUp: ({ email, password, options }: { email: string; password: string; options?: { data?: { role?: string } } }) => {
    console.log(`[Mock] Signup attempt with ${email}`);
    
    // Prevent registration with admin email
    if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      return Promise.resolve({
        data: { user: null },
        error: { message: 'Cette adresse email n\'est pas disponible pour l\'inscription' }
      });
    }
    
    // Create a unique user ID based on email
    const userId = `user_${email.replace(/[^a-zA-Z0-9]/g, '_')}`;
    
    // Get the role from options if provided
    const role = options?.data?.role || 'homeowner';
    
    const mockUser = { 
      id: userId, 
      email,
      role,
      created_at: new Date().toISOString() 
    };
    
    // Special case for skyguard
    if (email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
      mockUser.id = 'skyguard_user_id';
      mockUser.first_name = 'SkyGuard';
      mockUser.last_name = 'Couverture';
    }
    
    localStorage.setItem('mockUser', JSON.stringify(mockUser));
    
    // Store in mockProfiles as well
    try {
      const profiles = JSON.parse(localStorage.getItem('mockProfiles') || '[]');
      
      // Check if profile already exists
      const existingIndex = profiles.findIndex((p: any) => p.id === mockUser.id);
      
      if (existingIndex >= 0) {
        // Update existing profile
        profiles[existingIndex] = {
          ...profiles[existingIndex],
          role,
          updated_at: new Date().toISOString()
        };
      } else {
        // Add new profile
        profiles.push({
          id: mockUser.id,
          email: mockUser.email,
          role,
          first_name: mockUser.first_name || '',
          last_name: mockUser.last_name || '',
          created_at: mockUser.created_at,
          updated_at: new Date().toISOString()
        });
      }
      
      localStorage.setItem('mockProfiles', JSON.stringify(profiles));
    } catch (e) {
      console.error("[Mock] Error updating mockProfiles:", e);
    }
    
    return Promise.resolve({ 
      data: { 
        user: mockUser, 
        session: { user: mockUser } 
      }, 
      error: null 
    });
  },
  
  signOut: () => {
    console.log('[Mock] Logout');
    localStorage.removeItem('mockUser');
    localStorage.removeItem('currentUser');
    return Promise.resolve({ error: null });
  },
  
  getUser: () => {
    console.log('[Mock] Get user');
    const mockUser = localStorage.getItem('mockUser');
    if (mockUser) {
      return Promise.resolve({ 
        data: { user: JSON.parse(mockUser) }, 
        error: null 
      });
    }
    return Promise.resolve({ data: { user: null }, error: null });
  },
  
  getSession: () => {
    console.log('[Mock] Get session');
    const mockUser = localStorage.getItem('mockUser');
    if (mockUser) {
      const user = JSON.parse(mockUser);
      return Promise.resolve({
        data: {
          session: {
            user,
            expires_at: Math.floor(Date.now() / 1000) + 3600
          }
        },
        error: null
      });
    }
    return Promise.resolve({ data: { session: null }, error: null });
  },
  
  onAuthStateChange: (callback: any) => {
    console.log('[Mock] Auth state change configured');
    
    // Immediately call callback with current user
    const mockUser = localStorage.getItem('mockUser');
    if (mockUser) {
      const user = JSON.parse(mockUser);
      setTimeout(() => {
        callback('SIGNED_IN', { user });
      }, 0);
    }
    
    // Add event listener to detect storage changes for better auth sync
    window.addEventListener('storage', (event) => {
      if (event.key === 'mockUser' && event.newValue) {
        const user = JSON.parse(event.newValue);
        callback('SIGNED_IN', { user });
      } else if (event.key === 'mockUser' && !event.newValue) {
        callback('SIGNED_OUT', null);
      }
    });
    
    // Return a mock subscription
    return { data: { subscription: { unsubscribe: () => {} } } };
  }
};
