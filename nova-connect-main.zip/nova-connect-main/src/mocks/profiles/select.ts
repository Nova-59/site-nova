
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL } from './constants';
import { getStoredProfile } from './storage';
import { MockProfile, ProfileResponse } from './types';

export function mockSelect() {
  return {
    eq: (field: string, value: string) => ({
      single: (): Promise<ProfileResponse> => {
        const mockUser = localStorage.getItem('mockUser');
        if (!mockUser) {
          return Promise.resolve({ data: null, error: null });
        }
        
        const user = JSON.parse(mockUser);
        
        // Special handling for admin user
        if (user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
          return Promise.resolve({ 
            data: { 
              id: user.id, 
              email: user.email, 
              role: 'admin',
              first_name: user.first_name || '',
              last_name: user.last_name || '',
              created_at: user.created_at 
            }, 
            error: null 
          });
        }
        
        // Get stored profile if it exists for skyguard email
        if (user.email && user.email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
          // Check if there's a stored profile first
          const storedProfile = getStoredProfile(user.id);
          if (storedProfile) {
            console.log("Found stored profile for skyguard:", storedProfile);
            // Return the stored profile with its role
            return Promise.resolve({ data: storedProfile, error: null });
          }
          
          // Check localStorage for a stored role preference
          try {
            const profiles = JSON.parse(localStorage.getItem('mockProfiles') || '[]');
            const profileMatch = profiles.find((p: any) => 
              p.email && p.email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()
            );
            
            if (profileMatch) {
              console.log("Found profile in mockProfiles for skyguard:", profileMatch);
              return Promise.resolve({ data: profileMatch, error: null });
            }
          } catch (e) {
            console.error("Error checking mockProfiles:", e);
          }
          
          // If no stored profile, use homeowner as default role
          console.log("No stored profile found for skyguard, using homeowner role");
          return Promise.resolve({ 
            data: { 
              id: user.id, 
              email: user.email, 
              role: 'homeowner',
              first_name: 'SkyGuard',
              last_name: 'Couverture',
              created_at: user.created_at 
            }, 
            error: null 
          });
        }
        
        // Get stored profile if it exists
        const storedProfile = getStoredProfile(user.id);
        if (storedProfile) {
          return Promise.resolve({ data: storedProfile, error: null });
        }
        
        // Default profile for new users
        return Promise.resolve({ 
          data: { 
            id: user.id, 
            email: user.email, 
            role: 'homeowner', // Default role is homeowner
            first_name: user.first_name || '',
            last_name: user.last_name || '',
            created_at: user.created_at 
          }, 
          error: null 
        });
      },
      maybeSingle: function(): Promise<ProfileResponse> {
        // Reuse the single implementation
        return this.single();
      }
    })
  };
}
