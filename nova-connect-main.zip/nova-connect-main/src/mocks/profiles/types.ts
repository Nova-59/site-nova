
import { UserRole } from '@/types/user';

// Define interfaces for profile data structure
export interface MockProfile {
  id: string;
  email: string;
  role: UserRole | string; // Allow both UserRole enum and string to avoid type casting issues
  first_name: string;
  last_name: string;
  created_at: string;
  [key: string]: any; // For additional properties
}

export interface ProfileResponse {
  data: MockProfile | null;
  error: { message: string } | null;
}

export interface ProfilesResponse {
  data: MockProfile[];
  error: { message: string } | null;
}
