
import { ADMIN_EMAIL } from './constants';
import { getStoredProfiles, saveStoredProfiles } from './storage';
import { ProfileResponse } from './types';
import { UserRole } from '@/types/user';

export function mockUpsert(data: any): Promise<ProfileResponse> {
  console.log(`[Mock] Upsert profile:`, data);
  
  // Ensure admin role remains admin
  if (data.email && data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
    data.role = 'admin';
    console.log(`[Mock] Ensuring admin role for ${ADMIN_EMAIL}`);
  }
  
  // Ensure we never have users with 'guest' role
  if (data.role === 'guest') {
    data.role = 'homeowner';
    console.log(`[Mock] Converting 'guest' role to 'homeowner' for consistency`);
  }
  
  // Update or add profile
  const mockProfiles = getStoredProfiles();
  const profileIndex = mockProfiles.findIndex((p: any) => p.id === data.id);
  
  if (profileIndex >= 0) {
    mockProfiles[profileIndex] = { ...mockProfiles[profileIndex], ...data };
  } else {
    mockProfiles.push(data);
  }
  
  saveStoredProfiles(mockProfiles);
  
  // Update currentUser if needed
  const currentUser = localStorage.getItem('currentUser');
  if (currentUser) {
    const user = JSON.parse(currentUser);
    if (user.id === data.id) {
      user.role = data.role;
      localStorage.setItem('currentUser', JSON.stringify(user));
    }
  }
  
  return Promise.resolve({ data, error: null });
}
