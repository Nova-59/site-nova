
import { MockProfile } from './types';

// Get all profiles from localStorage
export const getStoredProfiles = (): MockProfile[] => {
  try {
    const profiles = localStorage.getItem('mockProfiles');
    return profiles ? JSON.parse(profiles) : [];
  } catch (e) {
    console.error('Error getting profiles from localStorage', e);
    return [];
  }
};

// Save all profiles to localStorage
export const saveStoredProfiles = (profiles: MockProfile[]) => {
  localStorage.setItem('mockProfiles', JSON.stringify(profiles));
};

// Get a specific profile by ID
export const getStoredProfile = (id: string): MockProfile | null => {
  const profiles = getStoredProfiles();
  return profiles.find(p => p.id === id) || null;
};

// Update a specific profile by ID
export const updateStoredProfile = (id: string, updatedProfile: MockProfile) => {
  const profiles = getStoredProfiles();
  const index = profiles.findIndex(p => p.id === id);
  
  if (index >= 0) {
    profiles[index] = { ...profiles[index], ...updatedProfile };
  } else {
    profiles.push(updatedProfile);
  }
  
  saveStoredProfiles(profiles);
};

// Add a new profile
export const addStoredProfile = (profile: MockProfile) => {
  const profiles = getStoredProfiles();
  profiles.push(profile);
  saveStoredProfiles(profiles);
};
