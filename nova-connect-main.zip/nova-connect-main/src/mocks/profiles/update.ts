
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL } from './constants';
import { getStoredProfile, updateStoredProfile } from './storage';
import { MockProfile, ProfileResponse } from './types';
import { UserRole } from '@/types/user';

export function mockUpdate(data: any) {
  return {
    eq: (field: string, value: string) => {
      return {
        select: () => {
          console.log(`[Mock] Update profile with ${field} = ${value}`, data);
          
          // Special handling for admin email
          if (data.email && data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
            console.log(`[Mock] Preserving admin role for ${ADMIN_EMAIL}`);
            data.role = 'admin';
          }
          
          // Special handling for craftsman email
          if (data.email && data.email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
            console.log(`[Mock] Preserving craftsman role for ${CRAFTSMAN_EMAIL}`);
            data.role = 'craftsman';
          }
          
          // Ensure role is a valid UserRole type
          let safeRole: UserRole = data.role as UserRole;
          
          // Verify the role is valid
          if (!['homeowner', 'craftsman', 'admin', 'estimator', 'guest'].includes(safeRole)) {
            console.warn(`[Mock] Invalid role ${safeRole}, defaulting to homeowner`);
            safeRole = 'homeowner';
          }
          
          // Only admins can set admin role
          const currentUser = localStorage.getItem('currentUser');
          let currentUserRole = 'guest';
          
          if (currentUser) {
            try {
              const parsedUser = JSON.parse(currentUser);
              currentUserRole = parsedUser.role;
            } catch (e) {
              console.error(`[Mock] Error parsing currentUser`, e);
            }
          }
          
          // Only allow admin to set admin role
          if (safeRole === 'admin' && currentUserRole !== 'admin') {
            console.log(`[Mock] Attempted to set admin role without admin privileges`);
            safeRole = 'homeowner';
          }
          
          // Create updated profile with safe role
          const updatedProfile = {
            id: value,
            email: data.email || '',
            role: safeRole, // Use the validated role of type UserRole
            first_name: data.first_name || '',
            last_name: data.last_name || '',
            phone_number: data.phone_number || '',
            address: data.address || '',
            city: data.city || '',
            postal_code: data.postal_code || '',
            bio: data.bio || '',
            avatar_url: data.avatar_url || '',
            rating: data.rating || 0,
            completed_projects: data.completed_projects || 0,
            created_at: data.created_at || new Date().toISOString(),
            updated_at: new Date().toISOString()
          };
          
          // Update profile in localStorage
          updateStoredProfile(value, updatedProfile);
          
          // If this is the current user, update currentUser in localStorage too
          if (currentUser && JSON.parse(currentUser).id === value) {
            const currentUserData = JSON.parse(currentUser);
            currentUserData.role = safeRole;
            localStorage.setItem('currentUser', JSON.stringify(currentUserData));
            console.log(`[Mock] Updated currentUser role to ${safeRole}`);
          }
          
          return Promise.resolve({
            data: [updatedProfile],
            error: null
          });
        }
      };
    }
  };
}
