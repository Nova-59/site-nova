
import { mockSelect } from './select';
import { mockUpdate } from './update';
import { mockUpsert } from './upsert';
import { mockInsert } from './insert';
import { mockDelete } from './delete';

// Main export for profiles mock
export const mockProfiles = {
  select: () => mockSelect(),
  update: (data: any) => mockUpdate(data),
  upsert: (data: any) => mockUpsert(data),
  insert: (data: any) => mockInsert(data),
  delete: () => mockDelete()
};

// Re-export storage utilities for direct access
export { getStoredProfile } from './storage';
