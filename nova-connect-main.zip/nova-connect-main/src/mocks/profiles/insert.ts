
import { ADMIN_EMAIL } from './constants';
import { addStoredProfile } from './storage';
import { UserRole } from '@/types/user';

export function mockInsert(data: any) {
  console.log(`[Mock] Insert profile:`, data);
  
  // Security validation for role
  let safeRole = data.role as UserRole;
  
  // Only adjust admin role for security, not others
  if (data.role === 'admin') {
    // Allow admin for specific email
    if (data.email && data.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      safeRole = 'admin';
    } else {
      // Default to homeowner for security if someone tries to be admin
      safeRole = 'homeowner';
      console.log(`[Mock] Attempted to create admin account with unauthorized email, defaulted to homeowner`);
    }
  } else if (data.role === 'guest') {
    // Always convert guest to homeowner for consistency with Supabase
    safeRole = 'homeowner';
    console.log(`[Mock] Converting 'guest' role to 'homeowner' as standard practice`);
  } else {
    // Respect requested role for craftsman, homeowner, and estimator
    console.log(`[Mock] Creating profile with requested role: ${safeRole}`);
  }
  
  const mockProfile = {
    id: data.id,
    email: data.email,
    role: safeRole,
    first_name: '',
    last_name: '',
    created_at: new Date().toISOString()
  };
  
  // Save to localStorage
  addStoredProfile(mockProfile);

  // Update currentUser in localStorage with the correct role
  // This ensures that the role is updated both in the mock profile and the current user
  const currentUser = {
    id: data.id,
    email: data.email,
    role: safeRole,
    firstName: '',
    lastName: '',
    createdAt: new Date(),
    name: '',
  };
  
  console.log(`[Mock] Storing user with role: ${safeRole} in localStorage`);
  localStorage.setItem('currentUser', JSON.stringify(currentUser));
  
  return {
    eq: (field: string, value: string) => {
      console.log(`[Mock] Insert with condition ${field} = ${value}`);
      return Promise.resolve({ 
        data: { id: data.id }, 
        error: null 
      });
    }
  };
}
