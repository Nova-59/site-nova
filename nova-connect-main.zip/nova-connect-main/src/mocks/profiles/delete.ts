
import { getStoredProfile, getStoredProfiles, saveStoredProfiles } from './storage';

// Mock delete function for profiles
export const mockDelete = () => {
  console.log('[Mock] Deleting profile');
  
  return {
    eq: (field: string, value: string) => {
      console.log(`[Mock] Deleting profile where ${field} = ${value}`);
      
      // Get all profiles
      const profiles = getStoredProfiles();
      
      // Find the profile to delete
      const profileIndex = profiles.findIndex(p => p[field] === value);
      
      if (profileIndex !== -1) {
        // Remove the profile from the array
        profiles.splice(profileIndex, 1);
        
        // Save updated profiles
        saveStoredProfiles(profiles);
        
        return Promise.resolve({ data: null, error: null });
      }
      
      return Promise.resolve({ 
        data: null, 
        error: { message: `Profile with ${field} = ${value} not found` } 
      });
    }
  };
};
