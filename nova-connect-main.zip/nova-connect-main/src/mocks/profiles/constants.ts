
// Extracting constants
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL } from '@/services/auth/constants';

export { ADMIN_EMAIL, CRAFTSMAN_EMAIL };
