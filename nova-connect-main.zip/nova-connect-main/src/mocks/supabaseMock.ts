
// Client Supabase mocké
import { mockAuth } from './auth';
import { mockProfiles } from './profiles'; // Import from new path
import { mockStorage } from './storage';

export const createMockClient = () => {
  return {
    auth: mockAuth,
    from: (table: string) => {
      console.log(`[Mock] Operation on table ${table}`);
      if (table === 'profiles') {
        return mockProfiles;
      }
      // Default mock implementation for other tables
      return {
        select: () => ({
          eq: () => ({
            single: () => Promise.resolve({ data: null, error: null })
          })
        }),
        insert: () => ({
          eq: () => Promise.resolve({ data: null, error: null })
        }),
        update: () => ({
          eq: () => Promise.resolve({ data: null, error: null })
        }),
        upsert: () => Promise.resolve({ data: null, error: null })
      };
    },
    storage: mockStorage
  };
};
