
/**
 * Re-exports pour la rétrocompatibilité
 * IMPORTANT: Ce fichier est maintenu pour la compatibilité avec le code existant.
 * À terme, tout le code devrait utiliser directement lib/supabase-client.ts
 */

// Exporter depuis le nouveau fichier
import { 
  supabase,
  getSupabaseClient,
  isSupabaseReady,
  hasActiveSession,
  cleanAuthData 
} from './supabase-client';

// Re-exporter pour la rétrocompatibilité
export {
  supabase,
  getSupabaseClient,
  isSupabaseReady,
  hasActiveSession,
  cleanAuthData
};
