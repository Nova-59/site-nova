
/**
 * Client Supabase central et sécurisé
 * Ce fichier sert de point d'entrée unique pour toutes les interactions avec Supabase
 */
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Database } from '@/integrations/supabase/types';

// Constantes pour les clés Supabase
const SUPABASE_URL = "https://ibkbxmvxrneyupqsslmk.supabase.co";
const SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlia2J4bXZ4cm5leXVwcXNzbG1rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE0NTk0OTIsImV4cCI6MjA1NzAzNTQ5Mn0.Q6HVXIdT7ePeZDY1uH9fHby7WSvL-EMT5FD3OD8vDGU";

// Options de configuration du client
const supabaseOptions = {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    storage: localStorage
  }
};

// Création d'une instance unique du client Supabase
let supabaseInstance: SupabaseClient<Database> | null = null;

/**
 * Fonction pour obtenir l'instance du client Supabase
 * Garantit qu'une seule instance est créée (pattern Singleton)
 */
export const getSupabaseClient = (): SupabaseClient<Database> => {
  if (!supabaseInstance) {
    supabaseInstance = createClient<Database>(
      SUPABASE_URL,
      SUPABASE_KEY,
      supabaseOptions
    );
    console.log("Client Supabase initialisé");
  }
  return supabaseInstance;
};

// Export d'une instance du client pour un usage direct
export const supabase = getSupabaseClient();

/**
 * Vérifie si Supabase est initialisé et disponible
 * @param timeout Délai maximum d'attente en ms
 * @returns Promise<boolean> Indiquant si Supabase est prêt
 */
export const isSupabaseReady = async (timeout = 2000): Promise<boolean> => {
  try {
    // Promesse avec timeout pour éviter de bloquer indéfiniment
    const timeoutPromise = new Promise<boolean>((_, reject) => {
      setTimeout(() => reject(new Error('Supabase initialization timeout')), timeout);
    });

    // Tenter une simple opération pour vérifier la connexion
    const checkPromise = new Promise<boolean>(async (resolve) => {
      try {
        const { data, error } = await supabase.auth.getSession();
        if (error) {
          console.warn("Erreur lors de la vérification de Supabase:", error);
          resolve(false);
        } else {
          console.log("Supabase est prêt");
          resolve(true);
        }
      } catch (e) {
        console.warn("Exception lors de la vérification de Supabase:", e);
        resolve(false);
      }
    });

    // Utiliser la première promesse qui se résout
    return await Promise.race([checkPromise, timeoutPromise]);
  } catch (error) {
    console.error("Erreur lors de la vérification de Supabase:", error);
    return false;
  }
};

/**
 * Nettoie toutes les données d'authentification
 * Cette fonction est essentielle pour éviter les problèmes de persistance des sessions
 */
export const cleanAuthData = (): boolean => {
  try {
    console.log("Nettoyage de toutes les données d'authentification...");
    
    // 1. Suppression des données du localStorage
    const authKeys = Object.keys(localStorage).filter(key => 
      key.includes('supabase') || 
      key.includes('sb-') || 
      key.includes('auth') || 
      key.includes('currentUser') ||
      key.includes('mockUser')
    );
    
    authKeys.forEach(key => {
      try {
        localStorage.removeItem(key);
        console.log(`Suppression de ${key} du localStorage`);
      } catch (e) {
        console.error(`Échec de suppression de ${key}:`, e);
      }
    });
    
    // 2. Nettoyage du sessionStorage
    const sessionKeys = Object.keys(sessionStorage).filter(key => 
      key.includes('supabase') || 
      key.includes('sb-') || 
      key.includes('auth')
    );
    
    sessionKeys.forEach(key => {
      try {
        sessionStorage.removeItem(key);
      } catch (e) {
        console.error(`Échec de suppression de ${key} du sessionStorage:`, e);
      }
    });
    
    // 3. Suppression des cookies liés à l'authentification
    document.cookie = "sb-access-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie = "sb-refresh-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie = "supabase-auth-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    
    console.log("Nettoyage des données d'authentification terminé");
    return true;
  } catch (error) {
    console.error("Erreur lors du nettoyage des données d'authentification:", error);
    return false;
  }
};

/**
 * Vérifie si l'utilisateur a une session active
 * @returns Promise<boolean> Indiquant si une session est active
 */
export const hasActiveSession = async (): Promise<boolean> => {
  try {
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      console.error("Erreur lors de la vérification de session:", error);
      return false;
    }
    
    return !!data.session;
  } catch (error) {
    console.error("Exception lors de la vérification de session:", error);
    return false;
  }
};
