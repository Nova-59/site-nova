
import { cn } from "@/lib/utils";

export function navigationMenuTriggerStyle() {
  return cn(
    "text-black hover:bg-gray-200 hover:text-nova-gold text-lg font-medium px-4 py-2 block text-center"
  );
}
