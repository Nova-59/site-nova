
// Système de traduction simple
export const translations = {
  fr: {
    // Header
    home: "Accueil",
    services: "Services",
    howItWorks: "Comment ça marche",
    aboutUs: "À propos",
    signIn: "Connexion",
    getStarted: "Commencer",
    dashboard: "Tableau de bord",
    profile: "Profil",
    settings: "Paramètres",
    logOut: "Déconnexion",
    notifications: "Notifications",
    myAccount: "Mon compte",
    
    // Footer
    connectingHomeowners: "Connexion entre propriétaires et artisans vérifiés pour des réparations fiables.",
    quickLinks: "Liens rapides",
    contact: "Contact",
    subscribeNewsletter: "Abonnez-vous à notre newsletter",
    yourEmail: "Votre email",
    subscribe: "S'abonner",
    allRightsReserved: "Tous droits réservés",
    termsOfService: "Conditions d'utilisation",
    privacyPolicy: "Politique de confidentialité",
    cookiesPolicy: "Politique des cookies",
    
    // HomePage
    heroTitle: "Connectez-vous avec des artisans vérifiés pour vos réparations",
    heroSubtitle: "Notre plateforme garantit que toutes les demandes de réparation sont pré-vérifiées par des estimateurs professionnels, vous mettant en relation avec des artisans qualifiés en qui vous pouvez avoir confiance.",
    postRepairRequest: "Publier une demande de réparation",
    joinAsCraftsman: "Rejoindre en tant qu'artisan",
    howItWorksTitle: "Comment ça marche",
    submitRequest: "Soumettez votre demande",
    submitRequestDesc: "Décrivez votre besoin de réparation, téléchargez des photos et indiquez votre localisation. Notre plateforme facilite la description de ce que vous devez réparer.",
    professionalVerification: "Vérification professionnelle",
    professionalVerificationDesc: "Nos estimateurs vérifient votre demande et fournissent une estimation des coûts, assurant la transparence et évitant les surprises.",
    connectWithCraftsmen: "Connexion avec des artisans",
    connectWithCraftsmenDesc: "Les artisans qualifiés de votre région sont notifiés et peuvent accepter votre travail. Choisissez celui qui correspond le mieux à vos besoins.",
    whyChooseNova: "Pourquoi choisir NOVA",
    verifiedProfessionals: "Professionnels vérifiés",
    verifiedProfessionalsDesc: "Tous les artisans sur notre plateforme sont examinés et vérifiés pour leur qualité et leur fiabilité.",
    preVerifiedJobs: "Travaux pré-vérifiés",
    preVerifiedJobsDesc: "Chaque demande de réparation est vérifiée et estimée par des professionnels avant publication.",
    secureCommunication: "Communication sécurisée",
    secureCommunicationDesc: "La messagerie intégrée facilite la discussion des détails et la coordination de votre réparation.",
    readyToGetRepair: "Prêt à faire réparer correctement ?",
    joinThousands: "Rejoignez des milliers de propriétaires qui ont trouvé des artisans fiables pour leurs besoins de réparation.",
    getStartedNow: "Commencer maintenant",
    
    // AuthPage
    createAccount: "Créer un compte",
    signInAccount: "Connexion à votre compte",
    enterDetails: "Entrez vos informations pour créer un nouveau compte",
    enterCredentials: "Entrez vos identifiants pour accéder à votre compte",
    iAmA: "Je suis un(e) :",
    homeowner: "Propriétaire",
    craftsman: "Artisan",
    email: "Email",
    password: "Mot de passe",
    confirmPassword: "Confirmer le mot de passe",
    processing: "Traitement en cours...",
    signUp: "S'inscrire",
    alreadyHaveAccount: "Vous avez déjà un compte ?",
    dontHaveAccount: "Vous n'avez pas de compte ?",
    passwordsDoNotMatch: "Les mots de passe ne correspondent pas",
    pleaseEnsureMatch: "Veuillez vous assurer que vos mots de passe correspondent.",
    passwordTooShort: "Mot de passe trop court",
    passwordMinLength: "Le mot de passe doit contenir au moins 6 caractères",
    accountCreated: "Compte créé",
    accountCreatedDesc: "Votre compte a été créé avec succès.",
    welcomeBack: "Bienvenue",
    successfullyLoggedIn: "Vous vous êtes connecté avec succès.",
    authenticationFailed: "Échec d'authentification",
    problemWithRequest: "Un problème est survenu lors de votre demande. Veuillez réessayer.",
    unexpectedError: "Une erreur inattendue s'est produite",
    accountCreationFailed: "Échec de la création du compte",

    // Plumbing and services
    plumbing: "Plomberie",
    electricity: "Électricité",
    carpentry: "Menuiserie",
    painting: "Peinture",
    tiling: "Carrelage",
    gardening: "Jardinage",
    plumbingDesc: "Fuites, installations et réparations de tuyaux",
    electricityDesc: "Câblage, éclairage et appareils électriques",
    carpentryDesc: "Armoires, portes et réparations de bois",
    paintingDesc: "Services de peinture intérieure et extérieure",
    tilingDesc: "Carrelage de salle de bain, cuisine et sol",
    gardeningDesc: "Aménagement paysager et entretien de jardin"
  }
};

export const t = (key: string): string => {
  const keys = key.split('.');
  let current: any = translations.fr;
  
  for (const k of keys) {
    if (current[k] === undefined) {
      return key; // Retourne la clé si la traduction n'est pas trouvée
    }
    current = current[k];
  }
  
  return current;
};
