
import { v4 as uuidv4 } from 'uuid';

export type UserRole = 'homeowner' | 'craftsman' | 'admin' | 'estimator';

export interface User {
  id: string;
  email: string;
  role: UserRole;
  createdAt: Date;
}

// This is a mock implementation for development purposes only
export const createMockUser = async (
  email: string, 
  password: string, 
  isSignUp: boolean, 
  role: UserRole
): Promise<User> => {
  // In a real app, this would interact with your authentication backend
  // For demo purposes, we're just creating a mock user object
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  return {
    id: uuidv4(),
    email,
    role,
    createdAt: new Date()
  };
};

export const getCurrentUser = (): User | null => {
  const userJson = localStorage.getItem("currentUser");
  if (!userJson) return null;
  
  try {
    return JSON.parse(userJson);
  } catch (e) {
    console.error("Error parsing user data from localStorage", e);
    return null;
  }
};
