
import { Project } from "@/types/project";
import { v4 as uuidv4 } from 'uuid';

// Tableau vide pour les projets (suppression des données de démonstration)
export const mockProjects: Project[] = [];

// Fonction pour ajouter un nouveau projet
export const addProject = (project: Omit<Project, 'id'>) => {
  const newProject = {
    ...project,
    id: uuidv4()
  };
  mockProjects.push(newProject);
  return newProject;
};
