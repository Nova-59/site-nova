
/**
 * Formats a number as a currency string
 * @param amount - The amount to format
 * @param currency - The currency code (default: EUR)
 * @param locale - The locale to use (default: fr-FR)
 * @returns Formatted currency string
 */
export function formatCurrency(amount: number, currency = "EUR", locale = "fr-FR") {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

/**
 * Formats a date to a readable string
 * @param date - The date to format
 * @param format - The format to use (short, medium, long, full)
 * @param locale - The locale to use (default: fr-FR)
 * @returns Formatted date string
 */
export function formatDate(date: Date, format: 'short' | 'medium' | 'long' | 'full' = 'medium', locale = 'fr-FR') {
  const options: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'long', year: 'numeric' };
  
  switch (format) {
    case 'short':
      options.month = 'numeric';
      break;
    case 'long':
      options.weekday = 'long';
      break;
    case 'full':
      options.weekday = 'long';
      options.hour = '2-digit';
      options.minute = '2-digit';
      break;
    // medium is default
  }
  
  return new Intl.DateTimeFormat(locale, options).format(date);
}
