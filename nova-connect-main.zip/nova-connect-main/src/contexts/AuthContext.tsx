
/**
 * Point d'entrée unique pour l'authentification
 * Ce fichier centralise toutes les exportations liées à l'authentification
 */

// Import depuis l'implémentation réelle
import { AuthProvider, useAuth } from './auth/AuthProvider';
import { AuthContextType } from './auth/types';

// Re-exportation pour que tous les imports utilisent ce fichier
export { AuthProvider, useAuth };
export type { AuthContextType };
