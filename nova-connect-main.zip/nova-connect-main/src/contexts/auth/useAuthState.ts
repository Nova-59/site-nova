
import { useState } from 'react';
import { User } from '@/types/user';
import { useAuthError } from './methods/useAuthError';
import { useUserProfile } from './methods/useUserProfile';
import { useSessionState } from './methods/useSessionState';

export const useAuthState = () => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  
  const { 
    sessionError,
    setSessionError, 
    supabaseInitialized, 
    setSupabaseInitialized, 
    resetSessionError,
    refreshAttempts,
    incrementRefreshAttempt,
    resetRefreshAttempts
  } = useSessionState();
  
  const { error, handleAuthError, clearError } = useAuthError();
  
  const { processUserProfile } = useUserProfile(handleAuthError);

  return {
    user,
    setUser,
    loading,
    setLoading,
    sessionError,
    setSessionError,
    supabaseInitialized,
    setSupabaseInitialized,
    resetSessionError,
    handleAuthError,
    processUserProfile,
    error,
    refreshAttempts,
    incrementRefreshAttempt,
    resetRefreshAttempts
  };
};
