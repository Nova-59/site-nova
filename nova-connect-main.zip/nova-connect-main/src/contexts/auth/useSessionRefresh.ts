
import { useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { User, UserRole } from '@/types/user';
import { useUserStorage } from '@/hooks/useUserStorage';
import { Session } from '@supabase/supabase-js';
import { MAX_REFRESH_ATTEMPTS } from './constants';

export const useSessionRefresh = (
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  setSupabaseInitialized: (initialized: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string,
  processUserProfile: (userId: string, email: string, defaultRole?: UserRole) => Promise<User | null>,
  supabaseInitialized: boolean,
  refreshAttempts: number,
  incrementRefreshAttempt: () => void,
  resetRefreshAttempts: () => void
) => {
  const { saveUser, removeUser, loadUserFromStorage, isUserSessionValid } = useUserStorage();
  
  // Use a stateful variable to track ongoing refreshes
  let isRefreshing = false;

  const refreshSession = useCallback(async (): Promise<Session | null> => {
    // Prevent simultaneous refreshes
    if (isRefreshing) {
      console.log("Session refresh already in progress, skipping");
      return null;
    }
    
    try {
      // Mark as currently refreshing
      isRefreshing = true;
      
      // Limit the number of attempts
      if (refreshAttempts >= MAX_REFRESH_ATTEMPTS) {
        console.log(`Maximum refresh attempts reached (${MAX_REFRESH_ATTEMPTS}), stopping process`);
        setLoading(false);
        return null;
      }
      
      incrementRefreshAttempt();
      console.log(`Session refresh attempt #${refreshAttempts + 1}`);
      
      setLoading(true);
      resetSessionError();
      
      console.log("Refreshing auth session...");
      
      if (!supabaseInitialized) {
        console.log("Waiting for Supabase to initialize before refreshing session");
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      
      const { data, error } = await supabase.auth.getSession();
      
      setSupabaseInitialized(true);
      
      if (error) {
        throw new Error(`Session error: ${error.message}`);
      }
      
      if (!data.session) {
        console.log("No active session found during refresh");
        removeUser();
        setUser(null);
        resetRefreshAttempts();
        setLoading(false); // Important: ensure loading state is disabled here
        return null;
      }
      
      const supabaseUser = data.session.user;
      
      // Process the found user
      if (!isUserSessionValid(supabaseUser.id)) {
        console.log("Stored user does not match session, fetching updated profile");
        
        // Check for temporary role for this user
        const tempRoleKey = 'tempUserRole_' + supabaseUser.id;
        let defaultRole: UserRole = 'homeowner';
        const email = supabaseUser.email || '';
        
        // Check for special accounts
        if (email.toLowerCase() === 'direction@nova-aps.com') {
          defaultRole = 'admin';
        } else if (email.toLowerCase() === 'skyguard.couv@gmail.com') {
          // For skyguard, check if there's a stored role first before defaulting to craftsman
          try {
            // Check if we have a stored profile for this email already
            const { data } = await supabase
              .from('profiles')
              .select('role')
              .eq('email', email.toLowerCase())
              .maybeSingle();
            
            if (data && data.role) {
              console.log(`Found existing role for ${email}: ${data.role}`);
              defaultRole = data.role as UserRole;
            } else {
              // Special handling for skyguard account with localStorage
              const storedRole = localStorage.getItem(tempRoleKey);
              if (storedRole) {
                try {
                  const parsedRole = JSON.parse(storedRole);
                  console.log("Temporary role found:", parsedRole.role);
                  defaultRole = parsedRole.role as UserRole;
                } catch (e) {
                  console.error("Error parsing temporary role:", e);
                }
              }
            }
          } catch (e) {
            console.error("Error checking existing profile:", e);
          }
        } else {
          // For other users, check for temporary role
          try {
            const storedRole = localStorage.getItem(tempRoleKey);
            if (storedRole) {
              const parsedRole = JSON.parse(storedRole);
              console.log("Temporary role found:", parsedRole.role);
              defaultRole = parsedRole.role as UserRole;
            }
          } catch (e) {
            console.error("Error retrieving temporary role:", e);
          }
        }
        
        console.log("Using default role:", defaultRole);
        
        const freshUserData = await processUserProfile(
          supabaseUser.id, 
          email,
          defaultRole
        );
        
        if (freshUserData) {
          setUser(freshUserData);
          saveUser(freshUserData);
          console.log("User updated with role:", freshUserData.role);
          
          // Clean up temporary role after use
          localStorage.removeItem(tempRoleKey);
        } else {
          console.error("Failed to process user profile, no data returned");
          setLoading(false);
        }
      } else {
        const { user: storedUser } = loadUserFromStorage();
        if (storedUser) {
          // Check if user has 'guest' role and try to correct it
          if (storedUser.role === 'guest') {
            console.log("User with 'guest' role detected, attempting correction");
            
            const tempRoleKey = 'tempUserRole_' + storedUser.id;
            try {
              const storedRole = localStorage.getItem(tempRoleKey);
              if (storedRole) {
                const parsedRole = JSON.parse(storedRole);
                console.log("Correcting 'guest' role with temporary role:", parsedRole.role);
                
                const updatedUser = {
                  ...storedUser,
                  role: parsedRole.role as UserRole
                };
                
                setUser(updatedUser);
                saveUser(updatedUser);
                
                // Update profile in Supabase
                try {
                  await supabase
                    .from('profiles')
                    .update({ role: parsedRole.role })
                    .eq('id', storedUser.id);
                    
                  console.log("Profile updated in Supabase with role:", parsedRole.role);
                  
                  // Clean up temporary role after use
                  localStorage.removeItem(tempRoleKey);
                } catch (e) {
                  console.error("Error updating profile in Supabase:", e);
                }
              } else {
                // No temp role, still use stored user
                setUser(storedUser);
              }
            } catch (e) {
              console.error("Error correcting role:", e);
              setUser(storedUser);
            }
          } else {
            setUser(storedUser);
          }
        } else {
          console.warn("No stored user found despite session validation passing");
        }
      }
      
      resetRefreshAttempts();
      return data.session;
    } catch (error) {
      handleAuthError(error, 'session-refresh');
      removeUser();
      setUser(null);
      return null;
    } finally {
      // Always disable loading state at the end
      setLoading(false);
      // Mark refresh as complete
      isRefreshing = false;
    }
  }, [
    handleAuthError, 
    incrementRefreshAttempt,
    isUserSessionValid, 
    loadUserFromStorage, 
    processUserProfile, 
    refreshAttempts,
    removeUser, 
    resetRefreshAttempts,
    resetSessionError, 
    saveUser, 
    setLoading, 
    setSupabaseInitialized, 
    setUser, 
    supabaseInitialized
  ]);

  return { refreshSession };
};
