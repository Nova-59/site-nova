
import { User, UserRole } from '@/types/user';
import { useSignUp } from './methods/useSignUp';
import { useSignIn } from './methods/useSignIn';
import { useSignOut } from './methods/useSignOut';
import { useRoleManagement } from './methods/useRoleManagement';
import { useResetPassword } from './methods/useResetPassword';

export const useAuthMethods = (
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string,
  processUserProfile: (userId: string, email: string, defaultRole?: UserRole) => Promise<User | null>
) => {
  const { signUp } = useSignUp(
    setUser,
    setLoading,
    resetSessionError,
    handleAuthError
  );
  
  const { signIn } = useSignIn(
    setUser,
    setLoading,
    resetSessionError,
    handleAuthError,
    processUserProfile
  );
  
  const { signOut } = useSignOut(
    setUser,
    setLoading,
    resetSessionError,
    handleAuthError
  );
  
  const { updateUserRole } = useRoleManagement(
    setUser,
    setLoading,
    resetSessionError,
    handleAuthError
  );
  
  const { resetPassword, updatePassword } = useResetPassword(
    setLoading,
    resetSessionError,
    handleAuthError
  );

  return {
    signUp,
    signIn,
    signOut,
    updateUserRole,
    resetPassword,
    updatePassword
  };
};
