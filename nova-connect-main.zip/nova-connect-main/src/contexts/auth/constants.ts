
/**
 * Constants used across authentication components
 */

// Special email addresses for default roles
export const ADMIN_EMAIL = 'direction@nova-aps.com';
export const CRAFTSMAN_EMAIL = 'skyguard.couv@gmail.com';

// Auth configuration
export const MAX_REFRESH_ATTEMPTS = 3;
export const AUTH_LOADING_TIMEOUT = 5000;
