
import { User, UserRole } from '@/types/user';
import { Session } from '@supabase/supabase-js';

export interface AuthContextType {
  user: User | null;
  session: Session | null;
  loading: boolean;
  sessionError: string | null;
  error: Error | null;
  signIn: (email: string, password: string) => Promise<{error: Error | null}>;
  signUp: (email: string, password: string, role: UserRole) => Promise<{error: Error | null, user: User | null}>;
  signOut: () => Promise<{error: Error | null}>;
  updateUserRole: (userId: string, newRole: UserRole) => Promise<{success: boolean, error: Error | null}>;
  refreshSession: () => Promise<Session | null>;
  resetPassword: (email: string) => Promise<{error: Error | null}>;
  updatePassword: (newPassword: string) => Promise<{error: Error | null, success: boolean}>;
}
