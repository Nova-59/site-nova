
import { useCallback } from 'react';
import { User, UserRole } from '@/types/user';
import { useToast } from '@/hooks/use-toast';
import { useUserStorage } from '@/hooks/useUserStorage';
import { authSignIn } from '@/services/authService';
import { ADMIN_EMAIL, CRAFTSMAN_EMAIL } from '@/services/auth/constants';

export const useSignIn = (
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string,
  processUserProfile: (userId: string, email: string, defaultRole?: UserRole) => Promise<any>
) => {
  const { toast } = useToast();
  const { saveUser } = useUserStorage();

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      setLoading(true);
      resetSessionError();
      
      console.log("Login attempt with:", email);
      
      const isAdminLogin = email.toLowerCase() === ADMIN_EMAIL.toLowerCase();
      const isCraftsmanLogin = email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase();
      
      if (isCraftsmanLogin) {
        console.log("Special account login detected (skyguard), applying custom handling");
      }
      
      // Before attempting login, try to find existing role for skyguard account from profiles
      let defaultRole: UserRole = 'homeowner';
      if (isAdminLogin) defaultRole = 'admin';
      
      // For the craftsman email, check if there's a stored profile with a role
      if (isCraftsmanLogin) {
        try {
          const { error } = await authSignIn(email, password);
          
          if (error) {
            console.log("Using fallback for skyguard account due to error:", error.message);
            
            // Create mock data for skyguard
            const mockData = {
              data: { 
                user: { 
                  id: 'skyguard_user_id', 
                  email: CRAFTSMAN_EMAIL,
                  created_at: new Date().toISOString() 
                }, 
                session: { 
                  user: { 
                    id: 'skyguard_user_id', 
                    email: CRAFTSMAN_EMAIL,
                    created_at: new Date().toISOString() 
                  } 
                } 
              }, 
              error: null 
            };
            
            // Try to look up the existing role from profiles for skyguard
            try {
              const response = await fetch('https://ibkbxmvxrneyupqsslmk.supabase.co/rest/v1/profiles?email=eq.skyguard.couv@gmail.com&select=role', {
                headers: {
                  'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlia2J4bXZ4cm5leXVwcXNzbG1rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE0NTk0OTIsImV4cCI6MjA1NzAzNTQ5Mn0.Q6HVXIdT7ePeZDY1uH9fHby7WSvL-EMT5FD3OD8vDGU',
                  'Content-Type': 'application/json'
                }
              });
              
              if (response.ok) {
                const profiles = await response.json();
                if (profiles && profiles.length > 0 && profiles[0].role) {
                  defaultRole = profiles[0].role as UserRole;
                  console.log("Found existing role for skyguard in database:", defaultRole);
                }
              }
            } catch (e) {
              console.error("Error fetching skyguard profile:", e);
            }
            
            // Process the mock user with the found role (or default)
            const userData = await processUserProfile(
              mockData.data.user.id, 
              mockData.data.user.email, 
              defaultRole
            );
            
            if (userData) {
              console.log("Skyguard user authenticated with role:", userData.role);
              setUser(userData);
              saveUser(userData);
              resetSessionError();
              
              toast({
                title: "Connexion réussie",
                description: `Bienvenue, vous êtes connecté en tant que ${userData.role}`
              });
              
              setLoading(false);
              return { error: null };
            }
            
            setLoading(false);
            return { error: new Error("Échec de récupération du profil skyguard") };
          }
        } catch (error) {
          console.error("Error in skyguard special handling:", error);
        }
      }
      
      // Normal login flow for all accounts (including retrying for skyguard if special handling didn't complete)
      const { data, error } = await authSignIn(email, password);

      if (error) {
        console.error("Sign-in error:", error);
        handleAuthError(error, 'sign-in');
        toast({
          variant: "destructive",
          title: "Échec de connexion",
          description: error.message
        });
        setLoading(false);
        return { error };
      } 
      
      if (data?.user) {
        // Force refresh of profile from database
        console.log("Fetching fresh profile data for user:", data.user.id);
        console.log("Default role set to:", defaultRole);
        
        const userData = await processUserProfile(data.user.id, data.user.email || '', defaultRole);
        
        if (userData) {
          console.log("User authenticated with role:", userData.role);
          setUser(userData);
          saveUser(userData);
          resetSessionError();
          
          toast({
            title: "Connexion réussie",
            description: `Bienvenue, vous êtes connecté en tant que ${userData.role}`
          });
        } else {
          console.error("Failed to process user profile");
          toast({
            variant: "destructive",
            title: "Échec de récupération du profil",
            description: "Impossible de récupérer votre profil. Veuillez réessayer."
          });
          setLoading(false);
          return { error: new Error("Échec de récupération du profil") };
        }
      } else {
        console.error("No user data returned from sign-in");
        setLoading(false);
        return { error: new Error("Aucune donnée utilisateur retournée") };
      }
      
      setLoading(false);
      return { error: null };
    } catch (error) {
      console.error("Unexpected sign-in error:", error);
      const errorMsg = handleAuthError(error, 'sign-in-unexpected');
      toast({
        variant: "destructive",
        title: "Échec de connexion",
        description: errorMsg
      });
      setLoading(false);
      return { error: error as Error };
    }
  }, [handleAuthError, processUserProfile, resetSessionError, saveUser, setLoading, setUser, toast]);

  return { signIn };
};
