
import { useCallback } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useUserStorage } from '@/hooks/useUserStorage';
import { authSignOut } from '@/services/authService';

export const useSignOut = (
  setUser: (user: null) => void,
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string
) => {
  const { toast } = useToast();
  const { removeUser } = useUserStorage();

  const signOut = useCallback(async () => {
    try {
      console.log("Executing signOut in AuthContext...");
      
      setLoading(true);
      
      setUser(null);
      removeUser();
      resetSessionError();
      
      localStorage.removeItem('supabase.auth.token');
      localStorage.removeItem('currentUser');
      localStorage.removeItem('mockUser');
      
      await authSignOut();
      
      console.log("Signout sequence completed successfully");
      
      toast({
        title: "Déconnecté",
        description: "Vous avez été déconnecté avec succès"
      });
      
      setTimeout(() => {
        window.location.href = '/';
      }, 100);
      
      return { error: null };
    } catch (error) {
      handleAuthError(error, 'sign-out');
      
      toast({
        variant: "destructive",
        title: "Échec de déconnexion",
        description: "Une erreur s'est produite lors de la déconnexion. Veuillez rafraîchir la page."
      });
      
      setTimeout(() => {
        window.location.href = '/';
      }, 500);
      
      return { error: error as Error };
    } finally {
      setLoading(false);
    }
  }, [handleAuthError, removeUser, resetSessionError, setLoading, setUser, toast]);

  return { signOut };
};
