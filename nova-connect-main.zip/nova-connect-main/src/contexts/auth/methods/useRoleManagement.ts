
import { useCallback } from 'react';
import { UserRole } from '@/types/user';
import { useUserStorage } from '@/hooks/useUserStorage';
import { updateUserRole as apiUpdateUserRole } from '@/services/authService';

export const useRoleManagement = (
  setUser: (user: any) => void,
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string
) => {
  const { saveUser } = useUserStorage();

  const updateUserRole = useCallback(async (userId: string, newRole: UserRole) => {
    try {
      setLoading(true);
      
      // Load current user before proceeding
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      
      if (!currentUser || !currentUser.id) {
        throw new Error("Utilisateur non authentifié");
      }
      
      await apiUpdateUserRole(userId, newRole, currentUser.role as UserRole);

      if (currentUser.id === userId) {
        const updatedUser = { ...currentUser, role: newRole };
        setUser(updatedUser);
        saveUser(updatedUser);
        resetSessionError();
      }
      
      return { success: true, error: null };
    } catch (error) {
      handleAuthError(error, 'role-update');
      return { success: false, error: error as Error };
    } finally {
      setLoading(false);
    }
  }, [handleAuthError, resetSessionError, saveUser, setLoading, setUser]);

  return { updateUserRole };
};
