
import { useCallback } from 'react';
import { User, UserRole } from '@/types/user';
import { fetchUserProfile } from '@/services/authService';
import { CRAFTSMAN_EMAIL } from '@/services/auth/constants';

export const useUserProfile = (handleAuthError: (err: any, context: string) => string) => {
  const processUserProfile = useCallback(async (userId: string, email: string, defaultRole: UserRole = 'homeowner'): Promise<User | null> => {
    try {
      console.log("Processing user profile for:", email, "with default role:", defaultRole);
      
      // Special IDs for account handling
      const isCraftsmanById = userId === 'craftsman_user_id' || userId === 'skyguard_user_id';
      
      // Special handling for craftsman accounts with generated IDs
      if (isCraftsmanById) {
        console.log("Detected special account with generated ID");
        
        // Try to fetch the profile from the database first to respect any existing role
        try {
          const profileData = await fetchUserProfile(userId, true);
          
          if (profileData && profileData.role) {
            console.log("Found profile data for special account:", profileData);
            
            return {
              id: userId,
              email: CRAFTSMAN_EMAIL,
              role: profileData.role as UserRole,
              firstName: profileData.first_name || 'SkyGuard',
              lastName: profileData.last_name || 'Couverture',
              name: `${profileData.first_name || 'SkyGuard'} ${profileData.last_name || 'Couverture'}`,
              createdAt: new Date(),
            };
          }
        } catch (e) {
          console.warn("Error fetching profile data for special account:", e);
        }
        
        // If no profile found, try alternative lookup by email
        try {
          const response = await fetch('https://ibkbxmvxrneyupqsslmk.supabase.co/rest/v1/profiles?email=eq.skyguard.couv@gmail.com&select=*', {
            headers: {
              'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlia2J4bXZ4cm5leXVwcXNzbG1rIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDE0NTk0OTIsImV4cCI6MjA1NzAzNTQ5Mn0.Q6HVXIdT7ePeZDY1uH9fHby7WSvL-EMT5FD3OD8vDGU',
              'Content-Type': 'application/json'
            }
          });
          
          if (response.ok) {
            const profiles = await response.json();
            if (profiles && profiles.length > 0) {
              const profile = profiles[0];
              console.log("Found profile for skyguard by email:", profile);
              
              return {
                id: userId,
                email: CRAFTSMAN_EMAIL,
                role: profile.role as UserRole,
                firstName: profile.first_name || 'SkyGuard',
                lastName: profile.last_name || 'Couverture',
                name: `${profile.first_name || 'SkyGuard'} ${profile.last_name || 'Couverture'}`,
                createdAt: new Date(),
              };
            }
          }
        } catch (e) {
          console.error("Error finding profile by email:", e);
        }
        
        // As fallback, create with default role if everything else fails
        return {
          id: userId,
          email: CRAFTSMAN_EMAIL,
          role: defaultRole,
          firstName: 'SkyGuard',
          lastName: 'Couverture',
          name: 'SkyGuard Couverture',
          createdAt: new Date(),
        };
      }
      
      // For all other accounts, get profile from the database
      const profileData = await fetchUserProfile(userId);
      console.log("Profile data retrieved:", profileData);
      
      // Use the role from the profile data, or default to the provided defaultRole
      let userRole: UserRole = defaultRole;
      
      // If we have profile data, use the role from the profile
      if (profileData) {
        // If the role is "guest", convert it to the default role
        if (profileData.role === 'guest') {
          // Check if there's a temporary role stored for this user
          const tempRoleKey = 'tempUserRole_' + userId;
          try {
            const storedRole = localStorage.getItem(tempRoleKey);
            if (storedRole) {
              const parsedRole = JSON.parse(storedRole);
              console.log("Temporary role found for user:", parsedRole.role);
              userRole = parsedRole.role as UserRole;
            } else {
              // If no temporary role, use the default role
              userRole = defaultRole;
            }
          } catch (e) {
            console.error("Error retrieving temporary role:", e);
            userRole = defaultRole;
          }
        } else {
          userRole = (profileData.role as UserRole) || defaultRole;
        }
      }
      
      // Safely extract first_name and last_name with proper type checking
      const firstName = profileData && 'first_name' in profileData 
        ? (typeof profileData.first_name === 'string' ? profileData.first_name : '') 
        : '';
      
      const lastName = profileData && 'last_name' in profileData 
        ? (typeof profileData.last_name === 'string' ? profileData.last_name : '') 
        : '';
      
      // Create a name safely from the extracted first and last names
      const name = `${firstName} ${lastName}`.trim();
      
      const userData: User = {
        id: userId,
        email: email || '',
        role: userRole,
        firstName: firstName,
        lastName: lastName,
        createdAt: new Date(),
        name: name || email.split('@')[0],
      };
      
      console.log("Processed user profile:", userData);
      return userData;
    } catch (err) {
      console.error("Error processing user profile:", err);
      handleAuthError(err, 'profile-fetch');
      
      return {
        id: userId,
        email: email || '',
        role: defaultRole,
        createdAt: new Date(),
        name: email.split('@')[0] || '',
      };
    }
  }, [handleAuthError]);

  return { processUserProfile };
};
