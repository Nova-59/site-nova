
import { useState, useCallback } from 'react';

export const useSessionState = () => {
  const [sessionError, setSessionError] = useState<string | null>(null);
  const [supabaseInitialized, setSupabaseInitialized] = useState(false);
  const [refreshAttempts, setRefreshAttempts] = useState(0);
  
  const resetSessionError = useCallback(() => {
    if (sessionError) {
      setSessionError(null);
    }
  }, [sessionError]);
  
  const incrementRefreshAttempt = useCallback(() => {
    setRefreshAttempts(prev => {
      // Vérifier si on n'a pas déjà dépassé la limite
      if (prev >= 3) {
        console.log("Limite de tentatives atteinte, ne pas incrémenter davantage");
        return prev;
      }
      return prev + 1;
    });
  }, []);
  
  const resetRefreshAttempts = useCallback(() => {
    if (refreshAttempts !== 0) {
      console.log("Réinitialisation du compteur de tentatives");
      setRefreshAttempts(0);
    }
  }, [refreshAttempts]);

  return {
    sessionError,
    setSessionError,
    supabaseInitialized,
    setSupabaseInitialized,
    resetSessionError,
    refreshAttempts,
    incrementRefreshAttempt,
    resetRefreshAttempts
  };
};
