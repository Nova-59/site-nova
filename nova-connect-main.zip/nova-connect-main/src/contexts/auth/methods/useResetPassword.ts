
import { supabase } from '@/lib/supabase-client';

export const useResetPassword = (
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string
) => {
  const resetPassword = async (email: string) => {
    try {
      setLoading(true);
      resetSessionError();
      
      if (!email) {
        throw new Error("L'adresse email est requise");
      }
      
      console.log(`Tentative de réinitialisation de mot de passe pour: ${email}`);
      
      // URL complète pour le site de production
      const origin = window.location.origin || "https://nova-connect.lovable.app";
      const redirectUrl = `${origin}/reset-password`;
      
      console.log("URL de redirection pour la réinitialisation:", redirectUrl);
      
      // S'assurer que le baseUrl est une URL valide
      try {
        new URL(redirectUrl);
      } catch (e) {
        console.error("URL de redirection invalide:", e);
        throw new Error("Configuration d'URL invalide. Veuillez contacter l'administrateur.");
      }
      
      // Imprimer toutes les informations de requête pour le débogage
      console.log("URL de base:", window.location.origin);
      console.log("Navigateur:", navigator.userAgent);
      
      const { data, error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: redirectUrl
      });
      
      if (error) {
        console.error("Erreur de réinitialisation:", error);
        throw error;
      }
      
      console.log("Réinitialisation de mot de passe réussie, email envoyé", data);
      
      return { error: null };
    } catch (error) {
      console.error('Erreur de réinitialisation de mot de passe:', error);
      handleAuthError(error, 'reset-password');
      return { error: error as Error };
    } finally {
      setLoading(false);
    }
  };
  
  const updatePassword = async (newPassword: string) => {
    try {
      setLoading(true);
      resetSessionError();
      
      if (!newPassword || newPassword.length < 6) {
        throw new Error("Le mot de passe doit contenir au moins 6 caractères");
      }
      
      console.log("Tentative de mise à jour du mot de passe");
      
      // Vérification de session active
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      
      console.log("Session actuelle pour mise à jour du mot de passe:", 
        sessionData?.session ? "Session trouvée" : "Aucune session trouvée");
      
      if (sessionError) {
        console.error("Erreur lors de la récupération de la session:", sessionError);
        throw sessionError;
      }
      
      if (!sessionData.session) {
        console.error("Aucune session active lors de la mise à jour du mot de passe");
        
        // Tentative alternative: extraire le token de l'URL et le traiter manuellement
        const hash = window.location.hash;
        const searchParams = new URLSearchParams(window.location.search);
        
        console.log("Paramètres d'URL pour récupération manuelle:", {
          hash,
          search: Object.fromEntries(searchParams.entries())
        });
        
        // Vérifier si des tokens d'accès sont présents dans les paramètres d'URL
        const accessToken = searchParams.get('access_token');
        const type = searchParams.get('type');
        
        if ((type === 'recovery' || type === 'passwordReset') && accessToken) {
          try {
            console.log("Tentative d'établissement de session avec access_token de l'URL");
            const { data, error } = await supabase.auth.setSession({
              access_token: accessToken,
              refresh_token: ""
            });
            
            if (error || !data.session) {
              console.error("Échec de récupération manuelle de session:", error);
              throw new Error("Impossible d'établir une session valide. Le lien a peut-être expiré. Veuillez demander un nouveau lien.");
            }
            
            console.log("Session établie manuellement avec succès");
          } catch (e) {
            console.error("Erreur lors de la tentative manuelle de récupération de session:", e);
            throw new Error("Le lien de réinitialisation est invalide ou a expiré. Veuillez demander un nouveau lien.");
          }
        } else {
          throw new Error("Aucune session active. Le lien a peut-être expiré. Veuillez demander un nouveau lien.");
        }
      }
      
      console.log("Appel à supabase.auth.updateUser pour mise à jour du mot de passe");
      
      const { error } = await supabase.auth.updateUser({
        password: newPassword
      });
      
      if (error) {
        console.error("Erreur mise à jour du mot de passe:", error);
        throw error;
      }
      
      console.log("Mot de passe mis à jour avec succès");
      return { error: null, success: true };
    } catch (error) {
      console.error('Erreur de mise à jour du mot de passe:', error);
      handleAuthError(error, 'update-password');
      return { error: error as Error, success: false };
    } finally {
      setLoading(false);
    }
  };
  
  return { resetPassword, updatePassword };
};
