
import { useCallback } from 'react';
import { useErrorHandling } from '@/hooks/useErrorHandling';

export const useAuthError = () => {
  const { error, handleError: errorHandler, clearError } = useErrorHandling({
    showToast: false,
  });

  const handleAuthError = useCallback((err: any, context: string) => {
    const errorMessage = err instanceof Error ? err.message : String(err);
    console.error(`Auth error (${context}):`, err);
    errorHandler(err, context);
    return errorMessage;
  }, [errorHandler]);

  return {
    error,
    handleAuthError,
    clearError
  };
};
