
import { useCallback, useRef, useEffect } from 'react';
import { User, UserRole } from '@/types/user';
import { useToast } from '@/hooks/use-toast';
import { useUserStorage } from '@/hooks/useUserStorage';
import { authSignUp } from '@/services/authService';

const ADMIN_EMAIL = 'direction@nova-aps.com';

export const useSignUp = (
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  resetSessionError: () => void,
  handleAuthError: (error: any, context: string) => string
) => {
  const { toast } = useToast();
  const { saveUser } = useUserStorage();
  // Add mounted ref to prevent state updates after unmounting
  const isMountedRef = useRef(true);
  
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const signUp = useCallback(async (email: string, password: string, role: UserRole) => {
    try {
      setLoading(true);
      resetSessionError();
      
      console.log("Attempting signup with:", { email, role });
      
      // Only prevent admin email registration, not role adjustment
      if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        const errorMsg = "Cette adresse email ne peut pas être utilisée pour l'inscription";
        
        if (isMountedRef.current) {
          toast({
            variant: "destructive",
            title: "Inscription échouée",
            description: errorMsg
          });
        }
        
        return { error: new Error(errorMsg), user: null };
      }
      
      // Never allow 'guest' role
      if (role === 'guest') {
        role = 'homeowner';
        console.log("Rôle 'guest' converti automatiquement en 'homeowner'");
      }
      
      // Allow user to choose their role, except for admin which requires special handling
      let requestedRole = role;
      if (role === "admin") {
        requestedRole = "homeowner";
        console.log("Admin role requested but adjusted to homeowner - admin role requires approval");
      }
      
      // Stocker le rôle demandé pour le récupérer après confirmation de l'email
      localStorage.setItem('pendingRole', requestedRole);
      console.log("Rôle demandé stocké temporairement:", requestedRole);
      
      const { error, user: authUser } = await authSignUp(email, password, requestedRole);

      if (error) {
        if (isMountedRef.current) {
          handleAuthError(error, 'sign-up');
          toast({
            variant: "destructive",
            title: "Inscription échouée",
            description: error.message
          });
        }
        return { error, user: null };
      }

      if (authUser && isMountedRef.current) {
        try {
          console.log("Creating profile for:", authUser.id);
          
          // Stocker explicitement le rôle demandé avec l'ID utilisateur pour le récupérer après confirmation
          localStorage.setItem('tempUserRole_' + authUser.id, JSON.stringify({
            role: requestedRole,
            email: email
          }));
          console.log("Rôle temporaire stocké avec ID utilisateur:", requestedRole);
          
          // Create user with the requested role (except admin)
          const userData: User = {
            id: authUser.id,
            email: email,
            role: requestedRole,
            createdAt: new Date(),
          };

          setUser(userData);
          saveUser(userData);
          resetSessionError();

          console.log("User created successfully:", userData);
          
          if (isMountedRef.current) {
            let successMessage = "Votre compte a été créé avec succès";
            
            if (role === "craftsman") {
              successMessage = "Votre compte artisan a été créé. Un administrateur validera votre profil prochainement.";
            }
            
            toast({
              title: "Compte créé",
              description: successMessage
            });
          }
          
          return { error: null, user: userData };
        } catch (profileError) {
          if (isMountedRef.current) {
            handleAuthError(profileError, 'profile-creation');
          }
          return { error: profileError as Error, user: null };
        }
      }
      
      return { error: new Error('Utilisateur non créé ou vérifiez votre email pour confirmer'), user: null };
    } catch (error) {
      if (isMountedRef.current) {
        handleAuthError(error, 'sign-up-unexpected');
      }
      return { error: error as Error, user: null };
    } finally {
      if (isMountedRef.current) {
        setLoading(false);
      }
    }
  }, [handleAuthError, resetSessionError, saveUser, setLoading, setUser, toast]);

  return { signUp };
};
