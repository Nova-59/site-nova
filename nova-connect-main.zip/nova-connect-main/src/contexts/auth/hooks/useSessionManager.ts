
import { useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { Session } from '@supabase/supabase-js';

/**
 * Hook to manage the current session
 */
export function useSessionManager() {
  /**
   * Get the current Supabase session
   */
  const getSession = useCallback(async (): Promise<Session | null> => {
    try {
      const { data, error } = await supabase.auth.getSession();
      if (error) {
        console.error("Error getting session:", error);
        return null;
      }
      
      // Traçage plus détaillé pour aider au diagnostic
      if (data && data.session) {
        console.log("Session active trouvée:", data.session.user?.email);
        // Vérifier l'état des tokens
        const now = Math.floor(Date.now() / 1000);
        const expiresAt = data.session.expires_at || 0;
        const timeLeft = expiresAt - now;
        console.log(`Le token expire dans ${timeLeft} secondes`);
      } else {
        console.log("Aucune session active trouvée");
      }
      
      return data.session;
    } catch (error) {
      console.error("Exception getting session:", error);
      return null;
    }
  }, []);

  return {
    getSession
  };
}
