
import { useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { User } from '@/types/user';

/**
 * Hook to handle authentication state change listener
 */
export function useAuthStateListener(
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  setSupabaseInitialized: (initialized: boolean) => void,
  removeUser: () => boolean,
  resetSessionError: () => void,
  resetRefreshAttempts: () => void,
  handleAuthError: (error: any, context: string) => string,
  refreshSession: () => Promise<any>
) {
  /**
   * Set up the auth state change listener
   */
  const setupAuthListener = useCallback((isMounted: { current: boolean }) => {
    // Set up the event subscription
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log("Auth state changed:", event, session?.user?.email);
        
        if (!isMounted.current) return;
        
        // Add a delay to avoid multiple triggers
        await new Promise(resolve => setTimeout(resolve, 300));
        
        try {
          setLoading(true);
          setSupabaseInitialized(true);
          
          if (event === 'SIGNED_OUT') {
            if (isMounted.current) {
              removeUser();
              setUser(null);
              resetSessionError();
              resetRefreshAttempts();
            }
          } else if (session?.user && (event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED')) {
            // Refresh session only for relevant events
            await refreshSession();
          } else {
            // Important: mettre fin à l'état de chargement pour les autres événements aussi
            setLoading(false);
          }
        } catch (error) {
          if (isMounted.current) {
            handleAuthError(error, 'auth-state-change');
          }
        } finally {
          // Assurez-vous que loading est toujours mis à false, même en cas d'erreur
          if (isMounted.current) {
            setLoading(false);
          }
        }
      }
    );

    return subscription;
  }, [
    handleAuthError,
    refreshSession,
    removeUser,
    resetRefreshAttempts,
    resetSessionError,
    setLoading,
    setSupabaseInitialized,
    setUser
  ]);

  return {
    setupAuthListener
  };
}
