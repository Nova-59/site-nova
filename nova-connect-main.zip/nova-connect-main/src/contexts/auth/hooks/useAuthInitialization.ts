
import { useRef, useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { User } from '@/types/user';
import { AUTH_LOADING_TIMEOUT } from '../constants';

/**
 * Hook to handle authentication initialization logic
 */
export function useAuthInitialization(
  setUser: (user: User | null) => void,
  setLoading: (loading: boolean) => void,
  setSupabaseInitialized: (initialized: boolean) => void,
  handleAuthError: (error: any, context: string) => string,
  loadUserFromStorage: () => { user: User | null; error: Error | null },
  removeUser: () => boolean,
  processUserProfile: (userId: string, email: string) => Promise<User | null>,
  refreshSession: () => Promise<any>
) {
  // Reference to track if initialization has already been performed
  const authInitializedRef = useRef(false);

  /**
   * Initialize authentication state
   */
  const initializeAuth = useCallback(async (isMounted: boolean) => {
    // Avoid multiple initializations
    if (authInitializedRef.current) {
      return;
    }
    
    authInitializedRef.current = true;
    
    try {
      setLoading(true);
      
      // Load user from local storage first
      const { user: storedUser, error: storageError } = loadUserFromStorage();
      
      if (storedUser && isMounted) {
        console.log("User found in local storage, using temporarily:", storedUser);
        setUser(storedUser);
      }
      
      if (storageError && isMounted) {
        console.warn("Storage error:", storageError);
      }
      
      // Check Supabase session (once only)
      try {
        const { data } = await supabase.auth.getSession();
        console.log("Supabase initial session check:", data.session ? "Session exists" : "No session");
        
        if (isMounted) {
          setSupabaseInitialized(true);
        }
        
        // If we have a session, refresh user data
        if (data.session && data.session.user) {
          // Add a delay to avoid simultaneous executions
          await new Promise(resolve => setTimeout(resolve, 100));
          
          // Make sure we're still mounted before proceeding
          if (isMounted) {
            await refreshSession();
          }
        } else {
          // No active session, ensure user is logged out
          removeUser();
          if (isMounted) {
            setUser(null);
            setLoading(false); // Explicitly end loading state
          }
        }
      } catch (error) {
        console.error("Error during Supabase initialization check:", error);
        if (isMounted) {
          setSupabaseInitialized(true);
          handleAuthError(error, 'auth-init');
          setLoading(false); // Explicitly end loading state
        }
      }
    } catch (error) {
      if (isMounted) {
        handleAuthError(error, 'auth-init');
        removeUser();
        setUser(null);
        setLoading(false); // Explicitly end loading state
      }
    } finally {
      if (isMounted) {
        // For more safety, always disable loading state at the end
        setLoading(false);
      }
    }
  }, [
    handleAuthError,
    loadUserFromStorage,
    processUserProfile,
    refreshSession,
    removeUser,
    setLoading,
    setSupabaseInitialized,
    setUser
  ]);

  /**
   * Set up a safety timeout to prevent UI blocking
   */
  const setupLoadingTimeout = useCallback((isMounted: boolean) => {
    return setTimeout(() => {
      if (isMounted) {
        console.log("Auth loading timeout reached, forcing loading state to false");
        setLoading(false);
        setSupabaseInitialized(true);
      }
    }, AUTH_LOADING_TIMEOUT);
  }, [setLoading, setSupabaseInitialized]);

  return {
    initializeAuth,
    setupLoadingTimeout,
    authInitializedRef
  };
}
