
import { createContext, useContext, useEffect, ReactNode, useRef } from 'react';
import { supabase } from '@/lib/supabase-client';
import { AuthContextType } from './types';
import { useAuthState } from './useAuthState';
import { useAuthMethods } from './useAuthMethods';
import { useSessionRefresh } from './useSessionRefresh';
import { useUserStorage } from '@/hooks/useUserStorage';
import { useAuthInitialization } from './hooks/useAuthInitialization';
import { useAuthStateListener } from './hooks/useAuthStateListener';
import { useSessionManager } from './hooks/useSessionManager';

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const {
    user,
    setUser,
    loading,
    setLoading,
    sessionError,
    supabaseInitialized,
    setSupabaseInitialized,
    resetSessionError,
    handleAuthError,
    processUserProfile,
    error,
    refreshAttempts,
    incrementRefreshAttempt,
    resetRefreshAttempts
  } = useAuthState();

  const {
    signIn, 
    signUp, 
    signOut, 
    updateUserRole,
    resetPassword,
    updatePassword
  } = useAuthMethods(
    setUser,
    setLoading,
    resetSessionError,
    handleAuthError,
    processUserProfile
  );

  const { refreshSession } = useSessionRefresh(
    setUser,
    setLoading,
    setSupabaseInitialized,
    resetSessionError,
    handleAuthError,
    processUserProfile,
    supabaseInitialized,
    refreshAttempts,
    incrementRefreshAttempt,
    resetRefreshAttempts
  );

  const { 
    loadUserFromStorage, 
    removeUser, 
    storageError 
  } = useUserStorage();

  // Use our new hooks
  const { initializeAuth, setupLoadingTimeout, authInitializedRef } = useAuthInitialization(
    setUser,
    setLoading,
    setSupabaseInitialized,
    handleAuthError,
    loadUserFromStorage,
    removeUser,
    processUserProfile,
    refreshSession
  );

  const { setupAuthListener } = useAuthStateListener(
    setUser,
    setLoading,
    setSupabaseInitialized,
    removeUser,
    resetSessionError,
    resetRefreshAttempts,
    handleAuthError,
    refreshSession
  );

  const { getSession } = useSessionManager();

  // Reference to track component mount state
  const isMounted = useRef(true);

  useEffect(() => {
    // Set up the auth listener and initialization
    const loadingTimeoutId = setupLoadingTimeout(isMounted.current);
    
    // Initialize auth once
    initializeAuth(isMounted.current);
    
    // Set up the auth state listener
    const subscription = setupAuthListener(isMounted);

    return () => {
      isMounted.current = false;
      clearTimeout(loadingTimeoutId);
      subscription.unsubscribe();
    };
  }, [
    initializeAuth,
    setupLoadingTimeout,
    setupAuthListener
  ]);

  // Handle storage errors
  useEffect(() => {
    if (storageError) {
      handleAuthError(storageError, 'storage-error');
    }
  }, [storageError, handleAuthError]);

  return (
    <AuthContext.Provider value={{ 
      user, 
      session: null, // Session will be retrieved if needed via getSession
      loading, 
      error,
      sessionError,
      signIn, 
      signUp, 
      signOut, 
      updateUserRole,
      refreshSession,
      resetPassword,
      updatePassword
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used inside an AuthProvider');
  }
  return context;
}
