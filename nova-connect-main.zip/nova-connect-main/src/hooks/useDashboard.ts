
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { ErrorSeverity } from "@/hooks/useErrorHandling";

export function useDashboard() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [searchParams] = useSearchParams();
  const tabParam = searchParams.get("tab");
  const [activeTab, setActiveTab] = useState(tabParam || "overview");
  const [error, setError] = useState<{ message: string; severity: ErrorSeverity } | null>(null);

  // Log component rendering
  useEffect(() => {
    console.log("Dashboard hook initialized", { 
      user: user?.email, 
      role: user?.role, 
      loading, 
      path: window.location.pathname 
    });
  }, [user, loading]);

  // Update active tab when URL param changes
  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam);
    }
  }, [tabParam]);

  // Handle authentication and authorization
  useEffect(() => {
    if (!loading) {
      if (!user) {
        console.log("No user in Dashboard, redirecting to /auth");
        toast({
          title: "Accès non autorisé",
          description: "Vous devez être connecté pour accéder à votre tableau de bord.",
          variant: "destructive",
        });
        navigate("/auth");
      } else if (user.role === "guest") {
        console.log("Guest user trying to access dashboard, redirecting to /projects/submit");
        toast({
          title: "Accès limité",
          description: "En tant qu'invité, vous pouvez uniquement soumettre des projets.",
          variant: "default"
        });
        navigate("/projects/submit");
      }
    }
  }, [user, loading, navigate, toast]);

  // Handle tab changes
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    navigate(`/dashboard?tab=${value}`);
  };

  return {
    user,
    loading,
    activeTab,
    handleTabChange,
    error
  };
}
