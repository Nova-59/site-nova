
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Project } from "@/types/project";
import { mockProjects } from "@/lib/mock-projects";
import { useToast } from "@/hooks/use-toast";
import { getCurrentUser } from "@/lib/mock-api";
import { User } from "@/types/user";
import { ErrorSeverity } from "@/hooks/useErrorHandling";

export function useProjectDetail(projectId?: string) {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<{ message: string; severity: ErrorSeverity } | null>(null);
  const currentUser = getCurrentUser() as User | null;
  
  // Fetch project data
  useEffect(() => {
    if (!projectId) {
      setError({
        message: "Identifiant de projet manquant",
        severity: "error"
      });
      return;
    }

    const fetchProject = () => {
      setIsLoading(true);
      setError(null);
      
      try {
        // Simulate API fetch with a slight delay
        setTimeout(() => {
          const foundProject = mockProjects.find(p => p.id === projectId);
          
          if (foundProject) {
            setProject(foundProject);
          } else {
            setError({
              message: "Le projet que vous recherchez n'existe pas.",
              severity: "error"
            });
            toast({
              variant: "destructive",
              title: "Projet introuvable",
              description: "Le projet que vous recherchez n'existe pas.",
            });
            navigate("/dashboard");
          }
          
          setIsLoading(false);
        }, 500);
      } catch (err) {
        setError({
          message: "Erreur lors du chargement du projet",
          severity: "error"
        });
        setIsLoading(false);
      }
    };
    
    fetchProject();
  }, [projectId, navigate, toast]);

  // Determine user roles and access
  const isOwner = currentUser?.id === project?.ownerId;
  const isCraftsman = currentUser?.role === "craftsman";
  const hasAcceptedCraftsman = project?.craftsmanId !== undefined;

  // Handle taking over a project
  const handleTakeProject = () => {
    toast({
      title: "Projet pris en charge",
      description: "Vous avez pris en charge ce projet avec succès.",
    });
    // Implement actual project takeover logic here
  };

  // Define the default tab based on user role and project status
  let defaultTab = "artisans";
  if (project?.status === "in_progress" || project?.status === "completed") {
    defaultTab = "progress";
  } else if (project?.craftsmanId && (isOwner || currentUser?.id === project?.craftsmanId)) {
    defaultTab = "messages";
  }

  return {
    project,
    isLoading,
    error,
    currentUser,
    isOwner,
    isCraftsman,
    hasAcceptedCraftsman,
    handleTakeProject,
    defaultTab
  };
}
