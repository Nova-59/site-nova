
import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/lib/supabase-client";
import { useErrorHandling } from "./useErrorHandling";
import { useToast } from "./use-toast";

type TableName = "profiles" | "projects" | "project_bids";

interface UseRlsPolicyOptions {
  tableName: TableName;
  showToast?: boolean;
  onErrorRedirect?: string;
}

/**
 * Hook pour vérifier les politiques RLS de manière cohérente
 */
export function useRlsPolicy({ 
  tableName,
  showToast = true,
  onErrorRedirect
}: UseRlsPolicyOptions) {
  const [isChecking, setIsChecking] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const { handleError, error, clearError } = useErrorHandling({ 
    showToast: showToast, 
    defaultSeverity: "warning" 
  });
  const { toast } = useToast();

  const checkAccess = useCallback(async () => {
    try {
      setIsChecking(true);
      clearError();
      
      // Tenter une requête simple pour vérifier l'accès
      const { error: accessError } = await supabase
        .from(tableName)
        .select('id')  // Only select the ID to minimize data transfer
        .limit(1);
      
      if (accessError) {
        console.error(`RLS policy check failed for ${tableName}:`, accessError);
        handleError(accessError, `rls-policy-${tableName}`, "warning");
        setHasAccess(false);
        
        if (showToast) {
          toast({
            variant: "destructive",
            title: "Problème d'autorisation",
            description: `Vous n'avez pas les permissions nécessaires pour accéder à ces données (${tableName}).`
          });
        }
        
        return false;
      }
      
      setHasAccess(true);
      return true;
    } catch (err) {
      console.error("RLS check error:", err);
      handleError(err, "rls-policy-check", "error");
      setHasAccess(false);
      return false;
    } finally {
      setIsChecking(false);
    }
  }, [tableName, handleError, clearError, toast, showToast]);

  useEffect(() => {
    checkAccess();
  }, [checkAccess]);

  return {
    isChecking,
    hasAccess,
    error,
    checkAccess
  };
}
