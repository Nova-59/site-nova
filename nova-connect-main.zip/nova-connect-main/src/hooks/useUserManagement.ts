
import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useUserList } from "./user/useUserList";
import { useUserPagination } from "./user/useUserPagination";
import { useUserRoleManagement } from "./user/useUserRoleManagement";
import { useUserDeletion } from "./user/useUserDeletion";
import { useUserCreation } from "./user/useUserCreation";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { UserRole } from "@/types/user";

export function useUserManagement() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [itemsPerPage] = useState(5);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  
  // Vérification des autorisations
  useEffect(() => {
    if (!authLoading) {
      // Utilisateur non connecté ou non admin
      if (!user || user.role !== "admin") {
        console.log("Non-admin trying to access UserManagement, redirecting...");
        toast({
          variant: "destructive",
          title: "Accès non autorisé",
          description: "Vous n'avez pas les permissions pour accéder à cette page."
        });
        navigate("/dashboard");
        setIsAuthorized(false);
      } else {
        setIsAuthorized(true);
      }
      setIsInitializing(false);
    }
  }, [user, authLoading, navigate, toast]);
  
  // N'initialiser les hooks que si l'utilisateur est autorisé
  const { 
    users, 
    isLoading: isUserListLoading, 
    setUsers,
    error: userListError 
  } = useUserList(isAuthorized);
  
  const { 
    paginatedUsers, 
    currentPage, 
    totalPages, 
    handlePageChange, 
    setTotalPages 
  } = useUserPagination(users, itemsPerPage);
  
  const { handleRoleChange, isUpdatingRole } = useUserRoleManagement(setUsers);
  const { handleDeleteUser, isDeleting } = useUserDeletion(setUsers);
  const { createUser, isCreating } = useUserCreation(setUsers, itemsPerPage, setTotalPages);

  // État de chargement global
  const isLoading = authLoading || isInitializing || isUserListLoading || isUpdatingRole || isDeleting || isCreating;

  return {
    user,
    users,
    isLoading,
    isAuthorized,
    userListError,
    handleRoleChange,
    paginatedUsers,
    currentPage,
    totalPages,
    handlePageChange,
    handleDeleteUser,
    createUser
  };
}
