
/**
 * Hook pour gérer le profil utilisateur
 * S'occupe de charger, créer et mettre à jour les profils utilisateurs dans Supabase
 */
import { useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase-client';
import { UserRole } from '@/types/user';

export function useUserProfile() {
  const [profile, setProfile] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);

  // Charger le profil utilisateur depuis Supabase
  const loadUserProfile = useCallback(async (userId: string) => {
    try {
      setLoading(true);
      setError(null);
      
      console.log("Chargement du profil pour:", userId);
      
      // Récupérer le profil depuis Supabase
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();
      
      if (error) {
        console.error("Erreur lors du chargement du profil:", error);
        throw error;
      }
      
      console.log("Profil chargé:", data);
      setProfile(data);
      
      return data;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
      console.error("Erreur lors du chargement du profil:", errorMsg);
      setError(err instanceof Error ? err : new Error(String(err)));
      setProfile(null);
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Créer un nouveau profil utilisateur
  const createUserProfile = useCallback(async (userId: string, email: string, role: UserRole = 'homeowner') => {
    try {
      setLoading(true);
      setError(null);
      
      console.log("Création du profil pour:", userId, email, role);
      
      // Sécurité supplémentaire pour les rôles
      let safeRole: UserRole = role;
      if (role === 'admin' || role === 'estimator') {
        safeRole = 'homeowner';
        console.log("Rôle ajusté à 'homeowner' pour la sécurité");
      }
      
      const ADMIN_EMAIL = 'direction@nova-aps.com';
      const CRAFTSMAN_EMAIL = 'skyguard.couv@gmail.com';
      
      // Exception pour les administrateurs et artisans connus
      if (email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
        safeRole = 'admin';
      } else if (email.toLowerCase() === CRAFTSMAN_EMAIL.toLowerCase()) {
        safeRole = 'craftsman';
      }
      
      // Création du profil dans Supabase
      const profileData = {
        id: userId,
        email: email,
        role: safeRole,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      
      const { data, error } = await supabase
        .from('profiles')
        .insert(profileData)
        .select();
      
      if (error) {
        console.error("Erreur lors de la création du profil:", error);
        throw error;
      }
      
      const newProfile = data?.[0] || profileData;
      console.log("Profil créé:", newProfile);
      
      setProfile(newProfile);
      return newProfile;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
      console.error("Erreur lors de la création du profil:", errorMsg);
      setError(err instanceof Error ? err : new Error(String(err)));
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  // Mettre à jour le profil utilisateur
  const updateUserProfile = useCallback(async (userId: string, profileData: Partial<any>) => {
    try {
      setLoading(true);
      setError(null);
      
      console.log("Mise à jour du profil pour:", userId, profileData);
      
      // Ajouter la date de mise à jour
      const updatedData = {
        ...profileData,
        updated_at: new Date().toISOString()
      };
      
      // Mise à jour dans Supabase
      const { data, error } = await supabase
        .from('profiles')
        .update(updatedData)
        .eq('id', userId)
        .select();
      
      if (error) {
        console.error("Erreur lors de la mise à jour du profil:", error);
        throw error;
      }
      
      const updatedProfile = data?.[0] || null;
      
      if (updatedProfile) {
        console.log("Profil mis à jour:", updatedProfile);
        setProfile(updatedProfile);
      }
      
      return updatedProfile;
    } catch (err) {
      const errorMsg = err instanceof Error ? err.message : 'Erreur inconnue';
      console.error("Erreur lors de la mise à jour du profil:", errorMsg);
      setError(err instanceof Error ? err : new Error(String(err)));
      return null;
    } finally {
      setLoading(false);
    }
  }, []);

  return {
    profile,
    loading,
    error,
    loadUserProfile,
    createUserProfile,
    updateUserProfile
  };
}
