
import { useState } from "react";
import { supabase } from "@/lib/supabase-client";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Project, ProjectCategory } from "@/types/project";

export function useProjectSubmission() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();
  const navigate = useNavigate();

  const submitProject = async (formData: {
    title: string;
    description: string;
    category: string;
    address: string;
    city: string;
    postalCode: string;
    images: File[];
  }) => {
    if (!user) {
      toast({
        variant: "destructive",
        title: "Vous devez être connecté",
        description: "Veuillez vous connecter pour soumettre un projet.",
      });
      navigate("/auth");
      return;
    }

    setIsSubmitting(true);

    try {
      // Préparer les données du projet
      const shortDescription = formData.description.substring(0, 100) + 
        (formData.description.length > 100 ? '...' : '');
      
      // Créer l'objet projet à insérer - Assurez-vous d'utiliser les données de l'utilisateur connecté
      const projectObject = {
        title: formData.title,
        description: formData.description,
        short_description: shortDescription,
        category: formData.category.toLowerCase().replace(/[éèê]/g, 'e') as ProjectCategory,
        location: {
          city: formData.city,
          postalCode: formData.postalCode,
          address: formData.address,
          region: "Non spécifié"
        },
        budget: {
          min: 0,
          max: 0,
          currency: "EUR"
        },
        homeowner_id: user.id, // Important: utilisez l'ID de l'utilisateur actuel
        status: "pending",
        is_published: false
      };
      
      console.log("Soumission du projet avec l'ID utilisateur:", user.id);
      
      // Étape 1: Insertion du projet
      const { data: insertData, error: insertError } = await supabase
        .from('projects')
        .insert(projectObject)
        .select('id');
        
      if (insertError) {
        console.error("Erreur lors de l'insertion du projet:", insertError);
        throw insertError;
      }
      
      let projectId: string | null = null;
      
      // Si l'insertion a retourné les données, on les utilise directement
      if (insertData && insertData.length > 0) {
        projectId = insertData[0].id;
        console.log("Projet créé avec ID:", projectId);
      } else {
        // Si l'insertion n'a pas retourné de données, on fait une requête séparée
        const { data: recentProjects, error: selectError } = await supabase
          .from('projects')
          .select('id')
          .eq('homeowner_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1);
          
        if (selectError) {
          console.error("Erreur lors de la récupération du projet:", selectError);
          throw selectError;
        }
        
        if (!recentProjects || recentProjects.length === 0) {
          throw new Error("Aucune donnée retournée après la création du projet");
        }

        projectId = recentProjects[0].id;
        console.log("Projet récupéré avec ID:", projectId);
      }
      
      // Upload des images si disponibles
      if (formData.images.length > 0 && projectId) {
        const imagePromises = formData.images.map(async (image, index) => {
          const fileExt = image.name.split('.').pop();
          const fileName = `${projectId}/${index}-${Date.now()}.${fileExt}`;
          const filePath = `projects/${fileName}`;

          const { error: uploadError } = await supabase.storage
            .from('project-images')
            .upload(filePath, image);

          if (uploadError) {
            console.error("Erreur lors du téléchargement de l'image:", uploadError);
            throw uploadError;
          }

          // Obtenir l'URL publique de l'image
          const { data: publicURL } = supabase.storage
            .from('project-images')
            .getPublicUrl(filePath);

          return publicURL?.publicUrl || filePath;
        });

        try {
          const imageUrls = await Promise.all(imagePromises);
          console.log("Images téléchargées avec succès:", imageUrls.length);

          // Mettre à jour le projet avec les URLs des images
          const { error: updateError } = await supabase
            .from('projects')
            .update({ images: imageUrls })
            .eq('id', projectId);

          if (updateError) {
            console.error("Erreur lors de la mise à jour des images du projet:", updateError);
            throw updateError;
          }
        } catch (imageError) {
          console.error("Erreur lors du traitement des images:", imageError);
          // Continue even if images fail
        }
      }

      toast({
        title: "Projet soumis avec succès",
        description: "Un métreur va vous contacter pour planifier une visite.",
      });

      navigate("/dashboard");
    } catch (error) {
      console.error("Erreur lors de la soumission du projet:", error);
      toast({
        variant: "destructive",
        title: "Erreur lors de la soumission",
        description: "Veuillez réessayer plus tard.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return {
    isSubmitting,
    submitProject
  };
}
