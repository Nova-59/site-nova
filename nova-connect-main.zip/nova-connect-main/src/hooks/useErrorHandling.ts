
/**
 * Hook pour gérer les erreurs de manière cohérente
 * Centralise la gestion des erreurs avec options de toasts
 */
import { useState, useCallback } from 'react';
import { useToast } from './use-toast';

export type ErrorSeverity = 'info' | 'warning' | 'error' | 'success' | 'fatal';

export interface ErrorHandlingOptions {
  showToast?: boolean;
  defaultSeverity?: ErrorSeverity;
  logToConsole?: boolean;
}

export function useErrorHandling(options: ErrorHandlingOptions = {}) {
  const { showToast = true, defaultSeverity = 'error', logToConsole = false } = options;
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  const handleError = useCallback((
    error: unknown, 
    context: string = 'unknown', 
    severity: ErrorSeverity = defaultSeverity
  ) => {
    // Traitement de l'erreur
    const isErrorObj = error instanceof Error;
    const errorMsg = isErrorObj ? error.message : String(error);
    const errorObj = isErrorObj ? error : new Error(errorMsg);
    
    if (logToConsole) {
      console.error(`Erreur [${context}]:`, errorObj);
    }
    
    setError(errorObj);
    
    // Afficher un toast si demandé
    if (showToast) {
      toast({
        variant: severity === 'error' || severity === 'fatal' ? 'destructive' : 'default',
        title: severity === 'error' || severity === 'fatal' ? 'Erreur' : 
               severity === 'warning' ? 'Attention' : 
               severity === 'info' ? 'Information' : 'Succès',
        description: errorMsg
      });
    }
    
    return { message: errorMsg, error: errorObj };
  }, [defaultSeverity, showToast, toast, logToConsole]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  return {
    error,
    handleError,
    clearError
  };
}
