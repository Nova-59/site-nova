
import { UserRole } from "@/types/user";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { Dispatch, SetStateAction, useState, useRef, useEffect } from "react";

export function useUserCreation(
  setUsers: React.Dispatch<React.SetStateAction<any[]>>, 
  itemsPerPage: number, 
  setTotalPages: Dispatch<SetStateAction<number>>
) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isCreating, setIsCreating] = useState(false);
  // Add a mount status ref to track if the component is mounted
  const isMountedRef = useRef(true);

  // Update mounted status on cleanup
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const createUser = async (email: string, password: string, role: UserRole) => {
    try {
      if (!isMountedRef.current) return;
      
      setIsCreating(true);
      
      if (!user) {
        throw new Error("Utilisateur non authentifié");
      }
      
      // Vérification stricte: seul un admin peut créer des utilisateurs
      if (user.role !== 'admin') {
        if (isMountedRef.current) {
          toast({
            variant: "destructive",
            title: "Action non autorisée",
            description: "Seul un administrateur peut créer des utilisateurs."
          });
        }
        return;
      }
      
      console.log(`Creating new user with email ${email} and role ${role}`);
      
      // Create user in Auth
      const authResponse = await supabase.auth.signUp({
        email,
        password,
      });
      
      if ('error' in authResponse && authResponse.error) {
        throw authResponse.error;
      }
      
      if (!('data' in authResponse) || !authResponse.data.user) {
        throw new Error("Aucun utilisateur créé");
      }
      
      // Create profile with role
      const profileResponse = await supabase
        .from('profiles')
        .upsert({
          id: authResponse.data.user.id,
          email: authResponse.data.user.email,
          role: role,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        });
      
      if ('error' in profileResponse && profileResponse.error) {
        throw profileResponse.error;
      }
      
      // Refresh users list
      const fetchResponse = await supabase
        .from('profiles')
        .select('*');
      
      // Gérer la réponse de manière compatible avec le type
      let updatedData;
      let fetchError;
      
      if ('data' in fetchResponse && 'error' in fetchResponse) {
        updatedData = fetchResponse.data;
        fetchError = fetchResponse.error;
      } else {
        console.error("Unexpected response format:", fetchResponse);
        return;
      }
      
      if (fetchError) {
        throw fetchError;
      }
      
      // Only update state if component is still mounted
      if (isMountedRef.current && updatedData) {
        // Convertir les données Supabase en format User
        const fetchedUsers = updatedData.map((profile: any) => ({
          id: profile.id,
          email: profile.email,
          firstName: profile.first_name || "",
          lastName: profile.last_name || "",
          role: profile.role,
          createdAt: new Date(profile.created_at),
          address: profile.address || "",
          postalCode: profile.postal_code || "",
          city: profile.city || "",
          phoneNumber: profile.phone_number || "",
          bio: profile.bio || "",
          avatarUrl: profile.avatar_url || "",
          rating: profile.rating || 0,
          completedProjects: profile.completed_projects || 0,
          updatedAt: profile.updated_at ? new Date(profile.updated_at) : undefined
        }));
        
        setUsers(fetchedUsers);
        setTotalPages(Math.ceil(fetchedUsers.length / itemsPerPage));
      }
      
      if (isMountedRef.current) {
        toast({
          title: "Succès",
          description: `L'utilisateur ${email} a été créé avec le rôle ${role}.`
        });
      }
    } catch (error) {
      console.error("Failed to create user:", error);
      
      if (isMountedRef.current) {
        toast({
          variant: "destructive",
          title: "Erreur",
          description: `Impossible de créer l'utilisateur: ${(error as Error).message}`
        });
      }
    } finally {
      if (isMountedRef.current) {
        setIsCreating(false);
      }
    }
  };

  return { createUser, isCreating };
}
