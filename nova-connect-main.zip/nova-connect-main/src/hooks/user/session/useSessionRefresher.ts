
import { useAuth } from "@/contexts/AuthContext";
import { useState } from "react";
import { supabase } from "@/lib/supabase-client";

export interface SessionRefreshResult {
  success: boolean;
  sessionData?: any;
  error?: Error;
}

export function useSessionRefresher() {
  const { refreshSession } = useAuth();
  const [isRefreshing, setIsRefreshing] = useState(false);

  const attemptSessionRefresh = async (
    maxAttempts: number = 3,
    baseDelay: number = 500
  ): Promise<SessionRefreshResult> => {
    if (!refreshSession) {
      console.error("[SESSION] refreshSession not available");
      return { success: false, error: new Error("refreshSession not available") };
    }

    setIsRefreshing(true);
    
    try {
      let sessionAvailable = false;
      let sessionAttempts = 0;
      let lastError = null;
      let sessionData = null;
      
      while (!sessionAvailable && sessionAttempts < maxAttempts) {
        sessionAttempts++;
        console.log(`[SESSION] Tentative ${sessionAttempts}/${maxAttempts} de rafraîchissement de session`);
        
        try {
          // Forcer le rafraîchissement de la session
          await refreshSession();
          console.log("[SESSION] Session rafraîchie");
          
          // Attendre que les tokens se propagent
          const waitTime = baseDelay * sessionAttempts; // Augmenter le temps d'attente à chaque tentative
          console.log(`[SESSION] Attente de ${waitTime}ms pour propagation des tokens`);
          await new Promise(resolve => setTimeout(resolve, waitTime));
          
          // Vérifier si la session est disponible
          const { data, error } = await supabase.auth.getSession();
          
          if (error) {
            lastError = error;
            console.error("[SESSION] Erreur lors de la récupération de la session:", error);
            continue;
          }
          
          if (data && data.session) {
            console.log("[SESSION] Session active trouvée avec access token valide");
            sessionData = data;
            sessionAvailable = true;
            break;
          } else {
            console.warn("[SESSION] Pas de session active trouvée après rafraîchissement");
          }
        } catch (refreshError) {
          lastError = refreshError as Error;
          console.error(`[SESSION] Erreur lors de la tentative ${sessionAttempts}:`, refreshError);
        }
      }
      
      if (!sessionAvailable) {
        console.error("[ERREUR CRITIQUE] Impossible d'obtenir une session valide après plusieurs tentatives");
        return { 
          success: false, 
          error: new Error("Session non disponible pour effectuer la mise à jour")
        };
      }
      
      return { success: true, sessionData };
    } catch (error) {
      console.error("[SESSION] Erreur lors du rafraîchissement de la session:", error);
      return { success: false, error: error as Error };
    } finally {
      setIsRefreshing(false);
    }
  };

  return {
    attemptSessionRefresh,
    isRefreshing
  };
}
