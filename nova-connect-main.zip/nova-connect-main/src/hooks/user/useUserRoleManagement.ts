
import { UserRole } from "@/types/user";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { useSessionRefresher } from "./session/useSessionRefresher";
import { useRoleValidator } from "./roles/useRoleValidator";
import { useRoleUpdater } from "./roles/useRoleUpdater";
import { useLocalStorageUpdater } from "./storage/useLocalStorageUpdater";

export function useUserRoleManagement(setUsers: React.Dispatch<React.SetStateAction<any[]>>) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isUpdatingRole, setIsUpdatingRole] = useState(false);
  
  // Import utilities
  const { attemptSessionRefresh } = useSessionRefresher();
  const { validateAndTransformRole, canModifyRoles } = useRoleValidator();
  const { updateRoleViaRPC, updateRoleDirectly, verifyRoleUpdate } = useRoleUpdater();
  const { updateUserRoleInStorage } = useLocalStorageUpdater();

  const handleRoleChange = async (userId: string, newRole: UserRole) => {
    try {
      setIsUpdatingRole(true);

      // Log details to help with debugging
      console.log("====== DÉBUT DE LA FONCTION handleRoleChange ======");
      console.log("Paramètres reçus:", { userId, newRole });

      if (!user) {
        console.error("ERREUR: Utilisateur non authentifié");
        throw new Error("Utilisateur non authentifié");
      }
      
      // Strict validation: only admin can modify roles
      console.log("Vérification des permissions:", { userRole: user.role, isAdmin: user.role === 'admin' });
      if (!canModifyRoles(user.role)) {
        console.warn("Permission refusée: l'utilisateur n'est pas admin");
        toast({
          variant: "destructive",
          title: "Action non autorisée",
          description: "Seul un administrateur peut modifier les rôles des utilisateurs."
        });
        return;
      }
      
      // Validate and transform role if needed
      newRole = validateAndTransformRole(newRole);
      
      console.log(`[DÉMARRAGE] Mise à jour du rôle de l'utilisateur ${userId} vers ${newRole}`);
      
      // Refresh session to ensure we have valid tokens
      const { success: sessionSuccess, error: sessionError } = await attemptSessionRefresh(3, 500);
      
      if (!sessionSuccess) {
        console.error("[ERREUR CRITIQUE] Impossible d'obtenir une session valide:", sessionError);
        
        // Update UI anyway to avoid blocking in dev/test
        setUsers(prevUsers =>
          prevUsers.map(user =>
            user.id === userId ? { ...user, role: newRole } : user
          )
        );
        
        toast({
          variant: "destructive",
          title: "Erreur de session",
          description: "Impossible d'obtenir une session valide. Essayez de vous déconnecter puis reconnecter."
        });
        
        throw new Error("Session non disponible pour effectuer la mise à jour");
      }
      
      console.log("[SUPABASE] Session active confirmée, tentative de mise à jour du rôle");
      
      // Try RPC approach first (more secure)
      const { success: rpcSuccess } = await updateRoleViaRPC(userId, newRole);
      
      if (rpcSuccess) {
        // Update local state
        setUsers(prevUsers =>
          prevUsers.map(user =>
            user.id === userId ? { ...user, role: newRole } : user
          )
        );
        
        // Update localStorage if needed
        updateUserRoleInStorage(userId, newRole);
        
        toast({
          title: "Rôle mis à jour",
          description: `Le rôle de l'utilisateur a été changé à ${newRole}.`
        });
        
        console.log("====== FIN DE LA FONCTION handleRoleChange: SUCCÈS VIA RPC ======");
        return { success: true };
      }
      
      // If RPC failed, try direct update
      await new Promise(resolve => setTimeout(resolve, 500));
      const { success: directSuccess, error: directError } = await updateRoleDirectly(userId, newRole);
      
      if (!directSuccess) {
        console.error("[ERREUR SUPABASE] Mise à jour directe échouée:", directError);
        
        // Update local state anyway
        setUsers(prevUsers =>
          prevUsers.map(user =>
            user.id === userId ? { ...user, role: newRole } : user
          )
        );
        
        toast({
          variant: "destructive",
          title: "Mise à jour partielle",
          description: `La mise à jour peut avoir échoué côté serveur: ${directError?.message}`
        });
        
        throw directError || new Error("Erreur de mise à jour directe");
      }
      
      // Verify the update
      await verifyRoleUpdate(userId, newRole);
      
      // Update local state
      setUsers(prevUsers =>
        prevUsers.map(user =>
          user.id === userId ? { ...user, role: newRole } : user
        )
      );
      
      // Update localStorage if needed
      updateUserRoleInStorage(userId, newRole);
      
      toast({
        title: "Rôle mis à jour",
        description: `Le rôle de l'utilisateur a été changé à ${newRole}.`
      });
      
      console.log("====== FIN DE LA FONCTION handleRoleChange: SUCCÈS ======");
      
      return { success: true };
    } catch (error) {
      console.error("[ERREUR CRITIQUE] Échec de la mise à jour du rôle:", error);
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de mettre à jour le rôle de l'utilisateur."
      });
      console.log("====== FIN DE LA FONCTION handleRoleChange: ÉCHEC ======");
      return { success: false, error };
    } finally {
      setIsUpdatingRole(false);
    }
  };

  return { handleRoleChange, isUpdatingRole };
}
