
import { useState, useEffect } from "react";
import { User } from "@/types/user";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";

export function useUserList(isAuthorized = true) {
  const { user } = useAuth();
  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);
  const { toast } = useToast();

  // Debug logging
  useEffect(() => {
    console.log("UserList hook:", { user });
  }, [user]);

  // Fetch users from Supabase
  useEffect(() => {
    const fetchUsers = async () => {
      if (!user || user.role !== "admin" || !isAuthorized) return;
      
      setIsLoading(true);
      setError(null);
      
      try {
        // Récupérer les utilisateurs depuis Supabase
        const response = await supabase
          .from('profiles')
          .select('*');
        
        // Gérer la réponse de manière compatible avec le type
        let fetchedData;
        let fetchError;
        
        if ('data' in response && 'error' in response) {
          fetchedData = response.data;
          fetchError = response.error;
        } else {
          console.error("Unexpected response format:", response);
          setIsLoading(false);
          return;
        }
        
        if (fetchError) {
          console.error("Error fetching users:", fetchError);
          setError(new Error(fetchError.message));
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Impossible de récupérer la liste des utilisateurs."
          });
          setIsLoading(false);
          return;
        }
        
        if (fetchedData) {
          // Convertir les données Supabase en format User
          const fetchedUsers: User[] = fetchedData.map((profile: any) => ({
            id: profile.id,
            email: profile.email,
            firstName: profile.first_name || "",
            lastName: profile.last_name || "",
            role: profile.role,
            createdAt: new Date(profile.created_at),
            address: profile.address || "",
            postalCode: profile.postal_code || "",
            city: profile.city || "",
            phoneNumber: profile.phone_number || "",
            bio: profile.bio || "",
            avatarUrl: profile.avatar_url || "",
            rating: profile.rating || 0,
            completedProjects: profile.completed_projects || 0,
            updatedAt: profile.updated_at ? new Date(profile.updated_at) : undefined
          }));
          
          console.log("Users fetched from Supabase:", fetchedUsers);
          setUsers(fetchedUsers);
        }
      } catch (error) {
        console.error("Failed to fetch users:", error);
        setError(error as Error);
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Une erreur est survenue lors de la récupération des utilisateurs."
        });
      } finally {
        setIsLoading(false);
      }
    };

    if (user?.role === "admin" && isAuthorized) {
      fetchUsers();
    }
  }, [user, toast, isAuthorized]);

  return {
    users,
    isLoading,
    setUsers,
    error
  };
}
