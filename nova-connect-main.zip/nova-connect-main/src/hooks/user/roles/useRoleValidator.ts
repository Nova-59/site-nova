
import { UserRole } from "@/types/user";

export function useRoleValidator() {
  const validateAndTransformRole = (role: UserRole): UserRole => {
    // Ensure we never set role to 'guest'
    if (role === 'guest') {
      console.log("Conversion automatique du rôle 'guest' vers 'homeowner'");
      return 'homeowner';
    }
    return role;
  };
  
  const canModifyRoles = (userRole: UserRole | undefined): boolean => {
    return userRole === 'admin';
  };

  return {
    validateAndTransformRole,
    canModifyRoles
  };
}
