
import { supabase } from "@/lib/supabase-client";
import { UserRole } from "@/types/user";

interface RoleUpdateResult {
  success: boolean;
  data?: any;
  error?: Error;
}

export function useRoleUpdater() {
  const updateRoleViaRPC = async (userId: string, newRole: UserRole): Promise<RoleUpdateResult> => {
    try {
      console.log("[RPC] Tentative via fonction RPC admin_update_user_role");
      
      const { data, error } = await supabase
        .rpc('admin_update_user_role', { 
          p_user_id: userId, 
          p_role: newRole 
        });
      
      if (error) {
        console.warn("[RPC] Échec de l'appel RPC:", error);
        return { success: false, error: error };
      }
      
      console.log("[RPC] Mise à jour réussie via RPC");
      return { success: true, data };
    } catch (rpcCatchError) {
      console.error("[RPC] Exception lors de l'appel RPC:", rpcCatchError);
      return { success: false, error: rpcCatchError as Error };
    }
  };

  const updateRoleDirectly = async (userId: string, newRole: UserRole): Promise<RoleUpdateResult> => {
    try {
      console.log("[SUPABASE] Tentative via mise à jour directe de la table profiles");
      
      const { data, error } = await supabase
        .from('profiles')
        .update({ 
          role: newRole,
          updated_at: new Date().toISOString()
        })
        .eq('id', userId)
        .select();
      
      if (error) {
        console.error("[ERREUR SUPABASE] Mise à jour directe échouée:", error);
        return { success: false, error };
      }
      
      console.log("[SUPABASE] Mise à jour directe réussie:", data);
      return { success: true, data };
    } catch (error) {
      console.error("[SUPABASE] Exception lors de la mise à jour directe:", error);
      return { success: false, error: error as Error };
    }
  };

  const verifyRoleUpdate = async (userId: string, expectedRole: UserRole): Promise<boolean> => {
    try {
      const { data: verificationData } = await supabase
        .from('profiles')
        .select('id, role')
        .eq('id', userId)
        .single();
        
      console.log("[VÉRIFICATION] Profil après mise à jour:", { 
        roleActuel: verificationData?.role,
        roleVoulu: expectedRole,
        succès: verificationData?.role === expectedRole
      });
      
      return verificationData?.role === expectedRole;
    } catch (verifyError) {
      console.warn("[VÉRIFICATION] Impossible de vérifier le nouveau rôle:", verifyError);
      return false;
    }
  };

  return {
    updateRoleViaRPC,
    updateRoleDirectly,
    verifyRoleUpdate
  };
}
