
import { useState, useEffect } from "react";
import { User } from "@/types/user";

export function useUserPagination(users: User[], itemsPerPage = 5) {
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [paginatedUsers, setPaginatedUsers] = useState<User[]>([]);

  // Update paginated users when current page changes or users list changes
  useEffect(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    setPaginatedUsers(users.slice(startIndex, endIndex));
    setTotalPages(Math.ceil(users.length / itemsPerPage));
  }, [currentPage, users, itemsPerPage]);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  return {
    paginatedUsers,
    currentPage,
    totalPages,
    setTotalPages,
    handlePageChange
  };
}
