
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/lib/supabase";
import { useState } from "react";

export function useUserDeletion(setUsers: React.Dispatch<React.SetStateAction<any[]>>) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDeleting, setIsDeleting] = useState(false);

  const handleDeleteUser = async (userId: string) => {
    try {
      setIsDeleting(true);

      if (!user) {
        throw new Error("Utilisateur non authentifié");
      }
      
      // Vérification stricte: seul un admin peut supprimer des utilisateurs
      if (user.role !== 'admin') {
        toast({
          variant: "destructive",
          title: "Action non autorisée",
          description: "Seul un administrateur peut supprimer des utilisateurs."
        });
        return;
      }
      
      // Empêcher la suppression d'un admin
      const userToDelete = (await supabase.from('profiles').select('*').eq('id', userId).single()).data;
      if (userToDelete?.role === 'admin') {
        toast({
          variant: "destructive",
          title: "Action impossible",
          description: "Les comptes administrateurs ne peuvent pas être supprimés."
        });
        return;
      }
      
      console.log(`Deleting user ${userId}`);
      
      // Delete from Supabase
      const profilesQueryBuilder = supabase.from('profiles');
      // Vérifier si la méthode delete existe
      if (!('delete' in profilesQueryBuilder)) {
        console.error("Delete method not available in this context");
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Fonctionnalité de suppression non disponible."
        });
        return;
      }
      
      const response = (profilesQueryBuilder as any).delete().eq('id', userId);
      
      // Gérer la réponse de manière compatible avec le type
      let deleteError;
      
      if (response && typeof response.then === 'function') {
        const result = await response;
        if ('error' in result) {
          deleteError = result.error;
        }
      } else {
        console.error("Unexpected response format:", response);
        return;
      }
      
      if (deleteError) {
        throw deleteError;
      }
      
      // Update local state
      setUsers(prevUsers => prevUsers.filter(user => user.id !== userId));
      
      toast({
        title: "Succès",
        description: "L'utilisateur a été supprimé avec succès."
      });
    } catch (error) {
      console.error("Failed to delete user:", error);
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de supprimer l'utilisateur."
      });
    } finally {
      setIsDeleting(false);
    }
  };

  return { handleDeleteUser, isDeleting };
}
