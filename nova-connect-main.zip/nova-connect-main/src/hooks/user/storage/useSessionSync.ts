
import { useCallback } from 'react';
import { User } from '@/types/user';
import { supabase } from '@/lib/supabase-client';

/**
 * Hook for synchronizing with Supabase session
 */
export function useSessionSync() {
  /**
   * Synchronize with the current Supabase session
   */
  const syncWithSupabaseSession = useCallback(async (
    removeUserFn: () => boolean
  ): Promise<boolean> => {
    try {
      // Check the current Supabase session
      const { data, error } = await supabase.auth.getSession();
      
      if (error) {
        console.error("Error checking Supabase session:", error);
        removeUserFn(); // Clean local data on error
        return false;
      }
      
      if (!data.session || !data.session.user) {
        // No active session, clean localStorage
        console.log("No active Supabase session, cleaning local data");
        removeUserFn();
        return false;
      }
      
      return true;
    } catch (error) {
      console.error("Error syncing with Supabase session:", error);
      removeUserFn(); // In case of doubt, clean local data
      return false;
    }
  }, []);

  return {
    syncWithSupabaseSession
  };
}
