
import { useState, useCallback } from 'react';
import { User } from '@/types/user';
import { useErrorHandling } from '@/hooks/useErrorHandling';

/**
 * Core local storage operations for user data
 */
export function useLocalStorage() {
  const { handleError, error: storageError, clearError } = useErrorHandling({
    showToast: false,
    defaultSeverity: 'warning'
  });

  /**
   * Save data to localStorage with error handling
   */
  const saveToStorage = useCallback((key: string, data: any): boolean => {
    clearError();
    try {
      localStorage.setItem(key, JSON.stringify(data));
      return true;
    } catch (error) {
      handleError(error, `save-${key}-storage`, 'warning');
      return false;
    }
  }, [handleError, clearError]);

  /**
   * Load data from localStorage with error handling
   */
  const loadFromStorage = useCallback(<T>(key: string): { data: T | null; error: Error | null } => {
    clearError();
    try {
      const item = localStorage.getItem(key);
      if (!item) {
        return { data: null, error: null };
      }

      try {
        const parsedData = JSON.parse(item) as T;
        return { data: parsedData, error: null };
      } catch (e) {
        localStorage.removeItem(key); // Remove corrupt data
        const error = new Error(`Failed to parse ${key} data`);
        handleError(error, `parse-${key}-storage`, 'warning');
        return { data: null, error };
      }
    } catch (error) {
      const err = error instanceof Error ? error : new Error(`Could not access local storage for ${key}`);
      handleError(err, `access-${key}-storage`, 'error');
      return { data: null, error: err };
    }
  }, [handleError, clearError]);

  /**
   * Remove data from localStorage with error handling
   */
  const removeFromStorage = useCallback((key: string): boolean => {
    clearError();
    try {
      localStorage.removeItem(key);
      return true;
    } catch (error) {
      handleError(error, `remove-${key}-storage`, 'warning');
      return false;
    }
  }, [handleError, clearError]);

  return {
    saveToStorage,
    loadFromStorage,
    removeFromStorage,
    storageError
  };
}
