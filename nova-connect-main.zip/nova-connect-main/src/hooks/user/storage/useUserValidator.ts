
import { useCallback } from 'react';
import { User } from '@/types/user';

/**
 * Hook for validating user data
 */
export function useUserValidator() {
  /**
   * Validates user object has required fields
   */
  const isValidUserData = useCallback((user: any): boolean => {
    return !!user && !!user.id && !!user.email;
  }, []);

  /**
   * Validates if the stored user session is still valid
   */
  const isUserSessionValid = useCallback((userId: string, storedUser: User | null): boolean => {
    if (!storedUser || storedUser.id !== userId) {
      return false;
    }
    return true;
  }, []);

  /**
   * Verify if the stored user data is fresh enough to use
   */
  const isUserDataFresh = useCallback((storedAt: string | undefined, maxAgeMs: number = 24 * 60 * 60 * 1000): boolean => {
    if (!storedAt) return false;
    
    const storedDate = new Date(storedAt);
    const now = new Date();
    
    return now.getTime() - storedDate.getTime() <= maxAgeMs;
  }, []);

  return {
    isValidUserData,
    isUserSessionValid,
    isUserDataFresh
  };
}
