
import { useState, useEffect, useCallback } from 'react';
import { User } from '@/types/user';
import { useErrorHandling } from '@/hooks/useErrorHandling';
import { supabase } from '@/lib/supabase-client';
import { useUserStorageData } from './useUserStorageData';
import { useUserValidator } from './useUserValidator';
import { useSessionSync } from './useSessionSync';

/**
 * Main hook for managing user data in localStorage
 * with enhanced error handling, session validation and persistence
 */
export function useUserStorage() {
  const [isLoading, setIsLoading] = useState(true);
  const { handleError, error: storageError, clearError } = useErrorHandling({
    showToast: false,
    defaultSeverity: 'warning'
  });

  const {
    storedUser,
    setStoredUser,
    loadUserFromStorage,
    saveUser,
    removeUser
  } = useUserStorageData();

  const { isUserSessionValid } = useUserValidator();
  const { syncWithSupabaseSession } = useSessionSync();

  // Check if user session is valid
  const isSessionValid = useCallback((userId: string): boolean => {
    const { user } = loadUserFromStorage();
    return isUserSessionValid(userId, user);
  }, [loadUserFromStorage, isUserSessionValid]);

  // Initialize user from localStorage at component mount
  useEffect(() => {
    const initializeUser = async () => {
      try {
        setIsLoading(true);
        
        // Load stored user data
        const { user, error } = loadUserFromStorage();
        
        if (error) {
          console.error("Error loading user:", error);
        } else if (user) {
          console.log("User found in local storage, using temporarily");
          setStoredUser(user);
        }
        
        // Sync with Supabase session
        await syncWithSupabaseSession(removeUser);
      } catch (error) {
        handleError(error, "initialize-user-storage", "error");
        removeUser(); // Clean for safety
      } finally {
        setIsLoading(false);
      }
    };

    // Initialize on load
    initializeUser();
    
    // Listen for auth state changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event) => {
      console.log("Auth state changed in useUserStorage:", event);
      
      if (event === 'SIGNED_OUT') {
        console.log("Signout detected, cleaning local data");
        removeUser();
      } else if (event === 'SIGNED_IN') {
        syncWithSupabaseSession(removeUser);
      }
    });
    
    // Clean up listener
    return () => {
      subscription.unsubscribe();
    };
  }, [loadUserFromStorage, handleError, syncWithSupabaseSession, removeUser]);

  return {
    storedUser,
    saveUser,
    removeUser,
    loadUserFromStorage,
    isUserSessionValid: isSessionValid,
    isLoading,
    storageError: storageError?.message
  };
}
