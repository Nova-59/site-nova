
import { UserRole } from "@/types/user";

export function useLocalStorageUpdater() {
  const updateUserRoleInStorage = (userId: string, newRole: UserRole): boolean => {
    try {
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      if (currentUser && currentUser.id === userId) {
        currentUser.role = newRole;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        console.log("[STOCKAGE] LocalStorage mis à jour pour l'utilisateur courant");
        return true;
      }
      return false;
    } catch (storageError) {
      console.warn("[STOCKAGE] Erreur lors de la mise à jour du localStorage:", storageError);
      return false;
    }
  };

  return {
    updateUserRoleInStorage
  };
}
