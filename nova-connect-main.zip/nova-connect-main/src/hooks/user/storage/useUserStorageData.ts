
import { useState, useCallback, useEffect } from 'react';
import { User } from '@/types/user';
import { useLocalStorage } from './useLocalStorage';
import { useUserValidator } from './useUserValidator';

const USER_STORAGE_KEY = 'currentUser';
const MOCK_USER_KEY = 'mockUser';
const MAX_AGE_MS = 24 * 60 * 60 * 1000; // 24 hours

/**
 * Hook for handling user data operations
 */
export function useUserStorageData() {
  const [storedUser, setStoredUser] = useState<User | null>(null);
  const { saveToStorage, loadFromStorage, removeFromStorage } = useLocalStorage();
  const { isValidUserData, isUserDataFresh } = useUserValidator();

  /**
   * Load user from storage with validation
   */
  const loadUserFromStorage = useCallback((): { user: User | null; error: Error | null } => {
    // Check for mock user first (for tests)
    const { data: mockUser } = loadFromStorage<User>(MOCK_USER_KEY);
    if (mockUser) {
      console.warn("Mock user data found and removed");
      removeFromStorage(MOCK_USER_KEY);
    }
    
    // Get real user data
    const { data: userData, error } = loadFromStorage<{ storedAt?: string } & User>(USER_STORAGE_KEY);
    
    if (!userData) {
      return { user: null, error };
    }

    // Validate data format
    if (!isValidUserData(userData)) {
      removeFromStorage(USER_STORAGE_KEY); // Remove invalid data
      const validationError = new Error("Invalid user data in storage");
      return { user: null, error: validationError };
    }

    // Check freshness
    if (userData.storedAt && !isUserDataFresh(userData.storedAt, MAX_AGE_MS)) {
      console.warn("User data expired, removing");
      removeFromStorage(USER_STORAGE_KEY);
      return { user: null, error: null };
    }

    // Ensure createdAt is a Date object
    if (userData.createdAt && typeof userData.createdAt === 'string') {
      userData.createdAt = new Date(userData.createdAt);
    }

    return { user: userData, error };
  }, [loadFromStorage, removeFromStorage, isValidUserData, isUserDataFresh]);

  /**
   * Save user to storage with timestamp
   */
  const saveUser = useCallback((user: User): boolean => {
    if (!isValidUserData(user)) {
      console.warn("Attempted to save invalid user data");
      return false;
    }

    // Remove mock data
    removeFromStorage(MOCK_USER_KEY);
    
    // Add timestamp for freshness check
    const userData = {
      ...user,
      storedAt: new Date().toISOString()
    };
    
    const success = saveToStorage(USER_STORAGE_KEY, userData);
    if (success) {
      setStoredUser(user);
    }
    return success;
  }, [saveToStorage, removeFromStorage, isValidUserData]);

  /**
   * Remove user from storage
   */
  const removeUser = useCallback((): boolean => {
    removeFromStorage(USER_STORAGE_KEY);
    removeFromStorage(MOCK_USER_KEY);
    setStoredUser(null);
    return true;
  }, [removeFromStorage]);

  return {
    storedUser,
    setStoredUser,
    loadUserFromStorage,
    saveUser,
    removeUser
  };
}
