
/**
 * Re-export for backward compatibility
 * This ensures existing code continues to work while we transition to the new structure
 */
export { useUserStorage } from './user/storage/useUserStorage';
