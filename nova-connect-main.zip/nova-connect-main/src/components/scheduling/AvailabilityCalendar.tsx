
import { useState } from "react";
import { Calendar } from "@/components/ui/calendar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { Clock, Save, Calendar as CalendarIcon } from "lucide-react";
import { TimeSlotSelector } from "./TimeSlotSelector";

interface Availability {
  date: Date;
  timeSlots: string[];
}

interface AvailabilityCalendarProps {
  projectId: string;
  isCraftsman: boolean;
  existingAvailabilities?: Availability[];
  onSaveAvailability?: (availabilities: Availability[]) => void;
  onSelectTimeSlot?: (date: Date, timeSlot: string) => void;
}

// Créneaux horaires standard pour les disponibilités
const timeSlots = [
  "08:00", "09:00", "10:00", "11:00", "12:00", "13:00", 
  "14:00", "15:00", "16:00", "17:00", "18:00"
];

export function AvailabilityCalendar({ 
  projectId, 
  isCraftsman, 
  existingAvailabilities = [],
  onSaveAvailability,
  onSelectTimeSlot
}: AvailabilityCalendarProps) {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(undefined);
  const [selectedTimeSlots, setSelectedTimeSlots] = useState<string[]>([]);
  const [availabilities, setAvailabilities] = useState<Availability[]>(existingAvailabilities);
  const [isLoading, setIsLoading] = useState(false);

  // Vérifier si une date a des disponibilités
  const isDateWithAvailability = (date: Date) => {
    return availabilities.some(a => 
      a.date.toDateString() === date.toDateString() && a.timeSlots.length > 0
    );
  };

  // Récupérer les créneaux pour une date donnée
  const getTimeSlotsForDate = (date: Date) => {
    const availability = availabilities.find(a => 
      a.date.toDateString() === date.toDateString()
    );
    return availability ? availability.timeSlots : [];
  };

  // Gérer la sélection d'une date
  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    if (date) {
      const slots = getTimeSlotsForDate(date);
      setSelectedTimeSlots(slots);
    } else {
      setSelectedTimeSlots([]);
    }
  };

  // Activer/désactiver un créneau horaire
  const toggleTimeSlot = (timeSlot: string) => {
    if (selectedTimeSlots.includes(timeSlot)) {
      setSelectedTimeSlots(selectedTimeSlots.filter(t => t !== timeSlot));
    } else {
      setSelectedTimeSlots([...selectedTimeSlots, timeSlot].sort());
    }
  };

  // Enregistrer les disponibilités
  const handleSaveAvailability = async () => {
    if (!selectedDate) return;
    
    setIsLoading(true);
    
    // Mettre à jour les disponibilités localement
    const updatedAvailabilities = [...availabilities];
    const existingIndex = updatedAvailabilities.findIndex(
      a => a.date.toDateString() === selectedDate.toDateString()
    );
    
    if (existingIndex >= 0) {
      updatedAvailabilities[existingIndex].timeSlots = selectedTimeSlots;
    } else {
      updatedAvailabilities.push({
        date: selectedDate,
        timeSlots: selectedTimeSlots
      });
    }
    
    // Simuler une requête API
    setTimeout(() => {
      setAvailabilities(updatedAvailabilities);
      
      if (onSaveAvailability) {
        onSaveAvailability(updatedAvailabilities);
      }
      
      toast({
        title: "Disponibilités enregistrées",
        description: `Vos disponibilités pour le ${format(selectedDate, 'dd MMMM yyyy', { locale: fr })} ont été sauvegardées.`,
      });
      
      setIsLoading(false);
    }, 1000);
  };

  // Sélectionner un créneau horaire (pour les propriétaires)
  const handleSelectTimeSlot = (timeSlot: string) => {
    if (!selectedDate || !onSelectTimeSlot) return;
    onSelectTimeSlot(selectedDate, timeSlot);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          {isCraftsman ? "Proposer vos disponibilités" : "Choisir un créneau horaire"}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h3 className="font-medium mb-2 flex items-center">
              <CalendarIcon className="h-4 w-4 mr-2" />
              Sélectionnez une date
            </h3>
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={handleDateSelect}
              className="border rounded-md p-3"
              disabled={(date) => {
                const today = new Date();
                today.setHours(0, 0, 0, 0);
                return date < today;
              }}
              modifiers={{
                booked: (date) => isDateWithAvailability(date),
              }}
              modifiersStyles={{
                booked: { backgroundColor: "rgba(59, 130, 246, 0.1)" },
              }}
            />
          </div>
          
          <div>
            <h3 className="font-medium mb-2 flex items-center">
              <Clock className="h-4 w-4 mr-2" />
              {selectedDate ? (
                <>Créneaux pour le {format(selectedDate, 'dd MMMM yyyy', { locale: fr })}</>
              ) : (
                <>Sélectionnez d'abord une date</>
              )}
            </h3>
            
            {selectedDate ? (
              <div className="space-y-2 mt-4">
                <TimeSlotSelector
                  timeSlots={timeSlots}
                  selectedTimeSlots={selectedTimeSlots}
                  onToggleTimeSlot={toggleTimeSlot}
                  isCraftsman={isCraftsman}
                  onSelectTimeSlot={handleSelectTimeSlot}
                  availableTimeSlots={getTimeSlotsForDate(selectedDate)}
                />
              </div>
            ) : (
              <div className="flex items-center justify-center h-40 border rounded-md bg-muted/20">
                <p className="text-sm text-muted-foreground">
                  Veuillez sélectionner une date dans le calendrier
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
      
      {isCraftsman && selectedDate && (
        <CardFooter>
          <Button 
            onClick={handleSaveAvailability}
            disabled={isLoading || !selectedDate} 
            className="w-full"
          >
            <Save className="mr-2 h-4 w-4" />
            {isLoading ? "Enregistrement..." : "Enregistrer mes disponibilités"}
          </Button>
        </CardFooter>
      )}
    </Card>
  );
}
