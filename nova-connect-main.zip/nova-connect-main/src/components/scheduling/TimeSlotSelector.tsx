
import { Badge } from "@/components/ui/badge";

interface TimeSlotSelectorProps {
  timeSlots: string[];
  selectedTimeSlots: string[];
  onToggleTimeSlot: (timeSlot: string) => void;
  isCraftsman: boolean;
  onSelectTimeSlot?: (timeSlot: string) => void;
  availableTimeSlots?: string[];
}

export function TimeSlotSelector({ 
  timeSlots, 
  selectedTimeSlots, 
  onToggleTimeSlot,
  isCraftsman,
  onSelectTimeSlot,
  availableTimeSlots = []
}: TimeSlotSelectorProps) {
  if (isCraftsman) {
    return (
      <div className="grid grid-cols-3 gap-2">
        {timeSlots.map(timeSlot => (
          <Badge
            key={timeSlot}
            variant={selectedTimeSlots.includes(timeSlot) ? "default" : "outline"}
            className="cursor-pointer py-2"
            onClick={() => onToggleTimeSlot(timeSlot)}
          >
            {timeSlot}
          </Badge>
        ))}
      </div>
    );
  }

  return (
    <div>
      {availableTimeSlots.length > 0 ? (
        <div className="grid grid-cols-3 gap-2">
          {availableTimeSlots.map(timeSlot => (
            <Badge
              key={timeSlot}
              variant="outline"
              className="cursor-pointer py-2 hover:bg-primary hover:text-primary-foreground"
              onClick={() => onSelectTimeSlot?.(timeSlot)}
            >
              {timeSlot}
            </Badge>
          ))}
        </div>
      ) : (
        <p className="text-sm text-muted-foreground">
          Aucun créneau disponible pour cette date.
        </p>
      )}
    </div>
  );
}
