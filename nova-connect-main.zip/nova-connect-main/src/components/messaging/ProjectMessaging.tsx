
import { useState } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useToast } from "@/hooks/use-toast";
import { Send, PaperclipIcon, Clock, Info } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { getCurrentUser } from "@/lib/mock-api";
import { User } from "@/types/user";

// Message interface
interface Message {
  id: string;
  content: string;
  senderId: string;
  senderName: string;
  senderAvatar?: string;
  timestamp: string;
  isRead: boolean;
}

interface ProjectMessagingProps {
  projectId: string;
  otherUser?: {
    id: string;
    name: string;
    avatar?: string;
  };
}

export function ProjectMessaging({ projectId, otherUser }: ProjectMessagingProps) {
  const { toast } = useToast();
  const [messageText, setMessageText] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const currentUser = getCurrentUser();
  
  // Mock messages - in a real app these would come from an API
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Bonjour, je suis intéressé par votre projet. Est-ce que je pourrais avoir plus de détails sur les matériaux souhaités ?",
      senderId: "craftsman1",
      senderName: "Pierre Durand",
      timestamp: new Date(Date.now() - 2 * 3600000).toISOString(),
      isRead: true
    },
    {
      id: "2",
      content: "Bonjour, merci pour votre intérêt ! Je souhaite des matériaux écologiques et durables. Avez-vous de l'expérience avec ce type de matériaux ?",
      senderId: "owner1",
      senderName: "Sophie Martin",
      timestamp: new Date(Date.now() - 1 * 3600000).toISOString(),
      isRead: true
    }
  ]);
  
  // No messages available if project doesn't have assigned craftsman yet
  const showEmptyState = !otherUser || messages.length === 0;
  
  const handleSendMessage = () => {
    if (!messageText.trim()) return;
    
    setIsLoading(true);
    
    // Simulate sending message
    setTimeout(() => {
      const newMessage: Message = {
        id: Date.now().toString(),
        content: messageText.trim(),
        senderId: currentUser?.id || "currentUser",
        senderName: getUserName(currentUser as User) || "Vous",
        timestamp: new Date().toISOString(),
        isRead: false
      };
      
      setMessages([...messages, newMessage]);
      setMessageText("");
      setIsLoading(false);
      
      // Send notification
      toast({
        title: "Message envoyé",
        description: `Votre message a été envoyé à ${otherUser?.name || "l'autre utilisateur"}.`,
      });
    }, 1000);
  };
  
  // Helper function to get user name
  const getUserName = (user: User | null): string => {
    if (!user) return "";
    // If user has firstName or lastName, use them
    if (user.firstName || user.lastName) {
      return `${user.firstName || ""} ${user.lastName || ""}`.trim();
    }
    // If user has name property, use it
    if (user.name) {
      return user.name;
    }
    // Fallback to email
    return user.email.split('@')[0];
  };
  
  if (showEmptyState) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Messages</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              La messagerie sera disponible une fois qu'un artisan aura été assigné au projet.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="h-[550px] flex flex-col">
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarFallback>{otherUser?.name.charAt(0) || "U"}</AvatarFallback>
            {otherUser?.avatar && <AvatarImage src={otherUser.avatar} />}
          </Avatar>
          <CardTitle>{otherUser?.name || "Conversation"}</CardTitle>
        </div>
      </CardHeader>
      
      <ScrollArea className="flex-1 px-4">
        <div className="space-y-4 mb-4">
          {messages.map((message) => {
            const isCurrentUser = message.senderId === (currentUser?.id || "currentUser");
            
            return (
              <div 
                key={message.id} 
                className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
              >
                <div className="flex gap-2 max-w-[80%]">
                  {!isCurrentUser && (
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>{message.senderName.charAt(0)}</AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div className={`rounded-lg p-3 ${
                    isCurrentUser 
                      ? 'bg-primary text-primary-foreground' 
                      : 'bg-muted'
                  }`}>
                    <p className="text-sm">{message.content}</p>
                    <div className="flex justify-end mt-1">
                      <span className="text-xs opacity-70 flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {new Date(message.timestamp).toLocaleTimeString('fr-FR', {
                          hour: '2-digit',
                          minute: '2-digit'
                        })}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
      
      <CardFooter className="p-4 pt-2 border-t">
        <div className="flex gap-2 w-full">
          <Button variant="outline" size="icon">
            <PaperclipIcon className="h-4 w-4" />
          </Button>
          <Textarea 
            placeholder="Écrivez votre message..." 
            className="flex-1 min-h-10 max-h-32"
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
          />
          <Button 
            onClick={handleSendMessage} 
            disabled={isLoading || !messageText.trim()}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
