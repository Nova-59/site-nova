
import { useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { HandCoins, Info, Clock } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { getCurrentUser } from "@/lib/mock-api";
import { User } from "@/types/user";

const bidFormSchema = z.object({
  message: z
    .string()
    .min(10, { message: "Le message doit contenir au moins 10 caractères" })
    .max(500, { message: "Le message ne peut pas dépasser 500 caractères" }),
});

type BidFormValues = z.infer<typeof bidFormSchema>;

interface ProjectBidFormProps {
  projectId: string;
  minBudget: number;
  maxBudget: number;
}

export function ProjectBidForm({ projectId, minBudget, maxBudget }: ProjectBidFormProps) {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const currentUser = getCurrentUser() as User | null;
  
  const isCraftsman = currentUser?.role === "craftsman";
  
  const defaultValues: Partial<BidFormValues> = {
    message: "",
  };

  const form = useForm<BidFormValues>({
    resolver: zodResolver(bidFormSchema),
    defaultValues,
  });

  const onSubmit = async (data: BidFormValues) => {
    setIsSubmitting(true);
    
    setTimeout(() => {
      console.log("Project acceptance submitted:", { projectId, ...data });
      
      toast({
        title: "Projet pris en charge",
        description: "Vous avez pris en charge ce projet. Le client en sera informé.",
      });
      
      form.reset(defaultValues);
      setIsSubmitting(false);
    }, 1500);
  };

  if (!currentUser) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Prendre en charge ce projet</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Connexion requise</AlertTitle>
            <AlertDescription>
              Vous devez être connecté pour prendre en charge ce projet.
            </AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Button variant="default" asChild className="w-full">
            <a href="/auth">Se connecter</a>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  if (!isCraftsman) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Prendre en charge ce projet</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Compte artisan requis</AlertTitle>
            <AlertDescription>
              Seuls les artisans vérifiés peuvent prendre en charge des projets.
            </AlertDescription>
          </Alert>
        </CardContent>
        <CardFooter>
          <Button variant="default" asChild className="w-full">
            <a href="/craftsman/register">Devenir artisan</a>
          </Button>
        </CardFooter>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Prendre en charge ce projet</CardTitle>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="mb-4 bg-muted p-4 rounded-md">
              <h3 className="font-medium mb-2">Budget vérifié par notre métreur</h3>
              <p className="text-2xl font-bold">{minBudget} € - {maxBudget} €</p>
              <p className="text-sm text-muted-foreground mt-2">Commission de service de 12%</p>
              <div className="border-t mt-2 pt-2">
                <p className="text-sm">Montant que vous recevrez: <span className="font-medium">{Math.round(maxBudget * 0.88)} € - {Math.round(minBudget * 0.88)} €</span></p>
              </div>
            </div>
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message au client</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Présentez-vous et expliquez pourquoi vous êtes le meilleur artisan pour ce projet..." 
                      className="min-h-[120px]" 
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Alert variant="default" className="bg-muted/50">
              <Info className="h-4 w-4" />
              <AlertDescription className="text-xs">
                En prenant en charge ce projet, vous vous engagez à réaliser les travaux selon le cahier des charges 
                établi par notre métreur et dans les délais convenus. Votre paiement sera effectué après la réception 
                des travaux et validation par le client.
              </AlertDescription>
            </Alert>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isSubmitting}
            >
              <HandCoins className="mr-2 h-4 w-4" />
              {isSubmitting ? "Traitement en cours..." : "Prendre en charge ce projet"}
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
