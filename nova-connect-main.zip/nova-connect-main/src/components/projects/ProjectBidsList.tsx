
import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Clock, MessageCircle, Check, Star, Info } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";

// Type definition for bids (renamed to acceptances in the UI)
interface Bid {
  id: string;
  projectId: string;
  craftsmanId: string;
  craftsmanName: string;
  craftsmanAvatar?: string;
  amount?: number; // Now optional since price is fixed by the estimator
  timeframe?: string; // Now optional since timeline may be predefined
  message: string;
  rating?: number;
  createdAt: string;
  status: "pending" | "accepted" | "rejected";
}

interface ProjectBidsListProps {
  projectId: string;
  isOwner: boolean;
  bids?: Bid[];
}

export function ProjectBidsList({ projectId, isOwner, bids = [] }: ProjectBidsListProps) {
  const { toast } = useToast();
  const [localBids, setLocalBids] = useState<Bid[]>(bids);
  const [loadingBidId, setLoadingBidId] = useState<string | null>(null);
  
  // For demo purposes, let's have some mock data if no bids provided
  const hasBids = localBids.length > 0;
  
  // Handlers for bid actions
  const handleAcceptBid = (bidId: string) => {
    setLoadingBidId(bidId);
    
    // Simulate API call
    setTimeout(() => {
      // Update local state
      setLocalBids(prevBids => 
        prevBids.map(bid => 
          bid.id === bidId 
            ? { ...bid, status: "accepted" } 
            : { ...bid, status: "rejected" }
        )
      );
      
      // Show success toast
      toast({
        title: "Artisan sélectionné",
        description: "L'artisan a été notifié. Les travaux peuvent maintenant commencer.",
      });
      
      setLoadingBidId(null);
    }, 1000);
  };
  
  const handleMessageCraftsman = (craftsmanName: string) => {
    toast({
      title: "Messagerie",
      description: `La messagerie avec ${craftsmanName} sera disponible prochainement.`,
    });
  };
  
  // If there are no bids yet, show info message
  if (!hasBids) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Artisans intéressés</CardTitle>
          <CardDescription>
            Les artisans qui souhaitent réaliser vos travaux apparaîtront ici.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <Info className="h-4 w-4" />
            <AlertTitle>Pas encore d'artisans</AlertTitle>
            <AlertDescription>
              Aucun artisan n'a encore manifesté son intérêt pour ce projet.
              {isOwner 
                ? " Vous serez notifié lorsqu'un artisan proposera ses services."
                : " Soyez le premier à proposer vos services pour ce projet."}
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Artisans intéressés</CardTitle>
        <CardDescription>
          {localBids.length} artisan{localBids.length > 1 ? 's' : ''} proposent leurs services
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <div className="divide-y">
          {localBids.map((bid) => (
            <div key={bid.id} className="p-4">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Avatar>
                    <AvatarFallback>{bid.craftsmanName.charAt(0)}</AvatarFallback>
                    {bid.craftsmanAvatar && (
                      <AvatarImage src={bid.craftsmanAvatar} alt={bid.craftsmanName} />
                    )}
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{bid.craftsmanName}</h4>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {bid.rating && (
                        <span className="flex items-center">
                          <Star className="h-3 w-3 text-yellow-500 mr-1" />
                          {bid.rating.toFixed(1)}
                        </span>
                      )}
                      <span className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        {new Date(bid.createdAt).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                  </div>
                </div>
                <Badge variant={
                  bid.status === "accepted" ? "default" : 
                  bid.status === "rejected" ? "outline" : 
                  "secondary"
                }>
                  {bid.status === "accepted" ? "Sélectionné" : 
                   bid.status === "rejected" ? "Non retenu" : 
                   "En attente"}
                </Badge>
              </div>
              
              <p className="text-sm mb-4">{bid.message}</p>
              
              {isOwner && bid.status === "pending" && (
                <div className="flex gap-2">
                  <Button 
                    variant="default" 
                    size="sm" 
                    className="flex-1"
                    onClick={() => handleAcceptBid(bid.id)}
                    disabled={loadingBidId !== null}
                  >
                    <Check className="mr-1 h-4 w-4" />
                    {loadingBidId === bid.id ? "En cours..." : "Sélectionner cet artisan"}
                  </Button>
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => handleMessageCraftsman(bid.craftsmanName)}
                  >
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                </div>
              )}
              
              {(bid.status === "accepted" || !isOwner) && (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => handleMessageCraftsman(bid.craftsmanName)}
                >
                  <MessageCircle className="mr-1 h-4 w-4" />
                  {isOwner ? "Contacter l'artisan" : "Contacter le propriétaire"}
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
