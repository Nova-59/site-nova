
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProjectProgressTracking } from "@/components/projects/ProjectProgressTracking";
import { ProjectStatus } from "@/types/project";

interface ProjectDetailTabsProps {
  projectId: string;
  status: ProjectStatus;
  isOwner: boolean;
  hasAcceptedCraftsman: boolean;
  currentUserId?: string;
  craftsmanId?: string;
  defaultTab?: string;
}

export function ProjectDetailTabs({
  projectId,
  status,
  isOwner,
  hasAcceptedCraftsman,
  currentUserId,
  craftsmanId,
  defaultTab = "artisans"
}: ProjectDetailTabsProps) {
  return (
    <Tabs defaultValue={defaultTab} className="w-full">
      <TabsList className="grid w-full grid-cols-3">
        <TabsTrigger value="artisans">Artisans intéressés</TabsTrigger>
        <TabsTrigger value="messages">Messages</TabsTrigger>
        <TabsTrigger value="progress">Progression</TabsTrigger>
      </TabsList>
      
      {/* Artisans Tab */}
      <TabsContent value="artisans" className="pt-6">
        <div className="text-center p-8 border rounded-lg">
          <h3 className="text-lg font-medium">Aucun artisan n'a encore pris en charge ce projet</h3>
          <p className="text-muted-foreground mt-2">Les artisans pourront voir votre projet et choisir de le prendre en charge</p>
        </div>
      </TabsContent>
      
      {/* Messages Tab */}
      <TabsContent value="messages" className="pt-6">
        <div className="text-center p-8 border rounded-lg">
          <h3 className="text-lg font-medium">Messagerie</h3>
          <p className="text-muted-foreground mt-2">La messagerie sera disponible une fois qu'un artisan aura pris en charge votre projet</p>
        </div>
      </TabsContent>
      
      {/* Progress Tab */}
      <TabsContent value="progress" className="pt-6">
        <ProjectProgressTracking 
          projectId={projectId}
          status={status}
          isOwner={isOwner}
        />
      </TabsContent>
    </Tabs>
  );
}
