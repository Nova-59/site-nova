
import { Button } from "@/components/ui/button";

interface CraftsmanProjectTakeoverFormProps {
  onTakeProject: () => void;
}

export function CraftsmanProjectTakeoverForm({ onTakeProject }: CraftsmanProjectTakeoverFormProps) {
  return (
    <div className="space-y-4">
      <div className="bg-muted p-4 rounded-lg border">
        <h3 className="font-medium mb-2">Intéressé par ce projet ?</h3>
        <p className="text-sm text-muted-foreground mb-4">
          En choisissant de prendre en charge ce projet, vous vous engagez à :
        </p>
        <ul className="text-sm space-y-2 mb-4">
          <li className="flex items-start gap-2">
            <span className="bg-green-100 text-green-800 p-1 rounded-full mt-0.5">✓</span>
            <span>Respecter les délais indiqués</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="bg-green-100 text-green-800 p-1 rounded-full mt-0.5">✓</span>
            <span>Réaliser le travail selon les spécifications</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="bg-green-100 text-green-800 p-1 rounded-full mt-0.5">✓</span>
            <span>Accepter le paiement via Nova Connect après validation des travaux</span>
          </li>
        </ul>
        <Button className="w-full" onClick={onTakeProject}>
          Prendre en charge ce projet
        </Button>
      </div>
      
      <div className="bg-muted p-4 rounded-lg border">
        <h3 className="font-medium mb-2">Information importante</h3>
        <p className="text-sm text-muted-foreground">
          Pour recevoir votre paiement, vous devez renseigner votre IBAN dans votre profil. 
          Le paiement sera effectué une fois les travaux validés par notre équipe.
        </p>
      </div>
    </div>
  );
}
