
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Calendar, 
  MapPin, 
  Euro, 
  Clock, 
  User, 
  CheckCircle, 
  FileText,
  MessageCircle,
  HandCoins,
  CreditCard
} from "lucide-react";
import { Project, ProjectCategory, ProjectStatus } from "@/types/project";
import { formatCurrency } from "@/lib/utils";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

interface ProjectDetailsCardProps {
  project: Project;
  onBid?: () => void;
  onMessage?: () => void;
  onPay?: () => void;
}

// Map category to human-readable label
const getCategoryLabel = (category: ProjectCategory): string => {
  const categoryMap: Record<ProjectCategory, string> = {
    plumbing: "Plomberie",
    electrical: "Électricité",
    carpentry: "Menuiserie",
    painting: "Peinture",
    flooring: "Revêtement de sol",
    roofing: "Toiture",
    masonry: "Maçonnerie",
    landscaping: "Aménagement extérieur",
    renovation: "Rénovation complète",
    other: "Autre"
  };
  
  return categoryMap[category] || category;
};

// Map status to human-readable label
const getStatusLabel = (status: ProjectStatus): string => {
  const statusMap: Record<ProjectStatus, string> = {
    pending: "En attente",
    verified: "Vérifié",
    assigned: "Assigné",
    in_progress: "En cours",
    completed: "Terminé",
    cancelled: "Annulé"
  };
  
  return statusMap[status] || status;
};

// Get status color for badge
const getStatusColor = (status: ProjectStatus): 
  "default" | "secondary" | "destructive" | "outline" => {
  const statusColorMap: Record<ProjectStatus, "default" | "secondary" | "destructive" | "outline"> = {
    pending: "outline",
    verified: "secondary",
    assigned: "default",
    in_progress: "default",
    completed: "default",
    cancelled: "destructive"
  };
  
  return statusColorMap[status] || "outline";
};

// Get project progress percentage based on status
const getProjectProgress = (status: ProjectStatus): number => {
  const progressMap: Record<ProjectStatus, number> = {
    pending: 10,
    verified: 25,
    assigned: 40,
    in_progress: 75,
    completed: 100,
    cancelled: 0
  };
  
  return progressMap[status] || 0;
};

export function ProjectDetailsCard({ project, onBid, onMessage, onPay }: ProjectDetailsCardProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  // These are placeholders for functionality we'll implement later
  const handleBid = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      if (onBid) {
        onBid();
      } else {
        toast({
          title: "Fonctionnalité en développement",
          description: "Le système d'enchères sera disponible prochainement.",
        });
      }
    }, 1000);
  };
  
  const handleMessage = () => {
    if (onMessage) {
      onMessage();
    } else {
      toast({
        title: "Fonctionnalité en développement",
        description: "La messagerie sera disponible prochainement.",
      });
    }
  };
  
  const handlePayment = () => {
    if (onPay) {
      onPay();
    } else {
      toast({
        title: "Fonctionnalité en développement",
        description: "Le système de paiement sera disponible prochainement.",
      });
    }
  };
  
  // Determine if project has images
  const hasImages = project.images && project.images.length > 0;
  
  // We show different UI elements based on project status
  const showBidButton = ["verified", "assigned"].includes(project.status);
  const showMessageButton = ["assigned", "in_progress", "completed"].includes(project.status);
  const showPaymentButton = ["completed"].includes(project.status);
  
  return (
    <Card className="w-full">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-2xl">{project.title}</CardTitle>
            <CardDescription className="flex items-center gap-1 mt-1">
              <MapPin className="h-3.5 w-3.5" />
              {project.location.city}, {project.location.postalCode} ({project.location.region})
            </CardDescription>
          </div>
          <Badge variant={getStatusColor(project.status)}>
            {getStatusLabel(project.status)}
          </Badge>
        </div>
        
        {/* Project Progress Indicator */}
        <div className="mt-4 space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Progression du projet</span>
            <span>{getProjectProgress(project.status)}%</span>
          </div>
          <Progress value={getProjectProgress(project.status)} />
        </div>
      </CardHeader>
      
      <CardContent className="space-y-6">
        {/* Project Images Carousel (placeholder for now) */}
        {hasImages && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {project.images.map((image, index) => (
              <div key={image.id} className="rounded-md overflow-hidden bg-muted h-48">
                <img 
                  src={image.url} 
                  alt={image.alt} 
                  className="w-full h-full object-cover"
                />
              </div>
            ))}
          </div>
        )}
        
        {/* Project Description */}
        <div>
          <h3 className="text-lg font-medium mb-2">Description</h3>
          <p className="text-muted-foreground whitespace-pre-line">
            {project.description}
          </p>
        </div>
        
        {/* Project Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Informations générales</h3>
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <Badge variant="outline">{getCategoryLabel(project.category)}</Badge>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Euro className="h-4 w-4 text-muted-foreground" />
                <span>Budget: {formatCurrency(project.budget.min)} - {formatCurrency(project.budget.max)}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>Créé le: {new Date(project.createdAt).toLocaleDateString('fr-FR')}</span>
              </div>
              {project.startDate && (
                <div className="flex items-center gap-2 text-sm">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <span>Début: {new Date(project.startDate).toLocaleDateString('fr-FR')}</span>
                </div>
              )}
              {project.endDate && (
                <div className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-muted-foreground" />
                  <span>Fin: {new Date(project.endDate).toLocaleDateString('fr-FR')}</span>
                </div>
              )}
            </div>
          </div>
          
          <div className="space-y-3">
            <h3 className="text-lg font-medium">Intervenants</h3>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>PR</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">Propriétaire</p>
                  <p className="text-xs text-muted-foreground">ID: {project.ownerId}</p>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback>ME</AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-medium">Métreur</p>
                  <p className="text-xs text-muted-foreground">ID: {project.estimatorId}</p>
                </div>
              </div>
              
              {project.craftsmanId && (
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>AR</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="text-sm font-medium">Artisan</p>
                    <p className="text-xs text-muted-foreground">ID: {project.craftsmanId}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Project Documents Section (Placeholder) */}
        <div>
          <h3 className="text-lg font-medium mb-2">Documents</h3>
          <Alert>
            <FileText className="h-4 w-4" />
            <AlertTitle>Dossier complet</AlertTitle>
            <AlertDescription>
              Plans, métrés et spécifications techniques disponibles pour les artisans sélectionnés.
            </AlertDescription>
          </Alert>
        </div>
      </CardContent>
      
      <Separator />
      
      <CardFooter className="flex flex-wrap gap-3 justify-between p-6">
        <div className="flex flex-wrap gap-3">
          {showBidButton && (
            <Button 
              variant="default" 
              className="gap-2"
              onClick={handleBid}
              disabled={isLoading}
            >
              <HandCoins size={16} />
              {isLoading ? "Chargement..." : "Soumettre une offre"}
            </Button>
          )}
          
          {showMessageButton && (
            <Button
              variant="outline"
              className="gap-2"
              onClick={handleMessage}
            >
              <MessageCircle size={16} />
              Contacter
            </Button>
          )}
          
          {showPaymentButton && (
            <Button
              variant="default"
              className="gap-2"
              onClick={handlePayment}
            >
              <CreditCard size={16} />
              Procéder au paiement
            </Button>
          )}
        </div>
        
        <Button
          variant="ghost"
          className="gap-2"
          onClick={() => window.history.back()}
        >
          Retour
        </Button>
      </CardFooter>
    </Card>
  );
}
