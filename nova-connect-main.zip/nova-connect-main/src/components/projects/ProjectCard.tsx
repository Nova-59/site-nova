
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { MapPin, Calendar, Euro, Lock, Eye } from "lucide-react";
import { Project, ProjectCategory } from "@/types/project";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { Link } from "react-router-dom";

interface ProjectCardProps {
  project: Project;
}

// Map category to human-readable label
const getCategoryLabel = (category: ProjectCategory): string => {
  const categoryMap: Record<ProjectCategory, string> = {
    plumbing: "Plomberie",
    electrical: "Électricité",
    carpentry: "Menuiserie",
    painting: "Peinture",
    flooring: "Revêtement de sol",
    roofing: "Toiture",
    masonry: "Maçonnerie",
    landscaping: "Aménagement extérieur",
    renovation: "Rénovation complète",
    other: "Autre"
  };
  
  return categoryMap[category] || category;
};

export function ProjectCard({ project }: ProjectCardProps) {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const handlePurchaseAccess = () => {
    setIsLoading(true);
    
    // In a real app, this would make an API call to purchase access
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Fonctionnalité en développement",
        description: "Cette fonctionnalité sera disponible prochainement.",
      });
    }, 1000);
  };
  
  // Determine if an image is available to display
  const hasImage = project.images && project.images.length > 0;
  const thumbnailImage = hasImage ? project.images[0].url : "/placeholder.svg";
  
  return (
    <Card className="overflow-hidden flex flex-col h-full hover:shadow-md transition-shadow">
      <div className="relative h-48 bg-muted">
        <img 
          src={thumbnailImage} 
          alt={hasImage ? project.images[0].alt : "Project thumbnail"} 
          className="h-full w-full object-cover"
        />
        <Badge className="absolute top-2 right-2" variant="secondary">
          {getCategoryLabel(project.category)}
        </Badge>
      </div>
      
      <CardHeader className="pb-2">
        <CardTitle className="line-clamp-1 text-xl">{project.title}</CardTitle>
        <CardDescription className="flex items-center gap-1">
          <MapPin className="h-3.5 w-3.5" />
          {project.location.city}, {project.location.postalCode}
        </CardDescription>
      </CardHeader>
      
      <CardContent className="pb-2 flex-grow">
        <p className="line-clamp-2 text-muted-foreground mb-4 text-sm">
          {project.shortDescription}
        </p>
        
        <div className="grid grid-cols-2 gap-3 text-sm">
          <div className="flex items-center gap-1.5">
            <Euro className="h-4 w-4 text-muted-foreground" />
            <span>
              {formatCurrency(project.budget.min)} - {formatCurrency(project.budget.max)}
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span>
              {new Date(project.createdAt).toLocaleDateString('fr-FR')}
            </span>
          </div>
        </div>
        
        <Separator className="my-4" />
        
        <div className="text-sm text-muted-foreground flex items-center gap-2">
          <Lock className="h-4 w-4" />
          <span>Détails complets sur achat {(project.budget.max * 0.12).toFixed(0)}€</span>
        </div>
      </CardContent>
      
      <CardFooter className="pt-0 flex gap-2">
        <Button 
          className="flex-1" 
          onClick={handlePurchaseAccess} 
          disabled={isLoading}
        >
          {isLoading ? "Traitement..." : "Accéder aux détails"}
        </Button>
        
        <Button variant="outline" asChild>
          <Link to={`/projects/${project.id}`} className="flex items-center gap-2">
            <Eye size={16} />
            <span className="sr-only md:not-sr-only md:inline">Aperçu</span>
          </Link>
        </Button>
      </CardFooter>
    </Card>
  );
}
