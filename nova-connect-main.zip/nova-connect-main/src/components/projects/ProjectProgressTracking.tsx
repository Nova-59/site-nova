
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Info, Check, Clock, CreditCard, FileCheck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ProjectStatus } from "@/types/project";
import { useState } from "react";

interface ProjectStage {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  current: boolean;
  date?: string;
  paymentRequired?: boolean;
  paymentAmount?: number;
  documents?: {
    id: string;
    name: string;
    url: string;
  }[];
}

interface ProjectProgressTrackingProps {
  projectId: string;
  status: ProjectStatus;
  isOwner: boolean;
}

export function ProjectProgressTracking({ projectId, status, isOwner }: ProjectProgressTrackingProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Active project stages only available for in_progress projects
  const showStages = ["in_progress", "completed"].includes(status);
  
  // Example project stages for a renovation project
  const [stages, setStages] = useState<ProjectStage[]>([
    {
      id: "1",
      title: "Planification et conception",
      description: "Validation des plans et des matériaux",
      completed: true,
      current: false,
      date: "15/05/2023"
    },
    {
      id: "2",
      title: "Travaux préparatoires",
      description: "Démolition et préparation du site",
      completed: status === "completed",
      current: status === "in_progress",
      date: status === "completed" ? "28/05/2023" : undefined,
      paymentRequired: true,
      paymentAmount: 2500
    },
    {
      id: "3",
      title: "Réalisation des travaux",
      description: "Installation et construction",
      completed: false,
      current: false,
      documents: [
        {
          id: "doc1",
          name: "Photos d'avancement",
          url: "#"
        }
      ]
    },
    {
      id: "4",
      title: "Finitions",
      description: "Peinture, nettoyage et finitions",
      completed: false,
      current: false
    },
    {
      id: "5",
      title: "Réception des travaux",
      description: "Inspection finale et remise des clés",
      completed: false,
      current: false,
      paymentRequired: true,
      paymentAmount: 3500
    }
  ]);
  
  // Calculate progress percentage
  const completedStages = stages.filter(s => s.completed).length;
  const totalStages = stages.length;
  const progressPercentage = Math.round((completedStages / totalStages) * 100);
  
  const handleCompleteStage = (stageId: string) => {
    setIsProcessing(true);
    
    // Simulate API call
    setTimeout(() => {
      // Update stages
      setStages(stages.map(stage => {
        if (stage.id === stageId) {
          // Mark current stage as completed
          return { ...stage, completed: true, current: false, date: new Date().toLocaleDateString('fr-FR') };
        } else if (stage.id === (Number(stageId) + 1).toString()) {
          // Set next stage as current
          return { ...stage, current: true };
        }
        return stage;
      }));
      
      toast({
        title: "Étape terminée",
        description: "L'étape a été marquée comme terminée et le projet a été mis à jour.",
      });
      
      setIsProcessing(false);
    }, 1500);
  };
  
  const handlePayment = (amount: number) => {
    toast({
      title: "Paiement",
      description: `Le paiement de ${amount}€ sera disponible prochainement.`,
    });
  };
  
  // If project is not in progress yet, show placeholder
  if (!showStages) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Progression du projet</CardTitle>
        </CardHeader>
        <CardContent>
          <Alert className="mb-4">
            <Info className="h-4 w-4" />
            <AlertDescription>
              Le suivi de la progression sera disponible une fois les travaux commencés.
            </AlertDescription>
          </Alert>
          
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-medium mb-2">Statut actuel</h3>
              <Badge variant="outline">
                {status === "pending" ? "En attente de validation" :
                 status === "verified" ? "Vérifié, en attente d'un artisan" :
                 status === "assigned" ? "Artisan assigné, démarrage prochain" :
                 status === "cancelled" ? "Annulé" : 
                 "Inconnu"}
              </Badge>
            </div>
            
            <div>
              <h3 className="text-sm font-medium mb-2">Prochaines étapes</h3>
              <ol className="list-decimal list-inside text-sm text-muted-foreground space-y-1 pl-2">
                {status === "pending" && (
                  <>
                    <li>Vérification par notre équipe</li>
                    <li>Publication sur la marketplace</li>
                    <li>Sélection d'un artisan</li>
                  </>
                )}
                {status === "verified" && (
                  <>
                    <li>Réception des offres d'artisans</li>
                    <li>Sélection de l'artisan</li>
                    <li>Planification des travaux</li>
                  </>
                )}
                {status === "assigned" && (
                  <>
                    <li>Signature du contrat</li>
                    <li>Planning des travaux</li>
                    <li>Démarrage du chantier</li>
                  </>
                )}
              </ol>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Progression du projet</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 mb-6">
          <div className="flex justify-between text-sm">
            <span>Avancement global</span>
            <span>{progressPercentage}%</span>
          </div>
          <Progress value={progressPercentage} />
        </div>
        
        <div className="space-y-6">
          {stages.map((stage, index) => (
            <div key={stage.id} className={`relative ${index < stages.length - 1 ? 'pb-6' : ''}`}>
              {/* Vertical timeline connector */}
              {index < stages.length - 1 && (
                <div className="absolute left-3.5 top-7 bottom-0 w-px bg-border"></div>
              )}
              
              <div className="flex gap-4">
                <div className={`h-7 w-7 rounded-full flex items-center justify-center flex-shrink-0 ${
                  stage.completed 
                    ? 'bg-primary text-primary-foreground' 
                    : stage.current 
                      ? 'bg-orange-500 text-white' 
                      : 'bg-muted text-muted-foreground'
                }`}>
                  {stage.completed ? (
                    <Check className="h-4 w-4" />
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>
                
                <div className="space-y-2 flex-1">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="text-sm font-medium">{stage.title}</h3>
                      <p className="text-xs text-muted-foreground">
                        {stage.description}
                      </p>
                    </div>
                    {stage.completed && (
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {stage.date}
                      </Badge>
                    )}
                  </div>
                  
                  {/* Documents section */}
                  {stage.documents && stage.documents.length > 0 && (
                    <div className="mt-2">
                      <Separator className="my-2" />
                      <div className="flex items-center gap-2">
                        <FileCheck className="h-4 w-4 text-muted-foreground" />
                        <span className="text-xs">Documents</span>
                      </div>
                      <ul className="text-xs text-blue-600 space-y-1 mt-1">
                        {stage.documents.map(doc => (
                          <li key={doc.id}>
                            <a href={doc.url} className="hover:underline">
                              {doc.name}
                            </a>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {/* Action buttons */}
                  {stage.current && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      {/* Payment button for owner */}
                      {isOwner && stage.paymentRequired && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1"
                          onClick={() => handlePayment(stage.paymentAmount || 0)}
                        >
                          <CreditCard className="h-3.5 w-3.5" />
                          Payer {stage.paymentAmount}€
                        </Button>
                      )}
                      
                      {/* Complete stage button for craftsman */}
                      {!isOwner && (
                        <Button
                          size="sm"
                          className="gap-1"
                          onClick={() => handleCompleteStage(stage.id)}
                          disabled={isProcessing || (stage.paymentRequired && isOwner)}
                        >
                          <Check className="h-3.5 w-3.5" />
                          {isProcessing ? "En cours..." : "Marquer comme terminé"}
                        </Button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
