
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { ProjectInfoSection } from "./form/ProjectInfoSection";
import { LocationSection } from "./form/LocationSection";
import { ImagesUploadSection } from "./form/ImagesUploadSection";
import { ProjectNoticeAlert } from "./form/ProjectNoticeAlert";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useProjectSubmission } from "@/hooks/useProjectSubmission";

const projectTypes = [
  "Plomberie",
  "Électricité",
  "Maçonnerie",
  "Peinture",
  "Carrelage",
  "Menuiserie",
  "Toiture",
  "Isolation",
  "Chauffage",
  "Autre"
];

export function ProjectSubmissionForm() {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState("");
  const [postalCode, setPostalCode] = useState("");
  const [projectType, setProjectType] = useState("");
  const [images, setImages] = useState<File[]>([]);
  const [imagePreviewUrls, setImagePreviewUrls] = useState<string[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { submitProject, isSubmitting } = useProjectSubmission();

  const validateForm = () => {
    const errors = [];
    
    if (!title.trim()) errors.push("Titre du projet");
    if (!description.trim()) errors.push("Description du projet");
    if (!city.trim()) errors.push("Ville");
    if (!postalCode.trim()) errors.push("Code postal");
    if (!projectType) errors.push("Type de projet");
    
    return {
      isValid: errors.length === 0,
      errorFields: errors
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Vérifier si l'utilisateur est connecté
    if (!user) {
      toast({
        variant: "destructive",
        title: "Vous devez être connecté",
        description: "Veuillez vous connecter pour soumettre un projet.",
      });
      navigate("/auth");
      return;
    }
    
    console.log("Soumission de projet par utilisateur:", user.id, user.email, user.role);
    
    // Valider le formulaire
    const { isValid, errorFields } = validateForm();
    if (!isValid) {
      toast({
        variant: "destructive",
        title: "Formulaire incomplet",
        description: `Veuillez remplir les champs suivants : ${errorFields.join(", ")}.`,
      });
      return;
    }
    
    // Utiliser le hook useProjectSubmission pour soumettre le projet
    await submitProject({
      title,
      description,
      category: projectType,
      address,
      city,
      postalCode,
      images
    });
    
    // Nettoyage du formulaire après soumission réussie
    if (!isSubmitting) {
      setTitle("");
      setDescription("");
      setAddress("");
      setCity("");
      setPostalCode("");
      setProjectType("");
      
      imagePreviewUrls.forEach(url => URL.revokeObjectURL(url));
      setImages([]);
      setImagePreviewUrls([]);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Soumettre un nouveau projet</CardTitle>
        <CardDescription>
          Décrivez votre projet en détail. Un métreur vous contactera pour planifier une visite et établir un devis précis.
        </CardDescription>
        <ProjectNoticeAlert />
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <ProjectInfoSection
            title={title}
            setTitle={setTitle}
            description={description}
            setDescription={setDescription}
            projectType={projectType}
            setProjectType={setProjectType}
            projectTypes={projectTypes}
          />
          
          <LocationSection
            address={address}
            setAddress={setAddress}
            city={city}
            setCity={setCity}
            postalCode={postalCode}
            setPostalCode={setPostalCode}
          />
          
          <ImagesUploadSection
            images={images}
            setImages={setImages}
            imagePreviewUrls={imagePreviewUrls}
            setImagePreviewUrls={setImagePreviewUrls}
          />
          
          <CardFooter className="px-0 pt-4">
            <Button type="submit" disabled={isSubmitting} className="w-full">
              {isSubmitting ? "Soumission en cours..." : "Soumettre mon projet"}
            </Button>
          </CardFooter>
        </form>
      </CardContent>
    </Card>
  );
}
