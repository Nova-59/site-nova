
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

interface ProjectInfoSectionProps {
  title: string;
  setTitle: (value: string) => void;
  description: string;
  setDescription: (value: string) => void;
  projectType: string;
  setProjectType: (value: string) => void;
  projectTypes: string[];
}

export function ProjectInfoSection({ 
  title, 
  setTitle, 
  description, 
  setDescription, 
  projectType, 
  setProjectType,
  projectTypes 
}: ProjectInfoSectionProps) {
  return (
    <>
      <div className="space-y-2">
        <Label htmlFor="title">Titre du projet</Label>
        <Input
          id="title"
          placeholder="Ex: Rénovation de salle de bain"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="projectType">Type de projet</Label>
        <Select 
          value={projectType} 
          onValueChange={setProjectType}
          required
        >
          <SelectTrigger id="projectType">
            <SelectValue placeholder="Sélectionnez le type de projet" />
          </SelectTrigger>
          <SelectContent>
            {projectTypes.map((type) => (
              <SelectItem key={type} value={type}>
                {type}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description détaillée</Label>
        <Textarea
          id="description"
          placeholder="Décrivez votre projet en détail (matériaux, dimensions, particularités...)"
          rows={5}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>
    </>
  );
}
