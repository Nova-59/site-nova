
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function ProjectNoticeAlert() {
  return (
    <Alert className="mt-4">
      <AlertCircle className="h-4 w-4" />
      <AlertTitle>Note importante</AlertTitle>
      <AlertDescription>
        Votre projet sera évalué par un métreur, puis publié sur la marketplace Nova Connect après validation. 
        Les artisans pourront consulter votre projet et choisir de le prendre en charge. Votre paiement sera 
        conservé par Nova Connect et ne sera versé à l'artisan qu'après la réception des travaux que notre 
        équipe aura validés. Les artisans ne reçoivent pas directement d'argent sur le site, mais doivent 
        renseigner leur IBAN sur leur profil pour recevoir leur paiement une fois les travaux validés.
      </AlertDescription>
    </Alert>
  );
}
