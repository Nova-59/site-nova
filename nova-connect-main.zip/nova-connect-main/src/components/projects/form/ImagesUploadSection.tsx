
import { useState } from "react";
import { Upload, X } from "lucide-react";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

interface ImagesUploadSectionProps {
  images: File[];
  setImages: (images: File[]) => void;
  imagePreviewUrls: string[];
  setImagePreviewUrls: (urls: string[]) => void;
}

export function ImagesUploadSection({
  images,
  setImages,
  imagePreviewUrls,
  setImagePreviewUrls
}: ImagesUploadSectionProps) {
  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const filesArray = Array.from(e.target.files);
      const newImages = [...images, ...filesArray].slice(0, 5);
      setImages(newImages);
      
      const newPreviewUrls = newImages.map(file => URL.createObjectURL(file));
      setImagePreviewUrls(newPreviewUrls);
    }
  };

  const removeImage = (index: number) => {
    const newImages = [...images];
    newImages.splice(index, 1);
    setImages(newImages);
    
    const newPreviewUrls = [...imagePreviewUrls];
    URL.revokeObjectURL(newPreviewUrls[index]);
    newPreviewUrls.splice(index, 1);
    setImagePreviewUrls(newPreviewUrls);
  };
  
  return (
    <div className="space-y-3">
      <Label>Photos du projet (5 maximum)</Label>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {imagePreviewUrls.map((url, index) => (
          <div key={index} className="relative aspect-square">
            <img
              src={url}
              alt={`Preview ${index + 1}`}
              className="w-full h-full object-cover rounded-md"
            />
            <Button
              type="button"
              size="icon"
              variant="destructive"
              className="absolute -top-2 -right-2 h-6 w-6 rounded-full"
              onClick={() => removeImage(index)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        ))}
        {images.length < 5 && (
          <div className="border-2 border-dashed rounded-md border-gray-300 aspect-square flex flex-col items-center justify-center p-4 hover:bg-gray-50 cursor-pointer">
            <label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center justify-center h-full w-full">
              <Upload className="h-8 w-8 text-muted-foreground mb-2" />
              <span className="text-sm text-muted-foreground">Ajouter des photos</span>
              <input
                id="image-upload"
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageChange}
                className="hidden"
              />
            </label>
          </div>
        )}
      </div>
      <p className="text-sm text-muted-foreground">
        Ajoutez des photos pour nous aider à mieux comprendre votre projet. Notre métreur prendra des photos supplémentaires lors de sa visite.
      </p>
    </div>
  );
}
