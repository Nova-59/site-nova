
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { ArrowRight, Hammer, ShieldCheck, MessageSquare } from "lucide-react";
import { t } from "@/lib/i18n";

export function HomePage() {
  const navigate = useNavigate();
  
  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section - Changed to white background */}
        <section 
          className="py-20 text-black relative overflow-hidden bg-white"
        >
          <div className="container mx-auto px-4 text-center relative z-10">
            {/* Logo mis à jour */}
            <img 
              src="/lovable-uploads/fac78569-0689-40f5-b7c1-75a36351a493.png" 
              alt="NOVA" 
              className="h-36 mx-auto mb-8"
            />
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-black">{t('heroTitle')}</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto text-black/80">{t('heroSubtitle')}</p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg" 
                onClick={() => navigate("/auth")}
                className="bg-black text-nova-yellow hover:bg-black/90"
              >
                {t('postRepairRequest')}
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate("/auth")}
                className="bg-transparent text-black border-black hover:bg-black/10"
              >
                {t('joinAsCraftsman')}
              </Button>
            </div>
          </div>
        </section>
        
        {/* How It Works */}
        <section className="py-16 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">{t('howItWorksTitle')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="card-hover border-t-4 border-t-nova-yellow">
                <CardHeader>
                  <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                    1
                  </div>
                  <CardTitle>{t('submitRequest')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{t('submitRequestDesc')}</p>
                </CardContent>
              </Card>
              
              <Card className="card-hover border-t-4 border-t-nova-yellow">
                <CardHeader>
                  <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                    2
                  </div>
                  <CardTitle>{t('professionalVerification')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{t('professionalVerificationDesc')}</p>
                </CardContent>
              </Card>
              
              <Card className="card-hover border-t-4 border-t-nova-yellow">
                <CardHeader>
                  <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                    3
                  </div>
                  <CardTitle>{t('connectWithCraftsmen')}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p>{t('connectWithCraftsmenDesc')}</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
        
        {/* Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">{t('whyChooseNova')}</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <ShieldCheck className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t('verifiedProfessionals')}</h3>
                <p className="text-muted-foreground">{t('verifiedProfessionalsDesc')}</p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <Hammer className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t('preVerifiedJobs')}</h3>
                <p className="text-muted-foreground">{t('preVerifiedJobsDesc')}</p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <MessageSquare className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{t('secureCommunication')}</h3>
                <p className="text-muted-foreground">{t('secureCommunicationDesc')}</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* CTA - Removed background image */}
        <section 
          className="py-16 text-black relative bg-nova-yellow"
        >
          <div className="container mx-auto px-4 text-center relative z-10">
            <h2 className="text-3xl font-bold mb-6">{t('readyToGetRepair')}</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">{t('joinThousands')}</p>
            <Button 
              size="lg" 
              onClick={() => navigate("/auth")}
              className="bg-black text-nova-yellow hover:bg-black/90"
            >
              {t('getStartedNow')} <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
}
