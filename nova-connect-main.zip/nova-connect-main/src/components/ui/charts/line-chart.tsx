
import * as React from "react"
import * as RechartsPrimitive from "recharts"
import { ChartContainer } from "./chart-container"
import { ChartTooltip, ChartTooltipContent } from "./chart-tooltip"
import { ChartConfig } from "./chart-types"

export interface LineChartProps {
  data: Array<Record<string, any>>
  xAxisKey?: string
  yAxisKey?: string
  height?: number
}

export const LineChart: React.FC<LineChartProps> = ({ 
  data, 
  xAxisKey = "name", 
  yAxisKey = "value",
  height = 300
}) => {
  const config: ChartConfig = {}
  
  return (
    <ChartContainer config={config} className="w-full" style={{ height }}>
      <RechartsPrimitive.LineChart data={data}>
        <RechartsPrimitive.CartesianGrid strokeDasharray="3 3" vertical={false} />
        <RechartsPrimitive.XAxis dataKey={xAxisKey} />
        <RechartsPrimitive.YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <RechartsPrimitive.Line 
          type="monotone" 
          dataKey={yAxisKey} 
          stroke="var(--color-primary, #3b82f6)" 
          strokeWidth={2}
          dot={{ fill: "var(--color-primary, #3b82f6)", strokeWidth: 0, r: 4 }}
          activeDot={{ fill: "var(--color-primary, #3b82f6)", r: 6 }}
        />
      </RechartsPrimitive.LineChart>
    </ChartContainer>
  )
}
