
import React from "react";
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip } from "recharts";
import { useChart } from "./chart-container";
import { cn } from "@/lib/utils";

interface PieChartProps {
  data: {
    name: string;
    value: number;
    color?: string;
  }[];
  className?: string;
  height?: number;
  width?: number;
  innerRadius?: number;
  outerRadius?: number;
  paddingAngle?: number;
  dataKey?: string;
  nameKey?: string;
  showLabels?: boolean;
}

export function PieChart({
  data,
  className,
  height = 300,
  width,
  innerRadius = 0,
  outerRadius = 80,
  paddingAngle = 0,
  dataKey = "value",
  nameKey = "name",
  showLabels = false,
}: PieChartProps) {
  const { theme } = useChart();
  
  // Default colors if not provided in data
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];
  
  // Filter out any items with zero or negative values
  const validData = data.filter(item => item.value > 0);
  
  if (validData.length === 0) {
    return (
      <div className={cn("flex items-center justify-center", className)} style={{ height }}>
        <p className="text-muted-foreground text-sm">No data available</p>
      </div>
    );
  }

  return (
    <div className={cn("w-full", className)}>
      <ResponsiveContainer width={width || "100%"} height={height}>
        <RechartsPieChart>
          <Pie
            data={validData}
            cx="50%"
            cy="50%"
            labelLine={showLabels}
            label={showLabels ? ({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%` : undefined}
            innerRadius={innerRadius}
            outerRadius={outerRadius}
            paddingAngle={paddingAngle}
            dataKey={dataKey}
            nameKey={nameKey}
          >
            {validData.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={entry.color || COLORS[index % COLORS.length]}
                stroke={theme === 'dark' ? '#1a1a1a' : '#fff'}
                strokeWidth={1}
              />
            ))}
          </Pie>
          <RechartsTooltip
            formatter={(value: number, name: string) => [
              `${value}`, 
              name
            ]}
          />
        </RechartsPieChart>
      </ResponsiveContainer>
    </div>
  );
}
