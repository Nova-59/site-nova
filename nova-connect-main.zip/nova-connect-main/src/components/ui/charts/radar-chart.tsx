
import * as React from "react"
import {
  PolarAngleAxis,
  PolarGrid,
  PolarRadiusAxis,
  Radar,
  RadarChart as RechartsRadarChart,
  ResponsiveContainer,
  Tooltip,
} from "recharts"
import { useChart } from "./chart-container"
import { getPayloadConfigFromPayload } from "./chart-types"
import { ChartTooltip } from "./chart-tooltip"

interface RadarChartProps {
  data: Array<Record<string, any>>
  dataKey: string
  nameKey?: string
  valueKey?: string
  categories?: string[]
  height?: number
  width?: number
  className?: string
  colors?: string[]
}

export function RadarChart({
  data,
  dataKey,
  nameKey = "name",
  valueKey = "value",
  categories,
  height,
  width,
  className,
  colors,
}: RadarChartProps) {
  const { config, theme } = useChart()

  const getColor = (payload: unknown) => {
    if (!payload) return undefined

    const payloadConfig = getPayloadConfigFromPayload(config, payload, dataKey)

    if (!payloadConfig) return undefined

    if ("color" in payloadConfig && payloadConfig.color) {
      return payloadConfig.color
    }

    if ("theme" in payloadConfig && payloadConfig.theme && theme) {
      return payloadConfig.theme[theme]
    }

    return undefined
  }

  // Prepare categories if not explicitly provided
  const usedCategories = categories || 
    (data.length > 0 ? 
      Object.keys(data[0]).filter(key => key !== nameKey && key !== valueKey) : 
      [])

  return (
    <div className={className} style={{ width, height }}>
      <ResponsiveContainer width="100%" height="100%">
        <RechartsRadarChart
          data={data}
          outerRadius="80%"
          margin={{ top: 0, right: 0, bottom: 0, left: 0 }}
        >
          <PolarGrid />
          <PolarAngleAxis dataKey={nameKey} />
          <PolarRadiusAxis />
          <Tooltip content={<ChartTooltip />} />
          <Radar
            name={dataKey}
            dataKey={valueKey}
            stroke={colors?.[0] || "#8884d8"}
            fill={colors?.[0] || "#8884d8"}
            fillOpacity={0.6}
          />
          {usedCategories.map((category, index) => (
            <Radar
              key={category}
              name={category}
              dataKey={category}
              stroke={colors?.[index % (colors?.length || 1)] || getColor({ [dataKey]: category }) || `var(--chart-${index % 8 + 1})`}
              fill={colors?.[index % (colors?.length || 1)] || getColor({ [dataKey]: category }) || `var(--chart-${index % 8 + 1})`}
              fillOpacity={0.6}
            />
          ))}
        </RechartsRadarChart>
      </ResponsiveContainer>
    </div>
  )
}
