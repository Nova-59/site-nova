
import * as React from "react"
import * as RechartsPrimitive from "recharts"
import { ChartContainer } from "./chart-container"
import { ChartTooltip, ChartTooltipContent } from "./chart-tooltip"
import { ChartConfig } from "./chart-types"

export interface BarChartProps {
  data: { 
    labels: string[]
    datasets: Array<{
      data: number[]
      backgroundColor: string[]
    }>
  }
  height?: number
}

export const BarChart: React.FC<BarChartProps> = ({ 
  data, 
  height = 300
}) => {
  const config: ChartConfig = {}
  
  return (
    <ChartContainer config={config} className="w-full" style={{ height }}>
      <RechartsPrimitive.BarChart data={data.labels.map((label, index) => ({
        name: label,
        value: data.datasets[0].data[index]
      }))}>
        <RechartsPrimitive.CartesianGrid strokeDasharray="3 3" vertical={false} />
        <RechartsPrimitive.XAxis dataKey="name" />
        <RechartsPrimitive.YAxis />
        <ChartTooltip content={<ChartTooltipContent />} />
        <RechartsPrimitive.Bar 
          dataKey="value" 
          radius={[4, 4, 0, 0]} 
          fill="var(--color-primary, rgba(54, 162, 235, 0.6))"
        />
      </RechartsPrimitive.BarChart>
    </ChartContainer>
  )
}
