
import React from 'react';
import { NetworkErrorBoundary } from './NetworkErrorBoundary';
import { ErrorAlert } from './ErrorAlert';
import { useAuth } from '@/contexts/AuthContext';
import { supabase, cleanAuthData } from '@/lib/supabase';
import { Button } from './button';
import { useNavigate } from 'react-router-dom';

interface AuthErrorHandlerProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  requiredRole?: string;
  redirectTo?: string;
}

export function AuthErrorHandler({
  children,
  fallback,
  requiredRole,
  redirectTo = '/auth'
}: AuthErrorHandlerProps) {
  const { user, sessionError, refreshSession } = useAuth();
  const navigate = useNavigate();

  // Fonction de test personnalisée pour NetworkErrorBoundary
  const testAuthConnection = async () => {
    const { data, error } = await supabase.auth.getSession();
    if (error) throw error;
    if (!data.session) {
      throw new Error("Aucune session active");
    }
  };

  const handleLogin = () => {
    // Nettoyer d'abord les données d'authentification
    cleanAuthData();
    navigate(redirectTo);
  };

  const handleEmergencyLogout = async () => {
    try {
      // Nettoyage complet des données d'authentification
      cleanAuthData();
      
      // Tentative de déconnexion via Supabase
      try {
        await supabase.auth.signOut({ scope: 'global' });
      } catch (e) {
        console.error("Erreur lors de la déconnexion Supabase:", e);
      }
      
      // Redirection forcée
      console.log("Déconnexion d'urgence - redirection vers la page d'authentification");
      window.location.href = '/auth';
    } catch (e) {
      console.error("Erreur lors de la déconnexion d'urgence:", e);
      // Redirection même en cas d'erreur
      window.location.href = '/auth';
    }
  };

  // Si l'utilisateur n'est pas connecté
  if (!user) {
    return fallback ? (
      <>{fallback}</>
    ) : (
      <div className="p-4">
        <ErrorAlert
          title="Authentification requise"
          message="Vous devez être connecté pour accéder à cette fonctionnalité."
        />
        <div className="flex gap-2 mt-4">
          <Button 
            variant="default" 
            onClick={handleLogin}
          >
            Se connecter
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleEmergencyLogout}
          >
            Déconnexion d'urgence
          </Button>
        </div>
      </div>
    );
  }

  // Si un rôle spécifique est requis et que l'utilisateur n'a pas ce rôle
  if (requiredRole && user.role !== requiredRole) {
    return (
      <div className="p-4">
        <ErrorAlert
          title="Accès refusé"
          message={`Vous devez avoir le rôle "${requiredRole}" pour accéder à cette fonctionnalité.`}
        />
        <div className="flex gap-2 mt-4">
          <Button 
            variant="outline" 
            onClick={() => navigate('/')}
          >
            Retour à l'accueil
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleEmergencyLogout}
          >
            Déconnexion d'urgence
          </Button>
        </div>
      </div>
    );
  }

  // Si erreur de session persistante
  if (sessionError) {
    return (
      <div className="p-4">
        <ErrorAlert
          title="Erreur de session"
          message={sessionError}
        />
        <div className="flex gap-2 mt-4">
          <Button 
            variant="outline" 
            onClick={refreshSession}
          >
            Rafraîchir la session
          </Button>
          <Button 
            variant="destructive" 
            onClick={handleEmergencyLogout}
          >
            Déconnexion d'urgence
          </Button>
        </div>
      </div>
    );
  }

  // Utiliser le NetworkErrorBoundary avec le type 'auth'
  return (
    <NetworkErrorBoundary
      type="auth"
      fallback={fallback}
      testQuery={testAuthConnection}
      onRetry={refreshSession}
    >
      {children}
    </NetworkErrorBoundary>
  );
}
