
import React from 'react';
import { ErrorAlert } from './ErrorAlert';
import { InfoAlert } from './InfoAlert';
import { ErrorSeverity } from '@/hooks/useErrorHandling';

interface ErrorStateHandlerProps {
  children: React.ReactNode;
  error: { message: string; severity: ErrorSeverity } | null;
  context?: string;
  withFallback?: boolean;
  fallback?: React.ReactNode;
}

/**
 * Composant pour gérer l'affichage d'erreurs avec différents niveaux de sévérité
 */
export function ErrorStateHandler({
  children,
  error,
  context = 'Application',
  withFallback = true,
  fallback
}: ErrorStateHandlerProps) {
  // Si pas d'erreur, afficher les enfants normalement
  if (!error) {
    return <>{children}</>;
  }

  // Si withFallback est false, afficher l'erreur mais aussi les enfants
  if (!withFallback) {
    return (
      <>
        {renderError(error, context)}
        {children}
      </>
    );
  }

  // Sinon, afficher l'erreur et le fallback s'il est fourni
  return (
    <>
      {renderError(error, context)}
      {fallback}
    </>
  );
}

// Helper pour générer l'alerte appropriée en fonction de la sévérité
function renderError(
  error: { message: string; severity: ErrorSeverity },
  context: string
) {
  const errorMessage = error.message as string; // Type assertion here
  
  switch (error.severity) {
    case 'info':
      return (
        <InfoAlert
          title={`Information - ${context}`}
          message={errorMessage}
          severity="low"
        />
      );
    case 'warning':
      return (
        <InfoAlert
          title={`Avertissement - ${context}`}
          message={errorMessage}
          severity="medium"
        />
      );
    case 'error':
    case 'fatal':
    default:
      return (
        <ErrorAlert
          title={`Erreur - ${context}`}
          message={errorMessage}
        />
      );
  }
}
