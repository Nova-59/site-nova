
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Info, AlertTriangle } from "lucide-react";
import { Button } from "./button";
import { ErrorSeverity } from "@/hooks/useErrorHandling";

interface ErrorAlertProps {
  title?: string;
  message: string;
  className?: string;
  severity?: ErrorSeverity;
  code?: string | number | null;
  actions?: {
    label: string;
    onClick: () => void;
    variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  }[];
}

export function ErrorAlert({ 
  title, 
  message, 
  className = "", 
  severity = "error",
  code,
  actions
}: ErrorAlertProps) {
  // Déterminer la variante et l'icône en fonction de la sévérité
  let variant: "default" | "destructive";
  let Icon;
  let titleText;
  
  switch (severity) {
    case "info":
      variant = "default";
      Icon = Info;
      titleText = title || "Information";
      break;
    case "warning":
      variant = "default";
      Icon = AlertTriangle;
      titleText = title || "Attention";
      break;
    case "fatal":
      variant = "destructive";
      Icon = AlertCircle;
      titleText = title || "Erreur critique";
      break;
    case "error":
    default:
      variant = "destructive";
      Icon = AlertCircle;
      titleText = title || "Erreur";
      break;
  }

  return (
    <Alert variant={variant} className={`mb-4 ${className}`}>
      <Icon className="h-4 w-4" />
      <AlertTitle>{titleText}</AlertTitle>
      <AlertDescription className="space-y-2">
        <div>{message}</div>
        {code && (
          <div className="text-xs text-muted-foreground">
            {typeof code === 'number' ? `Code: ${code}` : code}
          </div>
        )}
        {actions && actions.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {actions.map((action, index) => (
              <Button
                key={index}
                variant={action.variant || "outline"}
                size="sm"
                onClick={action.onClick}
              >
                {action.label}
              </Button>
            ))}
          </div>
        )}
      </AlertDescription>
    </Alert>
  );
}
