
import React from "react";
import { cn } from "@/lib/utils";
import { CheckCircle2 } from "lucide-react";

interface StepProps {
  title: string;
  description?: string;
  icon?: React.ReactNode;
  active?: boolean;
  completed?: boolean;
  last?: boolean;
}

interface StepsProps {
  active: number;
  children: React.ReactNode;
  className?: string;
}

export function Step({
  title,
  description,
  icon,
  active = false,
  completed = false,
  last = false,
}: StepProps) {
  return (
    <div className={cn(
      "flex items-start transition-all duration-300", 
      active && "scale-105"
    )}>
      <div className="flex flex-col items-center">
        <div
          className={cn(
            "flex h-8 w-8 items-center justify-center rounded-full border-2 transition-all duration-300",
            active && "border-primary bg-primary text-primary-foreground shadow-md",
            completed && "border-primary bg-primary text-primary-foreground",
            !active && !completed && "border-muted-foreground bg-background text-muted-foreground hover:border-primary/50"
          )}
        >
          {completed ? (
            <CheckCircle2 className="h-6 w-6 animate-fade-in" />
          ) : (
            icon || <span className="text-sm font-medium"></span>
          )}
        </div>
        {!last && (
          <div
            className={cn(
              "mt-1 h-10 w-0.5 transition-all duration-300",
              active && "bg-primary",
              completed && "bg-primary",
              !active && !completed && "bg-muted-foreground/30"
            )}
          />
        )}
      </div>
      <div className={cn(
        "ml-4 pb-8 transition-all duration-300",
        active && "translate-x-1"
      )}>
        <p
          className={cn(
            "text-sm font-medium",
            active && "text-foreground",
            !active && completed && "text-foreground",
            !active && !completed && "text-muted-foreground"
          )}
        >
          {title}
        </p>
        {description && (
          <p
            className={cn(
              "text-sm",
              active && "text-muted-foreground",
              !active && !completed && "text-muted-foreground/60"
            )}
          >
            {description}
          </p>
        )}
      </div>
    </div>
  );
}

export function Steps({ active, children, className }: StepsProps) {
  // Convert children to array and add the necessary props
  const stepsArray = React.Children.toArray(children);
  const steps = stepsArray.map((step, index) => {
    if (React.isValidElement<StepProps>(step)) {
      return React.cloneElement(step, {
        active: index + 1 === active,
        completed: index + 1 < active,
        last: index === stepsArray.length - 1,
      });
    }
    return step;
  });

  return <div className={cn("flex flex-col", className)}>{steps}</div>;
}
