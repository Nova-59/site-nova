
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { CheckCircle } from "lucide-react";

interface SuccessAlertProps {
  title?: string;
  message: string;
  className?: string;
}

export function SuccessAlert({ title = "Succès", message, className = "" }: SuccessAlertProps) {
  return (
    <Alert variant="default" className={`bg-green-50 border-green-200 text-green-800 mb-4 ${className}`}>
      <CheckCircle className="h-4 w-4 text-green-600" />
      <AlertTitle>{title}</AlertTitle>
      <AlertDescription className="text-green-700">
        {message}
      </AlertDescription>
    </Alert>
  );
}
