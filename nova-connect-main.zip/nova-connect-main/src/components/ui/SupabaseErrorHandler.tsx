
import React, { useState, useEffect } from 'react';
import { NetworkErrorBoundary } from './NetworkErrorBoundary';
import { ErrorAlert } from './ErrorAlert';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { useRlsPolicy } from '@/hooks/useRlsPolicy';

type TableName = "profiles" | "project_bids" | "projects";

interface SupabaseErrorHandlerProps {
  children: React.ReactNode;
  fallback?: React.ReactNode;
  requireAuth?: boolean;
  tableName?: TableName; // Now properly typed
}

export function SupabaseErrorHandler({
  children,
  fallback,
  requireAuth = false,
  tableName
}: SupabaseErrorHandlerProps) {
  const { user, refreshSession, sessionError } = useAuth();
  const [authChecked, setAuthChecked] = useState(!requireAuth);
  
  // Utiliser notre nouveau hook si un nom de table est fourni
  const rlsPolicy = tableName ? useRlsPolicy({
    tableName,
    showToast: false
  }) : null;

  useEffect(() => {
    // Si l'authentification est requise, vérifier que l'utilisateur est connecté
    if (requireAuth && !authChecked) {
      if (!user) {
        setAuthChecked(true);
      } else {
        setAuthChecked(true);
      }
    }
  }, [user, requireAuth, authChecked]);

  // Fonction de test personnalisée pour NetworkErrorBoundary
  const testSupabaseConnection = async () => {
    // Test d'authentification si nécessaire
    if (requireAuth) {
      const { data, error } = await supabase.auth.getSession();
      if (error) throw error;
      if (requireAuth && (!data.session || !data.session.user)) {
        throw new Error("Session d'authentification invalide");
      }
    }
    
    // Test d'accès à la table si spécifiée
    if (tableName) {
      const { error } = await supabase.from(tableName).select('*').limit(1);
      if (error) throw error;
    } else {
      // Test simple avec une table connue
      const { error } = await supabase.from('profiles').select('*').limit(1);
      if (error) throw error;
    }
  };

  // Si l'authentification est requise mais l'utilisateur n'est pas connecté
  if (requireAuth && authChecked && !user) {
    return fallback ? (
      <>{fallback}</>
    ) : (
      <ErrorAlert
        title="Authentification requise"
        message="Vous devez être connecté pour accéder à cette fonctionnalité."
      />
    );
  }

  // Si erreur de session persistante
  if (sessionError) {
    return (
      <div className="p-4">
        <ErrorAlert
          title="Erreur de session"
          message={sessionError}
        />
      </div>
    );
  }

  // Si erreur d'accès à la table via RLS
  if (rlsPolicy && !rlsPolicy.isChecking && !rlsPolicy.hasAccess) {
    return (
      <div className="p-4">
        <ErrorAlert
          title="Erreur d'accès aux données"
          message={rlsPolicy.error?.message || `Vous n'avez pas les permissions nécessaires pour accéder à la table ${tableName}.`}
        />
      </div>
    );
  }

  // Utiliser le NetworkErrorBoundary avec le type 'supabase'
  return (
    <NetworkErrorBoundary
      type="supabase"
      fallback={fallback}
      testQuery={testSupabaseConnection}
      onRetry={requireAuth ? refreshSession : undefined}
    >
      {children}
    </NetworkErrorBoundary>
  );
}
