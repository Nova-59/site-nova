
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { InfoIcon } from "lucide-react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const infoAlertVariants = cva(
  "bg-blue-50 border-blue-200 text-blue-800",
  {
    variants: {
      severity: {
        low: "bg-blue-50 border-blue-200 text-blue-800",
        medium: "bg-amber-50 border-amber-200 text-amber-800",
        high: "bg-orange-50 border-orange-200 text-orange-800",
      },
    },
    defaultVariants: {
      severity: "low",
    },
  }
);

interface InfoAlertProps extends VariantProps<typeof infoAlertVariants> {
  title?: string;
  message: string;
  className?: string;
}

export function InfoAlert({ 
  title = "Information", 
  message, 
  className = "",
  severity = "low" 
}: InfoAlertProps) {
  const iconColors = {
    low: "text-blue-600",
    medium: "text-amber-600",
    high: "text-orange-600"
  };

  return (
    <Alert 
      variant="default" 
      className={cn(infoAlertVariants({ severity }), className, "mb-4")}
    >
      <InfoIcon className={`h-4 w-4 ${iconColors[severity]}`} />
      <AlertTitle>{title}</AlertTitle>
      <AlertDescription className={severity === "low" ? "text-blue-700" : severity === "medium" ? "text-amber-700" : "text-orange-700"}>
        {message}
      </AlertDescription>
    </Alert>
  );
}
