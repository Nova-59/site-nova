
import * as React from "react"

import {
  ChartContainer,
  BarChart as BarChartPrimitive,
  LineChart as LineChartPrimitive,
  PieChart as PieChartPrimitive,
  RadarChart as RadarChartPrimitive,
} from "@/components/ui/charts"

const chartConfig = {
  line: {
    label: "Line Chart",
    theme: {
      light: "#0077cc",
      dark: "#3498db",
    },
  },
  bar: {
    label: "Bar Chart",
    theme: {
      light: "#10b981",
      dark: "#34d399",
    },
  },
  pie: {
    label: "Pie Chart",
    theme: {
      light: "#f59e0b",
      dark: "#fbbf24",
    },
  },
  radar: {
    label: "Radar Chart",
    theme: {
      light: "#8b5cf6",
      dark: "#a78bfa",
    },
  },
} as const

const Chart = ChartContainer

// Re-export chart components with default config
const BarChart = React.forwardRef<
  React.ElementRef<typeof BarChartPrimitive>,
  React.ComponentPropsWithoutRef<typeof BarChartPrimitive>
>((props, ref) => (
  <Chart ref={ref} config={chartConfig} {...props}>
    <BarChartPrimitive {...props} />
  </Chart>
))
BarChart.displayName = "BarChart"

const LineChart = React.forwardRef<
  React.ElementRef<typeof LineChartPrimitive>,
  React.ComponentPropsWithoutRef<typeof LineChartPrimitive>
>((props, ref) => (
  <Chart ref={ref} config={chartConfig} {...props}>
    <LineChartPrimitive {...props} />
  </Chart>
))
LineChart.displayName = "LineChart"

const PieChart = React.forwardRef<
  React.ElementRef<typeof PieChartPrimitive>,
  React.ComponentPropsWithoutRef<typeof PieChartPrimitive>
>((props, ref) => (
  <Chart ref={ref} config={chartConfig} {...props}>
    <PieChartPrimitive {...props} />
  </Chart>
))
PieChart.displayName = "PieChart"

const RadarChart = React.forwardRef<
  React.ElementRef<typeof RadarChartPrimitive>,
  React.ComponentPropsWithoutRef<typeof RadarChartPrimitive>
>((props, ref) => (
  <Chart ref={ref} config={chartConfig} {...props}>
    <RadarChartPrimitive {...props} />
  </Chart>
))
RadarChart.displayName = "RadarChart"

export { Chart, BarChart, LineChart, PieChart, RadarChart }
