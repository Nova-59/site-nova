import { useState, useEffect, ReactNode, useCallback } from "react";
import { ErrorAlert } from "./ErrorAlert";
import { InfoAlert } from "./InfoAlert";
import { Button } from "./button";
import { RefreshCw } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useErrorHandling } from "@/hooks/useErrorHandling";

export type ErrorBoundaryType = 'network' | 'supabase' | 'auth' | 'general';

interface NetworkErrorBoundaryProps {
  children: ReactNode;
  fallback?: ReactNode;
  onRetry?: () => void;
  type?: ErrorBoundaryType;
  checkInterval?: number; // En millisecondes
  testQuery?: () => Promise<any>; // Fonction de test personnalisée
}

export function NetworkErrorBoundary({ 
  children, 
  fallback, 
  onRetry,
  type = 'network',
  checkInterval = 30000, // 30 secondes par défaut
  testQuery
}: NetworkErrorBoundaryProps) {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const { handleError } = useErrorHandling({
    showToast: false,
    logToConsole: true
  });

  const getErrorInfo = (errorType: ErrorBoundaryType, customMessage?: string) => {
    switch (errorType) {
      case 'supabase':
        return {
          title: "Problème de connexion à la base de données",
          message: customMessage || "Impossible de se connecter à la base de données. Veuillez réessayer ultérieurement."
        };
      case 'auth':
        return {
          title: "Problème d'authentification",
          message: customMessage || "Impossible de vérifier votre session. Veuillez vous reconnecter."
        };
      case 'network':
        return {
          title: "Erreur de connexion",
          message: customMessage || "Vous êtes actuellement hors ligne. Veuillez vérifier votre connexion internet."
        };
      default:
        return {
          title: "Erreur",
          message: customMessage || "Une erreur est survenue. Veuillez réessayer ultérieurement."
        };
    }
  };

  const checkSupabaseConnection = useCallback(async () => {
    if (isChecking) return;
    
    try {
      setIsChecking(true);
      
      if (testQuery) {
        await testQuery();
      } else {
        const { error } = await supabase.from('profiles').select('id').limit(1);
        if (error) throw error;
      }
      
      setConnectionError(null);
    } catch (err) {
      const result = handleError(err, `${type}-connection-check`);
      setConnectionError(result.message);
    } finally {
      setIsChecking(false);
    }
  }, [isChecking, testQuery, type, handleError]);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    if (type !== 'network' || isOnline) {
      checkSupabaseConnection();
    }
    
    const intervalId = setInterval(() => {
      if (type !== 'network' || isOnline) {
        checkSupabaseConnection();
      }
    }, checkInterval);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(intervalId);
    };
  }, [type, isOnline, checkInterval, checkSupabaseConnection]);

  const retry = async () => {
    setConnectionError(null);
    
    await checkSupabaseConnection();
    
    if (onRetry) onRetry();
  };

  if (type === 'network' && !isOnline) {
    if (fallback) return <>{fallback}</>;
    
    const errorInfo = getErrorInfo('network');
    
    return (
      <div className="p-4">
        <ErrorAlert 
          title={errorInfo.title}
          message={errorInfo.message}
        />
        <Button 
          variant="outline" 
          onClick={retry} 
          className="mt-4 flex items-center gap-2"
          disabled={isChecking}
        >
          <RefreshCw className={`h-4 w-4 ${isChecking ? 'animate-spin' : ''}`} /> 
          {isChecking ? 'Vérification...' : 'Réessayer'}
        </Button>
      </div>
    );
  }

  if (connectionError) {
    if (fallback) return <>{fallback}</>;
    
    const errorInfo = getErrorInfo(type, connectionError);
    
    return (
      <div className="p-4">
        <ErrorAlert 
          title={errorInfo.title}
          message={errorInfo.message}
        />
        <Button 
          variant="outline" 
          onClick={retry} 
          className="mt-4 flex items-center gap-2"
          disabled={isChecking}
        >
          <RefreshCw className={`h-4 w-4 ${isChecking ? 'animate-spin' : ''}`} /> 
          {isChecking ? 'Vérification...' : 'Réessayer'}
        </Button>
      </div>
    );
  }

  return <>{children}</>;
}
