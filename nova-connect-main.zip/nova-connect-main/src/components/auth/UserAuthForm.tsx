import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff, Home, Hammer, ClipboardCheck } from "lucide-react";
import { t } from "@/lib/i18n";
import { UserRole } from "@/types/user";
import { useAuth } from "@/contexts/AuthContext";
import { cleanAuthData } from "@/lib/supabase-client";

const ADMIN_EMAIL = 'direction@nova-aps.com';

interface UserAuthFormProps {
  onAuthenticate: (email: string, password: string, isSignUp: boolean, role: UserRole) => void;
}

export function UserAuthForm({ onAuthenticate }: UserAuthFormProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<UserRole>("homeowner");
  const { toast } = useToast();
  const { signIn, signUp, resetPassword } = useAuth();
  
  const isMountedRef = useRef(true);
  
  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const validateForm = (): boolean => {
    setErrorMessage(null);
    
    if (!email || !email.trim()) {
      setErrorMessage("L'adresse email est requise");
      toast({
        variant: "destructive",
        title: "Champ manquant",
        description: "L'adresse email est requise"
      });
      return false;
    }
    
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
      setErrorMessage("Format d'email invalide");
      toast({
        variant: "destructive",
        title: "Format invalide",
        description: "Veuillez entrer une adresse email valide"
      });
      return false;
    }
    
    if (!isForgotPassword && !password) {
      setErrorMessage("Le mot de passe est requis");
      toast({
        variant: "destructive",
        title: "Champ manquant",
        description: "Le mot de passe est requis"
      });
      return false;
    }
    
    if (isSignUp && email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      setErrorMessage("Cette adresse email n'est pas disponible pour l'inscription");
      toast({
        variant: "destructive",
        title: "Inscription impossible",
        description: "Cette adresse email n'est pas disponible pour l'inscription"
      });
      return false;
    }
    
    if (isSignUp) {
      if (password !== confirmPassword) {
        setErrorMessage("Les mots de passe ne correspondent pas");
        toast({
          variant: "destructive",
          title: "Les mots de passe ne correspondent pas",
          description: "Veuillez vous assurer que vos mots de passe correspondent."
        });
        return false;
      }
      
      if (password.length < 6) {
        setErrorMessage("Le mot de passe doit contenir au moins 6 caractères");
        toast({
          variant: "destructive",
          title: "Mot de passe trop court",
          description: "Le mot de passe doit contenir au moins 6 caractères"
        });
        return false;
      }
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    setSuccessMessage(null);
    
    try {
      cleanAuthData();
      
      if (isForgotPassword) {
        console.log(`Demande de réinitialisation de mot de passe pour: ${email}`);
        
        const { error } = await resetPassword(email);
        if (error && isMountedRef.current) {
          console.error("Erreur de réinitialisation:", error);
          setErrorMessage(error.message || "Échec de la réinitialisation du mot de passe");
          toast({
            variant: "destructive",
            title: "Échec de la réinitialisation",
            description: error.message || "Un problème est survenu lors de votre demande"
          });
          return;
        }
        
        if (isMountedRef.current) {
          setSuccessMessage("Un email de réinitialisation a été envoyé à votre adresse email");
          toast({
            title: "Email envoyé",
            description: "Veuillez vérifier votre boîte mail pour réinitialiser votre mot de passe"
          });
        }
        return;
      } else if (isSignUp) {
        console.log(`Création d'un compte ${userRole}`);
        
        const { error, user } = await signUp(email, password, userRole);
        if (error && isMountedRef.current) {
          console.error("Erreur d'inscription:", error);
          setErrorMessage(error.message || "Échec de la création du compte");
          toast({
            variant: "destructive",
            title: "Échec de la création du compte",
            description: error.message || "Un problème est survenu lors de votre demande"
          });
          return;
        }
        
        if (isMountedRef.current) {
          toast({
            title: "Compte créé",
            description: userRole === "craftsman" ? 
              "Votre compte artisan a été créé. Un administrateur validera votre profil prochainement." : 
              "Votre compte a été créé avec succès."
          });
        }
      } else {
        console.log("Tentative de connexion avec:", email);
        
        let loadingToastId = null;
        if (isMountedRef.current) {
          loadingToastId = toast({
            title: "Connexion en cours",
            description: "Veuillez patienter pendant la connexion..."
          });
        }
        
        const { error } = await signIn(email, password);
        
        if (isMountedRef.current && loadingToastId) {
          if (error) {
            toast({
              variant: "destructive",
              title: "Échec de l'authentification",
              description: error.message || "Un problème est survenu lors de votre demande"
            });
            return;
          }
        }
        
        if (isMountedRef.current) {
          toast({
            title: "Bienvenue",
            description: "Vous êtes connecté avec succès"
          });
        }
      }
      
      if (isMountedRef.current) {
        onAuthenticate(email, password, isSignUp, isSignUp ? userRole : "homeowner");
      }
      
    } catch (error: any) {
      if (isMountedRef.current) {
        console.error("Erreur générale d'authentification:", error);
        setErrorMessage(error.message || "Erreur inattendue");
        toast({
          variant: "destructive",
          title: "Échec de l'authentification",
          description: error.message || "Une erreur inattendue s'est produite"
        });
      }
    } finally {
      if (isMountedRef.current) {
        setIsLoading(false);
      }
    }
  };

  const toggleSignUp = () => {
    setIsSignUp(!isSignUp);
    setIsForgotPassword(false);
    setErrorMessage(null);
    setSuccessMessage(null);
    setEmail("");
    setPassword("");
    setConfirmPassword("");
    cleanAuthData();
  };

  const toggleForgotPassword = () => {
    setIsForgotPassword(!isForgotPassword);
    setIsSignUp(false);
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
          {isForgotPassword 
            ? "Réinitialisation du mot de passe" 
            : isSignUp 
              ? "Créer un compte" 
              : "Connexion"}
        </CardTitle>
        <CardDescription className="text-center">
          {isForgotPassword 
            ? "Entrez votre email pour recevoir un lien de réinitialisation" 
            : isSignUp 
              ? "Entrez vos informations pour créer un compte" 
              : "Entrez vos identifiants pour vous connecter"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
              {errorMessage}
            </div>
          )}
          
          {successMessage && (
            <div className="p-3 bg-green-50 border border-green-200 text-green-600 rounded-md text-sm">
              {successMessage}
            </div>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="nom@exemple.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              aria-invalid={errorMessage ? "true" : "false"}
            />
          </div>
          
          {!isForgotPassword && (
            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"} 
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  aria-invalid={errorMessage ? "true" : "false"}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute right-2 top-1/2 -translate-y-1/2"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </Button>
              </div>
              {isSignUp && <p className="text-xs text-gray-500 mt-1">Le mot de passe doit contenir au moins 6 caractères</p>}
            </div>
          )}
          
          {isSignUp && !isForgotPassword && (
            <>
              <div className="space-y-2">
                <Label htmlFor="confirmPassword">Confirmer le mot de passe</Label>
                <div className="relative">
                  <Input
                    id="confirmPassword"
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    minLength={6}
                    aria-invalid={errorMessage ? "true" : "false"}
                  />
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-lg font-medium block mb-3">Qui êtes-vous ?</Label>
                <RadioGroup 
                  value={userRole} 
                  onValueChange={(value) => setUserRole(value as UserRole)}
                  className="flex flex-col space-y-3 mt-2"
                >
                  <div className={`flex items-center space-x-2 border rounded-lg p-4 hover:bg-slate-50 cursor-pointer transition-all ${userRole === "homeowner" ? "border-green-500 bg-green-50/30" : ""}`}>
                    <RadioGroupItem value="homeowner" id="homeowner" className="text-green-500" />
                    <Label htmlFor="homeowner" className="flex items-center cursor-pointer w-full">
                      <div className="bg-green-100 p-2 rounded-full mr-3">
                        <Home className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <span className="font-medium block">Particulier</span>
                        <span className="text-sm text-muted-foreground">Je souhaite trouver un artisan pour mes travaux</span>
                      </div>
                    </Label>
                  </div>
                  
                  <div className={`flex items-center space-x-2 border rounded-lg p-4 hover:bg-slate-50 cursor-pointer transition-all ${userRole === "craftsman" ? "border-blue-500 bg-blue-50/30" : ""}`}>
                    <RadioGroupItem value="craftsman" id="craftsman" className="text-blue-500" />
                    <Label htmlFor="craftsman" className="flex items-center cursor-pointer w-full">
                      <div className="bg-blue-100 p-2 rounded-full mr-3">
                        <Hammer className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <span className="font-medium block">Artisan</span>
                        <span className="text-sm text-muted-foreground">Je réalise des travaux pour des particuliers</span>
                      </div>
                    </Label>
                  </div>
                </RadioGroup>
              </div>
            </>
          )}
          
          <Button type="submit" className="w-full mt-6" disabled={isLoading}>
            {isLoading 
              ? "Traitement en cours..." 
              : isForgotPassword 
                ? "Envoyer le lien de réinitialisation" 
                : isSignUp 
                  ? "S'inscrire" 
                  : "Se connecter"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col justify-center text-sm gap-2">
        {!isForgotPassword && (
          <div>
            {isSignUp ? "Vous avez déjà un compte ?" : "Vous n'avez pas de compte ?"}{" "}
            <Button variant="link" className="p-0" onClick={toggleSignUp}>
              {isSignUp ? "Se connecter" : "S'inscrire"}
            </Button>
          </div>
        )}
        
        <div>
          {isForgotPassword ? (
            <Button variant="link" className="p-0" onClick={toggleForgotPassword}>
              Retour à la connexion
            </Button>
          ) : !isSignUp && (
            <Button variant="link" className="p-0" onClick={toggleForgotPassword}>
              Mot de passe oublié ?
            </Button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}
