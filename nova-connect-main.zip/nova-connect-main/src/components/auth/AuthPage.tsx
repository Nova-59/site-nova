
/**
 * Page d'authentification principale
 * Gère la connexion, l'inscription et les redirections
 */
import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { UserAuthForm } from "./UserAuthForm";
import { useAuth } from "@/contexts/AuthContext";
import { t } from "@/lib/i18n";
import { UserRole } from "@/types/user";
import { Progress } from "@/components/ui/progress";

export function AuthPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading, error } = useAuth();
  const [loadingProgress, setLoadingProgress] = useState(0);
  
  // Simuler une progression du chargement pour donner un retour visuel
  useEffect(() => {
    if (loading) {
      setLoadingProgress(0);
      const interval = setInterval(() => {
        setLoadingProgress(prev => {
          if (prev >= 95) return prev;
          return prev + 5;
        });
      }, 300);
      
      return () => clearInterval(interval);
    } else {
      setLoadingProgress(100);
      const timeout = setTimeout(() => setLoadingProgress(0), 500);
      return () => clearTimeout(timeout);
    }
  }, [loading]);
  
  // Debug information
  useEffect(() => {
    console.log("AuthPage rendered", {
      user: user?.email,
      role: user?.role,
      loading,
      path: location.pathname,
      state: location.state
    });
  }, [user, loading, location]);
  
  const handleAuthenticate = async (
    email: string, 
    password: string, 
    isSignUp: boolean, 
    role: UserRole
  ) => {
    // Déjà géré par UserAuthForm via useAuth
    // Ici, nous nous occupons uniquement de la redirection
    
    const from = location.state?.from?.pathname || "/";
    
    if (role === "admin") {
      console.log("Auth successful, redirecting admin to /admin");
      navigate("/admin");
    } else if (role === "craftsman") {
      navigate("/projects/marketplace");
    } else if (role === "homeowner") {
      navigate("/dashboard");
    } else {
      navigate(from);
    }
  };
  
  // Si l'utilisateur est déjà connecté, rediriger vers la page appropriée
  useEffect(() => {
    if (!loading && user) {
      console.log("User already authenticated, redirecting based on role:", user.role);
      
      // Add a small delay to ensure state is properly updated
      setTimeout(() => {
        if (user.role === "admin") {
          console.log("Admin user detected, redirecting to /admin");
          navigate("/admin", { replace: true });
        } else if (user.role === "craftsman") {
          navigate("/projects/marketplace", { replace: true });
        } else if (user.role === "homeowner") {
          navigate("/dashboard", { replace: true });
        } else {
          // Check if there's a previous location to return to
          const from = location.state?.from?.pathname || "/";
          navigate(from, { replace: true });
        }
      }, 200);
    }
  }, [user, loading, navigate, location]);
  
  // Show error message if authentication failed
  if (error) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="w-full max-w-lg px-4 py-6 bg-destructive/10 rounded-lg">
          <h2 className="text-xl font-bold text-destructive mb-2">Erreur d'authentification</h2>
          <p className="text-muted-foreground mb-4">{error.message}</p>
          <button 
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md"
            onClick={() => window.location.reload()}
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }
  
  if (loading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <div className="w-full max-w-lg px-4">
          <div className="flex items-center mb-4">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
            <span className="ml-2">Authentification en cours...</span>
          </div>
          <Progress value={loadingProgress} className="h-2 w-full" />
          <p className="text-sm text-muted-foreground mt-2">
            Veuillez patienter pendant la vérification de votre compte...
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen flex flex-col justify-center">
      <div className="container max-w-6xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="hidden md:flex flex-col space-y-6">
            <div className="space-y-2">
              <h1 className="text-3xl md:text-4xl font-bold text-brand-blue">NOVA Network</h1>
              <p className="text-xl text-muted-foreground">
                {t('connectingHomeowners')}
              </p>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-brand-blue text-white p-2 rounded-full">✓</div>
                <div>
                  <h3 className="font-semibold">{t('verifiedProfessionals')}</h3>
                  <p className="text-muted-foreground">{t('verifiedProfessionalsDesc')}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="bg-brand-orange text-white p-2 rounded-full">✓</div>
                <div>
                  <h3 className="font-semibold">{t('preVerifiedJobs')}</h3>
                  <p className="text-muted-foreground">{t('preVerifiedJobsDesc')}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="bg-brand-blue text-white p-2 rounded-full">✓</div>
                <div>
                  <h3 className="font-semibold">Paiements Sécurisés</h3>
                  <p className="text-muted-foreground">Système de paiement protégé pour votre tranquillité d'esprit</p>
                </div>
              </div>
            </div>
          </div>
          
          <div>
            <UserAuthForm onAuthenticate={handleAuthenticate} />
          </div>
        </div>
      </div>
    </div>
  );
}
