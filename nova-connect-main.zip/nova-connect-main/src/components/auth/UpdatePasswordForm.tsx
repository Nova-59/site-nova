
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Eye, EyeOff } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";

export function UpdatePasswordForm() {
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const { toast } = useToast();
  const { updatePassword } = useAuth();
  const navigate = useNavigate();

  const validateForm = (): boolean => {
    setErrorMessage(null);
    
    if (!password) {
      setErrorMessage("Le nouveau mot de passe est requis");
      toast({
        variant: "destructive",
        title: "Champ manquant",
        description: "Le nouveau mot de passe est requis"
      });
      return false;
    }
    
    if (password.length < 6) {
      setErrorMessage("Le mot de passe doit contenir au moins 6 caractères");
      toast({
        variant: "destructive",
        title: "Mot de passe trop court",
        description: "Le mot de passe doit contenir au moins 6 caractères"
      });
      return false;
    }
    
    if (password !== confirmPassword) {
      setErrorMessage("Les mots de passe ne correspondent pas");
      toast({
        variant: "destructive",
        title: "Les mots de passe ne correspondent pas",
        description: "Veuillez vous assurer que vos mots de passe correspondent."
      });
      return false;
    }
    
    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsLoading(true);
    setSuccessMessage(null);
    
    try {
      const { error, success } = await updatePassword(password);
      
      if (error) {
        console.error("Erreur de mise à jour du mot de passe:", error);
        setErrorMessage(error.message || "Échec de la mise à jour du mot de passe");
        toast({
          variant: "destructive",
          title: "Échec de la mise à jour",
          description: error.message || "Un problème est survenu lors de votre demande"
        });
        setIsLoading(false);
        return;
      }
      
      if (success) {
        setSuccessMessage("Votre mot de passe a été mis à jour avec succès");
        toast({
          title: "Mot de passe mis à jour",
          description: "Votre mot de passe a été modifié avec succès"
        });
        
        // Rediriger vers le tableau de bord après un court délai
        setTimeout(() => {
          navigate("/dashboard");
        }, 2000);
      }
    } catch (error: any) {
      console.error("Erreur générale de mise à jour du mot de passe:", error);
      setErrorMessage(error.message || "Erreur inattendue");
      toast({
        variant: "destructive",
        title: "Échec de la mise à jour",
        description: error.message || "Une erreur inattendue s'est produite"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl font-bold text-center">
          Réinitialisation du mot de passe
        </CardTitle>
        <CardDescription className="text-center">
          Veuillez saisir votre nouveau mot de passe
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {errorMessage && (
            <div className="p-3 bg-red-50 border border-red-200 text-red-600 rounded-md text-sm">
              {errorMessage}
            </div>
          )}
          
          {successMessage && (
            <div className="p-3 bg-green-50 border border-green-200 text-green-600 rounded-md text-sm">
              {successMessage}
            </div>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="password">Nouveau mot de passe</Label>
            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"} 
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                aria-invalid={errorMessage ? "true" : "false"}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="absolute right-2 top-1/2 -translate-y-1/2"
                onClick={() => setShowPassword(!showPassword)}
              >
                {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-1">Le mot de passe doit contenir au moins 6 caractères</p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Confirmer le mot de passe</Label>
            <div className="relative">
              <Input
                id="confirmPassword"
                type={showPassword ? "text" : "password"}
                placeholder="••••••••"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                required
                minLength={6}
                aria-invalid={errorMessage ? "true" : "false"}
              />
            </div>
          </div>
          
          <Button type="submit" className="w-full mt-6" disabled={isLoading}>
            {isLoading ? "Traitement en cours..." : "Mettre à jour le mot de passe"}
          </Button>
        </form>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button variant="link" onClick={() => navigate("/auth")}>
          Retour à la connexion
        </Button>
      </CardFooter>
    </Card>
  );
}
