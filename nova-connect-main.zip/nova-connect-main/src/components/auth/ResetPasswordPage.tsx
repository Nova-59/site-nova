
import { useEffect, useState } from "react";
import { UpdatePasswordForm } from "./UpdatePasswordForm";
import { supabase } from "@/lib/supabase-client";
import { useNavigate, useLocation } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { ErrorAlert } from "../ui/ErrorAlert";
import { Button } from "../ui/button";

export function ResetPasswordPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { toast } = useToast();
  const [isValidToken, setIsValidToken] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [processingHash, setProcessingHash] = useState(false);

  // Fonction utilitaire pour l'extraction des paramètres de l'URL
  const extractParams = () => {
    const hash = location.hash;
    const searchParams = new URLSearchParams(location.search);
    const hashParams = new URLSearchParams(hash.replace('#', '?'));
    
    console.log("URL complète:", window.location.href);
    console.log("Hash:", hash);
    console.log("Search params:", Object.fromEntries(searchParams.entries()));
    console.log("Hash params:", Object.fromEntries(hashParams.entries()));
    
    // Essayer de trouver le type et les tokens dans les paramètres d'URL et de hash
    const type = searchParams.get('type') || hashParams.get('type');
    const accessToken = searchParams.get('access_token') || hashParams.get('access_token');
    const refreshToken = searchParams.get('refresh_token') || hashParams.get('refresh_token');
    
    return { type, accessToken, refreshToken, hash, searchParams, hashParams };
  };

  // Fonction pour traiter le hash manuellement
  const processHashManually = async (hash: string) => {
    setProcessingHash(true);
    
    try {
      console.log("Traitement manuel du hash:", hash);
      
      if (!hash) {
        console.log("Aucun hash à traiter");
        return false;
      }
      
      // Construire un nouvel objet URL pour extraire les paramètres du hash
      // Le hash commence souvent par # donc on le remplace par ? pour le traiter comme un query string
      const hashParams = new URLSearchParams(hash.replace('#', '?'));
      console.log("Paramètres extraits du hash:", Object.fromEntries(hashParams.entries()));
      
      const type = hashParams.get('type');
      const accessToken = hashParams.get('access_token');
      const refreshToken = hashParams.get('refresh_token');
      
      if ((type === 'recovery' || type === 'passwordReset') && (accessToken || refreshToken)) {
        console.log("Tokens trouvés dans le hash, tentative de configuration de session");
        
        let sessionResult;
        if (accessToken && refreshToken) {
          sessionResult = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: refreshToken
          });
        } else if (accessToken) {
          sessionResult = await supabase.auth.setSession({
            access_token: accessToken,
            refresh_token: ""
          });
        } else if (refreshToken) {
          // Tenter avec seulement le refresh token si disponible
          console.log("Tentative avec refresh token uniquement");
          await supabase.auth.refreshSession({ refresh_token: refreshToken });
          
          // Vérifier si une session a été établie
          const { data } = await supabase.auth.getSession();
          if (data.session) {
            console.log("Session établie avec succès via refresh token");
            return true;
          }
          return false;
        }
        
        if (sessionResult?.data?.session) {
          console.log("Session établie avec succès via les tokens du hash");
          return true;
        } else if (sessionResult?.error) {
          console.error("Erreur lors de l'établissement de la session via les tokens du hash:", sessionResult.error);
        }
      }
      
      return false;
    } catch (error) {
      console.error("Erreur lors du traitement manuel du hash:", error);
      return false;
    } finally {
      setProcessingHash(false);
    }
  };

  useEffect(() => {
    // Vérifier si nous sommes sur cette page avec un token valide
    const checkResetToken = async () => {
      try {
        console.log("Début de la vérification du token de réinitialisation...");
        setIsLoading(true);
        setError(null);
        
        // Extraire tous les paramètres pertinents de l'URL
        const { type, accessToken, refreshToken, hash, searchParams, hashParams } = extractParams();
        
        // 1. Vérifier s'il existe une session active
        console.log("Vérification de session existante...");
        const { data: existingSession } = await supabase.auth.getSession();
        
        if (existingSession?.session) {
          console.log("Session existante trouvée, permettre la réinitialisation");
          setIsValidToken(true);
          setIsLoading(false);
          return;
        }
        
        // 2. Vérifier si nous avons des paramètres de type recovery ou passwordReset
        console.log(`Vérification des paramètres de type: ${type || 'aucun'}`);
        if ((type === 'recovery' || type === 'passwordReset') && (accessToken || refreshToken)) {
          console.log("Paramètres de réinitialisation détectés dans l'URL");
          
          try {
            let sessionResult;
            
            if (accessToken && refreshToken) {
              console.log("Utilisation de access_token et refresh_token");
              sessionResult = await supabase.auth.setSession({
                access_token: accessToken,
                refresh_token: refreshToken
              });
            } else if (accessToken) {
              console.log("Utilisation de access_token uniquement");
              sessionResult = await supabase.auth.setSession({
                access_token: accessToken,
                refresh_token: ""
              });
            } else if (refreshToken) {
              console.log("Utilisation de refresh_token uniquement");
              const refreshResult = await supabase.auth.refreshSession({
                refresh_token: refreshToken
              });
              sessionResult = refreshResult;
            }
            
            if (sessionResult?.data?.session) {
              console.log("Session établie avec succès à partir des tokens d'URL");
              setIsValidToken(true);
              setIsLoading(false);
              return;
            } else if (sessionResult?.error) {
              console.error("Erreur lors de l'établissement de la session:", sessionResult.error);
              throw sessionResult.error;
            }
          } catch (tokenError) {
            console.error("Exception lors de l'utilisation des tokens d'URL:", tokenError);
          }
        }
        
        // 3. Traiter le hash de façon manuelle si présent
        if (hash) {
          console.log("Tentative de traitement manuel du hash");
          const hashSuccess = await processHashManually(hash);
          
          if (hashSuccess) {
            console.log("Traitement manuel du hash réussi, session établie");
            setIsValidToken(true);
            setIsLoading(false);
            return;
          }
        }
        
        // 4. Dernière vérification: si un hash est présent mais vide, cela peut indiquer un problème de CORS
        if (hash === '#') {
          console.warn("Hash vide détecté. Cela peut indiquer un problème de CORS ou de redirection");
          toast({
            variant: "destructive",
            title: "Problème avec le lien de réinitialisation",
            description: "Un problème de redirection a été détecté. Veuillez vérifier les paramètres de redirection dans Supabase."
          });
        }
        
        // 5. Aucune méthode n'a fonctionné, afficher une erreur
        console.error("Aucune méthode de récupération de session n'a fonctionné");
        throw new Error("Le lien de réinitialisation est invalide ou a expiré. Veuillez demander un nouveau lien.");
        
      } catch (error) {
        console.error("Erreur lors de la vérification du token:", error);
        const errorMessage = error instanceof Error 
          ? error.message 
          : "Problème avec le lien de réinitialisation. Veuillez demander un nouveau lien.";
        
        setError(errorMessage);
        setIsValidToken(false);
        
        toast({
          variant: "destructive",
          title: "Problème avec le lien de réinitialisation",
          description: errorMessage
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    checkResetToken();
  }, [navigate, toast, location]);

  const handleRequestNewLink = () => {
    navigate("/auth", { 
      state: { showResetPassword: true },
      replace: true 
    });
  };

  // Méthode alternative pour réinitialiser le mot de passe directement sans token
  const handleManualReset = () => {
    // Rediriger vers la page d'authentification avec instruction d'utiliser 
    // la fonction "Mot de passe oublié"
    navigate("/auth", { 
      state: { showResetPassword: true },
      replace: true 
    });
    
    toast({
      title: "Réinitialisation manuelle",
      description: "Pour réinitialiser votre mot de passe, utilisez l'option 'Mot de passe oublié' sur la page de connexion.",
    });
  };

  if (isLoading || processingHash) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="flex flex-col items-center space-y-4">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
          <span>{processingHash ? "Traitement du lien de réinitialisation..." : "Vérification du lien..."}</span>
          <span className="text-xs text-gray-500">URL: {window.location.href.substring(0, 50)}...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col justify-center">
      <div className="container max-w-6xl">
        <div className="flex justify-center">
          <div className="w-full max-w-md">
            {isValidToken ? (
              <UpdatePasswordForm />
            ) : (
              <div className="text-center space-y-4">
                {error && (
                  <ErrorAlert 
                    title="Lien invalide" 
                    message={error}
                    severity="error"
                    actions={[
                      {
                        label: "Demander un nouveau lien",
                        onClick: handleRequestNewLink,
                        variant: "default"
                      }
                    ]}
                  />
                )}
                
                <div className="mt-6 space-y-4 p-6 border border-gray-200 rounded-lg bg-gray-50">
                  <h2 className="text-xl font-semibold">Méthode alternative</h2>
                  <p className="text-gray-600">
                    Si vous continuez à rencontrer des problèmes avec le lien de réinitialisation,
                    vous pouvez utiliser directement la fonction "Mot de passe oublié" sur la page de connexion.
                  </p>
                  <Button 
                    onClick={handleManualReset}
                    className="mt-2"
                  >
                    Réinitialiser manuellement
                  </Button>
                </div>
                
                <button 
                  onClick={() => navigate("/auth")}
                  className="text-primary hover:underline mt-4"
                >
                  Retour à la page de connexion
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
