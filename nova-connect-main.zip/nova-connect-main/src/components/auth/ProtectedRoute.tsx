
/**
 * Composant pour protéger les routes qui nécessitent une authentification
 * Gère automatiquement les redirections et les vérifications de rôles
 */
import { ReactNode, useEffect, useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { UserRole } from '@/types/user';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { RefreshCw } from 'lucide-react';

interface ProtectedRouteProps {
  children: ReactNode;
  roles?: UserRole[];
}

export function ProtectedRoute({ children, roles }: ProtectedRouteProps) {
  const { user, loading, refreshSession, error } = useAuth();
  const location = useLocation();
  const { toast } = useToast();
  const [showRefreshButton, setShowRefreshButton] = useState(false);

  // Afficher le bouton de rafraîchissement après un délai
  useEffect(() => {
    if (!loading) {
      setShowRefreshButton(false);
      return;
    }

    const timer = setTimeout(() => {
      setShowRefreshButton(true);
    }, 2000);

    return () => clearTimeout(timer);
  }, [loading]);

  // Journalisation pour le débogage
  useEffect(() => {
    console.log("État de ProtectedRoute:", { 
      user: user?.email, 
      userId: user?.id,
      userRole: user?.role, 
      requiredRoles: roles,
      loading,
      currentPath: location.pathname,
      hasError: error ? "Oui" : "Non"
    });
  }, [user, roles, loading, location.pathname, error]);

  // Si erreur de session détectée
  if (error) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-8">
        <div className="text-center mb-4">
          <h2 className="text-xl font-bold text-red-600 mb-2">Erreur de session</h2>
          <p className="text-gray-600">{error.message}</p>
        </div>
        
        <Button 
          variant="default" 
          onClick={() => {
            // Force logout and redirect to authentication
            localStorage.clear();
            sessionStorage.clear();
            document.cookie = "sb-access-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            document.cookie = "sb-refresh-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            window.location.href = '/auth';
          }}
          className="mt-4"
        >
          <RefreshCw className="h-4 w-4 mr-2" /> Se reconnecter
        </Button>
      </div>
    );
  }

  // Afficher l'indicateur de chargement
  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-8">
        <div className="flex items-center justify-center">
          <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
          <span className="ml-2">Vérification de l'accès...</span>
        </div>
        
        {showRefreshButton && (
          <div className="mt-6 text-center">
            <p className="text-sm text-gray-500 mb-2">
              Le chargement prend plus de temps que prévu.
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                refreshSession();
              }}
              className="flex items-center gap-2"
            >
              <RefreshCw className="h-4 w-4" /> Rafraîchir la session
            </Button>
          </div>
        )}
      </div>
    );
  }

  // Non authentifié - rediriger vers la page de connexion avec le chemin de retour
  if (!user) {
    console.log("Utilisateur non authentifié, redirection vers /auth");
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  // Important: Handle the guest role conversion properly
  const effectiveUser = { ...user };
  
  // Users with 'guest' role should now be treated as 'homeowner'
  if (effectiveUser.role === "guest") {
    console.log("Converting 'guest' role to 'homeowner' in UI");
    effectiveUser.role = "homeowner";
    
    // Update localStorage to persist the role change
    try {
      const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
      if (currentUser && currentUser.id === effectiveUser.id) {
        currentUser.role = "homeowner";
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        console.log("LocalStorage mis à jour pour convertir 'guest' en 'homeowner'");
      }
    } catch (error) {
      console.error("Erreur lors de la mise à jour du localStorage:", error);
    }
  }
  
  // Si aucun rôle n'est spécifié, autoriser l'accès à tout utilisateur authentifié
  if (!roles) {
    console.log("Aucun rôle spécifié, accès accordé à l'utilisateur authentifié");
    return <>{children}</>;
  }

  // Vérifier si l'utilisateur a le rôle requis (using the effective role)
  if (!roles.includes(effectiveUser.role)) {
    console.log(`Accès refusé: le rôle ${effectiveUser.role} de l'utilisateur n'est pas autorisé pour ${location.pathname}. Requis: ${roles.join(', ')}`);
    
    // Ajouter des logs supplémentaires pour diagnostiquer
    console.log("User object:", JSON.stringify(effectiveUser, null, 2));
    
    // Rediriger les utilisateurs vers leur tableau de bord approprié en fonction du rôle
    switch (effectiveUser.role) {
      case "admin":
        console.log("Utilisateur administrateur, redirection vers le tableau de bord d'administration");
        return <Navigate to="/admin" replace />;
      case "homeowner":
        console.log("Propriétaire, redirection vers le tableau de bord");
        return <Navigate to="/dashboard" replace />;
      case "craftsman":
        console.log("Artisan, redirection vers la place de marché");
        return <Navigate to="/projects/marketplace" replace />;
      case "estimator":
        console.log("Estimateur, redirection vers le tableau de bord");
        return <Navigate to="/dashboard" replace />;
      default:
        return <Navigate to="/" replace />;
    }
  }

  // L'utilisateur est authentifié et a le rôle requis - autoriser l'accès
  console.log(`Accès accordé à ${location.pathname} pour l'utilisateur ${effectiveUser.email} avec le rôle ${effectiveUser.role}`);
  return <>{children}</>;
}
