
import { useState, useRef } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, UserCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProfileAvatarProps {
  avatarUrl?: string;
  onAvatarChange: (file: File) => Promise<void>;
  name: string;
}

export function ProfileAvatar({ avatarUrl, onAvatarChange, name }: ProfileAvatarProps) {
  const [isUploading, setIsUploading] = useState(false);
  const { toast } = useToast();
  // Use useRef instead of useState for DOM references
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    // Check file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast({
        variant: "destructive",
        title: "Fichier trop volumineux",
        description: "La taille maximum autorisée est de 5 Mo",
      });
      return;
    }
    
    // Check file type
    if (!file.type.startsWith("image/")) {
      toast({
        variant: "destructive",
        title: "Type de fichier non pris en charge",
        description: "Veuillez sélectionner une image",
      });
      return;
    }
    
    setIsUploading(true);
    
    try {
      await onAvatarChange(file);
      toast({
        title: "Avatar mis à jour",
        description: "Votre photo de profil a été actualisée",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible de mettre à jour votre avatar",
      });
    } finally {
      setIsUploading(false);
    }
  };

  // Get the initials from the name
  const getInitials = () => {
    return name
      .split(" ")
      .map(part => part[0])
      .join("")
      .toUpperCase();
  };

  return (
    <Card>
      <CardContent className="flex flex-col items-center justify-center p-6 gap-4">
        <Avatar className="h-32 w-32 border-2 border-muted">
          {avatarUrl ? (
            <AvatarImage src={avatarUrl} alt={name} />
          ) : (
            <AvatarFallback className="text-3xl">
              {name ? getInitials() : <UserCircle className="h-16 w-16" />}
            </AvatarFallback>
          )}
        </Avatar>
        
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={handleFileChange}
          ref={fileInputRef}
        />
        
        <Button 
          variant="outline" 
          className="flex gap-2 w-full"
          onClick={() => fileInputRef.current?.click()}
          disabled={isUploading}
        >
          <Upload size={16} />
          {isUploading ? "Téléchargement..." : "Changer ma photo"}
        </Button>
      </CardContent>
    </Card>
  );
}
