
import { Link } from "react-router-dom";
import { Facebook, Instagram, Twitter, Linkedin, Mail, Phone, MapPin, Building } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { t } from "@/lib/i18n";

export function Footer() {
  return (
    <footer className="bg-slate-900 text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <img 
                src="/lovable-uploads/c1b6620d-afa0-4165-9b0c-e9689060ffcd.png" 
                alt="NOVA" 
                className="h-14"
              />
            </div>
            <p className="text-slate-300">
              {t('connectingHomeowners')}
            </p>
            <div className="flex items-center gap-3">
              <Button size="icon" variant="ghost" className="rounded-full text-white hover:text-white hover:bg-nova-yellow">
                <Facebook size={18} />
              </Button>
              <Button size="icon" variant="ghost" className="rounded-full text-white hover:text-white hover:bg-nova-yellow">
                <Instagram size={18} />
              </Button>
              <Button size="icon" variant="ghost" className="rounded-full text-white hover:text-white hover:bg-nova-yellow">
                <Twitter size={18} />
              </Button>
              <Button size="icon" variant="ghost" className="rounded-full text-white hover:text-white hover:bg-nova-yellow">
                <Linkedin size={18} />
              </Button>
            </div>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">{t('quickLinks')}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-slate-300 hover:text-white">{t('home')}</Link>
              </li>
              <li>
                <Link to="/services" className="text-slate-300 hover:text-white">{t('services')}</Link>
              </li>
              <li>
                <Link to="/how-it-works" className="text-slate-300 hover:text-white">{t('howItWorks')}</Link>
              </li>
              <li>
                <Link to="/for-craftsmen" className="text-slate-300 hover:text-white">{t('joinAsCraftsman')}</Link>
              </li>
              <li>
                <Link to="/about" className="text-slate-300 hover:text-white">{t('aboutUs')}</Link>
              </li>
              <li>
                <Link to="/contact" className="text-slate-300 hover:text-white">{t('contact')}</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">{t('services')}</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/services/plumbing" className="text-slate-300 hover:text-white">{t('plumbing')}</Link>
              </li>
              <li>
                <Link to="/services/electricity" className="text-slate-300 hover:text-white">{t('electricity')}</Link>
              </li>
              <li>
                <Link to="/services/carpentry" className="text-slate-300 hover:text-white">{t('carpentry')}</Link>
              </li>
              <li>
                <Link to="/services/painting" className="text-slate-300 hover:text-white">{t('painting')}</Link>
              </li>
              <li>
                <Link to="/services/tiling" className="text-slate-300 hover:text-white">{t('tiling')}</Link>
              </li>
              <li>
                <Link to="/services/gardening" className="text-slate-300 hover:text-white">{t('gardening')}</Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-semibold text-lg mb-4">{t('contact')}</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Mail size={20} className="shrink-0 mt-0.5" />
                <span className="text-slate-300">direction@nova-aps.com</span>
              </li>
              <li className="flex items-start gap-3">
                <Phone size={20} className="shrink-0 mt-0.5" />
                <span className="text-slate-300">06 38 44 32 42</span>
              </li>
              <li className="flex items-start gap-3">
                <MapPin size={20} className="shrink-0 mt-0.5" />
                <span className="text-slate-300">57 rue Victor Baltard, 59200 Tourcoing</span>
              </li>
              <li className="flex items-start gap-3">
                <Building size={20} className="shrink-0 mt-0.5" />
                <span className="text-slate-300">SIREN: 93326291700018</span>
              </li>
            </ul>
            
            <div className="mt-6">
              <h4 className="font-medium mb-2">{t('subscribeNewsletter')}</h4>
              <div className="flex gap-2">
                <Input 
                  type="email" 
                  placeholder={t('yourEmail')} 
                  className="bg-slate-800 border-slate-700 focus-visible:ring-nova-yellow" 
                />
                <Button className="bg-nova-yellow hover:bg-nova-yellow/90 text-black">
                  {t('subscribe')}
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <Separator className="my-8 bg-slate-700" />
        
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-slate-400 text-sm">
            © {new Date().getFullYear()} NOVA Artisans. {t('allRightsReserved')}
          </p>
          
          <div className="flex gap-4 text-sm">
            <Link to="/terms" className="text-slate-400 hover:text-white">
              {t('termsOfService')}
            </Link>
            <Link to="/privacy" className="text-slate-400 hover:text-white">
              {t('privacyPolicy')}
            </Link>
            <Link to="/cookies" className="text-slate-400 hover:text-white">
              {t('cookiesPolicy')}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
