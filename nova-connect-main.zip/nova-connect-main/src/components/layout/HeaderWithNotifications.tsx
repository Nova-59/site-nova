
import { Link } from "react-router-dom";
import { NavigationMenu } from "@/components/ui/navigation-menu";
import { NotificationDropdown } from "@/components/notifications/NotificationDropdown";
import { useAuth } from "@/contexts/AuthContext";
import { GuestNavigation } from "./navigation/GuestNavigation";
import { AdminNavigation } from "./navigation/AdminNavigation";
import { CraftsmanNavigation } from "./navigation/CraftsmanNavigation";
import { HomeownerNavigation } from "./navigation/HomeownerNavigation";
import { GuestProjectNavigation } from "./navigation/GuestProjectNavigation";
import { GuestActions } from "./actions/GuestActions";
import { AdminActions } from "./actions/AdminActions";
import { CraftsmanActions } from "./actions/CraftsmanActions";
import { HomeownerActions } from "./actions/HomeownerActions";
import { GuestProjectActions } from "./actions/GuestProjectActions";

export function HeaderWithNotifications() {
  const { user, signOut } = useAuth();

  console.log("HeaderWithNotifications - Current user:", user);

  // Navigation différente selon le rôle
  const renderRoleBasedNavigation = () => {
    if (!user) {
      return <GuestNavigation />;
    }
    
    if (user.role === 'admin') {
      return <AdminNavigation />;
    }
    
    if (user.role === 'craftsman') {
      return <CraftsmanNavigation />;
    }
    
    if (user.role === 'guest') {
      return <GuestProjectNavigation />;
    }
    
    // Default for homeowner
    return <HomeownerNavigation />;
  };

  // Boutons d'action selon le rôle
  const renderRoleBasedActions = () => {
    if (!user) {
      return <GuestActions />;
    }
    
    if (user.role === 'admin') {
      return <AdminActions signOut={signOut} />;
    }
    
    if (user.role === 'craftsman') {
      return <CraftsmanActions signOut={signOut} />;
    }
    
    if (user.role === 'guest') {
      return <GuestProjectActions signOut={signOut} />;
    }
    
    // Default for homeowner
    return <HomeownerActions signOut={signOut} />;
  };

  return (
    <header className="border-b bg-background">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-6">
          <Link to="/" className="flex items-center space-x-2">
            <span className="font-bold text-lg">NOVA</span>
          </Link>

          <NavigationMenu className="hidden md:block">
            {renderRoleBasedNavigation()}
          </NavigationMenu>
        </div>

        <div className="flex items-center gap-3">
          {user && (
            <div className="mr-2">
              <NotificationDropdown emptyNotifications={true} />
            </div>
          )}
          
          {renderRoleBasedActions()}
        </div>
      </div>
    </header>
  );
}
