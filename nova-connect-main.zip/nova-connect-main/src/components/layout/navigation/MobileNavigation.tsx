
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Home, LogOut, Menu, Settings, User } from "lucide-react";
import { t } from "@/lib/i18n";

interface MobileNavigationProps {
  currentUser: any | null;
  handleLogout: () => void;
  getInitials: (name: string) => string;
}

export function MobileNavigation({ currentUser, handleLogout, getInitials }: MobileNavigationProps) {
  const onLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log("Mobile logout button clicked");
    try {
      await handleLogout();
      console.log("Mobile logout handler completed");
      // Navigation handled by AuthContext
    } catch (err) {
      console.error("Error during mobile logout:", err);
      // Force reload as fallback
      window.location.href = '/';
    }
  };

  return (
    <div className="md:hidden flex justify-between items-center">
      <Link to="/" className="flex items-center">
        <img 
          src="/lovable-uploads/fac78569-0689-40f5-b7c1-75a36351a493.png" 
          alt="NOVA" 
          className="h-14"
        />
      </Link>
      
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="text-black">
            <Menu />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="bg-white backdrop-blur-md text-black border-gray-200">
          <div className="flex flex-col h-full">
            <div className="py-4">
              <Link to="/" className="flex items-center gap-2">
                <img 
                  src="/lovable-uploads/fac78569-0689-40f5-b7c1-75a36351a493.png" 
                  alt="NOVA" 
                  className="h-12"
                />
              </Link>
            </div>
            
            <nav className="flex flex-col gap-1 py-4">
              <Link to="/" className="px-4 py-2 hover:bg-gray-100 rounded-md text-black">{t('home')}</Link>
              <Link to="/services" className="px-4 py-2 hover:bg-gray-100 rounded-md text-black">{t('services')}</Link>
              <Link to="/how-it-works" className="px-4 py-2 hover:bg-gray-100 rounded-md text-black">{t('howItWorks')}</Link>
              <Link to="/about" className="px-4 py-2 hover:bg-gray-100 rounded-md text-black">{t('aboutUs')}</Link>
            </nav>
            
            {currentUser ? (
              <div className="mt-auto border-t border-gray-200 pt-4">
                <div className="flex items-center gap-3 px-4 py-2">
                  <Avatar className="h-10 w-10">
                    <AvatarImage src={currentUser.avatar} />
                    <AvatarFallback>{getInitials(currentUser.name)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium text-black">{currentUser.name}</p>
                    <p className="text-sm text-gray-600">{currentUser.email}</p>
                  </div>
                </div>
                
                <div className="flex flex-col gap-1 py-2">
                  <Link to="/dashboard" className="px-4 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2 text-black">
                    <Home size={16} />
                    <span>{t('dashboard')}</span>
                  </Link>
                  <Link to="/profile" className="px-4 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2 text-black">
                    <User size={16} />
                    <span>{t('profile')}</span>
                  </Link>
                  <Link to="/settings" className="px-4 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2 text-black">
                    <Settings size={16} />
                    <span>{t('settings')}</span>
                  </Link>
                  <button 
                    onClick={onLogout}
                    className="px-4 py-2 hover:bg-gray-100 rounded-md flex items-center gap-2 text-destructive"
                  >
                    <LogOut size={16} />
                    <span>{t('logOut')}</span>
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-auto border-t border-gray-200 pt-4 flex flex-col gap-2 px-4">
                <Link to="/auth">
                  <Button className="w-full bg-nova-yellow text-black hover:bg-nova-yellow/90">{t('signIn')}</Button>
                </Link>
                <Link to="/auth">
                  <Button variant="outline" className="w-full border-gray-300 text-black hover:bg-gray-100">{t('signUp')}</Button>
                </Link>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>
    </div>
  );
}
