
import { useState } from "react";
import { Link } from "react-router-dom";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { t } from "@/lib/i18n";

export function MainNavigation() {
  const [isOpen, setIsOpen] = useState(false);

  const closeMenu = () => {
    setIsOpen(false);
  };

  return (
    <div className="relative w-full py-3">
      <NavigationMenu className="w-full max-w-none">
        <NavigationMenuList className="flex justify-center gap-0">
          <NavigationMenuItem className="flex justify-center">
            <NavigationMenuLink asChild className="text-black hover:bg-gray-200 hover:text-nova-gold text-lg font-medium px-4 py-2 block text-center">
              <Link to="/">{t('home')}</Link>
            </NavigationMenuLink>
          </NavigationMenuItem>
          
          <NavigationMenuItem className="flex justify-center">
            <div className="relative">
              <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
                <DropdownMenuTrigger className="text-black hover:bg-gray-200 hover:text-nova-gold text-lg font-medium px-4 py-2">
                  {t('services')}
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-white border border-gray-200 shadow-md w-48 mt-2 z-50">
                  {[
                    { title: t('plumbing'), path: '/services/plumbing' },
                    { title: t('electricity'), path: '/services/electricity' },
                    { title: t('carpentry'), path: '/services/carpentry' },
                    { title: t('painting'), path: '/services/painting' },
                    { title: t('tiling'), path: '/services/tiling' },
                    { title: t('gardening'), path: '/services/gardening' },
                    { title: "Couverture", path: '/services/couverture' },
                    { title: "Charpente", path: '/services/charpente' },
                    { title: "Zinguerie", path: '/services/zinguerie' },
                  ].map((service) => (
                    <DropdownMenuItem key={service.title} asChild className="p-0">
                      <Link
                        to={service.path}
                        className="block px-4 py-2 hover:bg-gray-100 text-black w-full text-left"
                        onClick={closeMenu}
                      >
                        {service.title}
                      </Link>
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </NavigationMenuItem>

          <NavigationMenuItem className="flex justify-center">
            <NavigationMenuLink asChild className="text-black hover:bg-gray-200 hover:text-nova-gold text-lg font-medium px-4 py-2 block text-center">
              <Link to="/how-it-works">{t('howItWorks')}</Link>
            </NavigationMenuLink>
          </NavigationMenuItem>
          
          <NavigationMenuItem className="flex justify-center">
            <NavigationMenuLink asChild className="text-black hover:bg-gray-200 hover:text-nova-gold text-lg font-medium px-4 py-2 block text-center">
              <Link to="/about">{t('aboutUs')}</Link>
            </NavigationMenuLink>
          </NavigationMenuItem>
        </NavigationMenuList>
      </NavigationMenu>
    </div>
  );
}
