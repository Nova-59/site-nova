import { useState, useEffect, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";
import { MainNavigation } from "./navigation/MainNavigation";
import { MobileNavigation } from "./navigation/MobileNavigation";
import { AuthButtons } from "./auth/AuthButtons";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile } from "@/types/user";

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  // Gestion du défilement pour l'effet visuel du header
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Fonction centralisée et sécurisée pour la déconnexion
  const handleLogout = async () => {
    await signOut();
    navigate("/");
  };

  // Fonction optimisée pour obtenir les initiales avec gestion des valeurs nulles
  const getInitials = (name: string) => {
    if (!name || name.trim() === '') {
      // Protection contre email null/undefined
      return user?.email?.charAt(0)?.toUpperCase() || "U";
    }
    // Extraction sécurisée des initiales
    return name.split(" ")
      .filter(Boolean) // Filtre les segments vides
      .map(n => n[0] || '')
      .join("")
      .toUpperCase() || "U";
  };

  // Utilisation de useMemo pour éviter des recalculs inutiles
  const formattedUser = useMemo(() => {
    if (!user) return null;
    
    return {
      id: user.id,
      email: user.email || "",
      name: `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email || "",
      role: user.role,
      avatar: user.avatarUrl
    };
  }, [user]);

  return (
    <header 
      className={cn(
        "sticky top-0 w-full transition-all duration-200 z-30 bg-white/90 backdrop-blur-sm",
        isScrolled ? "border-b border-white/10 shadow-sm" : ""
      )}
    >
      <div className="container mx-auto px-4">
        {/* Banner Image - Updated with new image */}
        <div className="w-full nova-banner">
          <img 
            src="/lovable-uploads/e8d21bd7-09a5-458e-b50a-1cae44abecdf.png" 
            alt="NOVA CONNECT" 
            className="w-full h-auto"
          />
        </div>
        
        {/* Navigation with gradient background */}
        <div className="menu-container gradient-background">
          <div className="flex justify-between items-center">
            {/* Desktop Navigation - Hidden on Mobile */}
            <div className="hidden md:block flex-grow">
              <MainNavigation />
            </div>
            
            {/* Mobile Navigation - Visible only on Mobile */}
            <div className="md:hidden">
              <MobileNavigation 
                currentUser={formattedUser}
                handleLogout={handleLogout}
                getInitials={getInitials}
              />
            </div>
          </div>
        </div>

        {/* Auth Buttons - Centered below menu */}
        <div className="w-full flex justify-center py-4 bg-gray-100">
          <AuthButtons 
            currentUser={formattedUser}
            handleLogout={handleLogout}
            getInitials={getInitials}
            size="sm"
          />
        </div>
      </div>
    </header>
  );
}
