
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface AdminActionsProps {
  signOut: () => void;
}

export function AdminActions({ signOut }: AdminActionsProps) {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" asChild>
        <Link to="/admin">Tableau de bord Admin</Link>
      </Button>
      <Button variant="ghost" asChild>
        <Link to="/profile">Profil</Link>
      </Button>
      <Button variant="destructive" size="sm" onClick={() => signOut()}>
        Déconnexion
      </Button>
    </div>
  );
}
