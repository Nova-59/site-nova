
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

export function GuestActions() {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" asChild>
        <Link to="/auth">Espace artisans & clients</Link>
      </Button>
      <Button asChild>
        <Link to="/projects/submit">Trouver un artisan en Hauts-de-France</Link>
      </Button>
    </div>
  );
}
