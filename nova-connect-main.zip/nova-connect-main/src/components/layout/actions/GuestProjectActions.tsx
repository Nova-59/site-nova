
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface GuestProjectActionsProps {
  signOut: () => void;
}

export function GuestProjectActions({ signOut }: GuestProjectActionsProps) {
  return (
    <div className="flex items-center gap-2">
      <Button asChild className="mr-2">
        <Link to="/projects/submit">Soumettre un projet</Link>
      </Button>
      <Button variant="ghost" asChild>
        <Link to="/profile">Profil</Link>
      </Button>
      <Button variant="destructive" size="sm" onClick={() => signOut()}>
        Déconnexion
      </Button>
    </div>
  );
}
