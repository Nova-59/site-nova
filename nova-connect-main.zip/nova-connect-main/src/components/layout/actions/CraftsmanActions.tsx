
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface CraftsmanActionsProps {
  signOut: () => void;
}

export function CraftsmanActions({ signOut }: CraftsmanActionsProps) {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" asChild>
        <Link to="/dashboard">Tableau de bord Artisan</Link>
      </Button>
      <Button variant="ghost" asChild>
        <Link to="/profile">Profil</Link>
      </Button>
      <Button variant="destructive" size="sm" onClick={() => signOut()}>
        Déconnexion
      </Button>
    </div>
  );
}
