
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface HomeownerActionsProps {
  signOut: () => void;
}

export function HomeownerActions({ signOut }: HomeownerActionsProps) {
  return (
    <div className="flex items-center gap-2">
      <Button variant="outline" asChild>
        <Link to="/dashboard">Tableau de bord</Link>
      </Button>
      <Button variant="ghost" asChild>
        <Link to="/profile">Profil</Link>
      </Button>
      <Button asChild className="mr-2">
        <Link to="/projects/submit">Soumettre un projet</Link>
      </Button>
      <Button variant="destructive" size="sm" onClick={() => signOut()}>
        Déconnexion
      </Button>
    </div>
  );
}
