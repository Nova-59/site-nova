
import { HeaderWithNotifications } from "@/components/layout/HeaderWithNotifications";
import { Footer } from "@/components/layout/Footer";

interface MainLayoutWithNotificationsProps {
  children: React.ReactNode;
}

export function MainLayoutWithNotifications({ children }: MainLayoutWithNotificationsProps) {
  return (
    <div className="flex min-h-screen flex-col">
      <HeaderWithNotifications />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
