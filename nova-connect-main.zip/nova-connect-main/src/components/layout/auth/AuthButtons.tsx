
import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, Home, LogOut, Settings, User } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { t } from "@/lib/i18n";

interface AuthButtonsProps {
  currentUser: {
    id: string;
    email: string;
    name: string;
    role: string;
    avatar?: string;
  } | null;
  handleLogout: () => void;
  getInitials: (name: string) => string;
  size?: "default" | "sm";
}

export function AuthButtons({ currentUser, handleLogout, getInitials, size = "default" }: AuthButtonsProps) {
  const navigate = useNavigate();
  const buttonSize = size === "sm" ? "sm" : "default";

  const onLogout = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    console.log("Logout button clicked");
    try {
      await handleLogout();
      console.log("Logout handler completed");
      // Navigation handled by AuthContext through window.location.href
    } catch (err) {
      console.error("Error during logout:", err);
      // Force reload as fallback
      window.location.href = '/';
    }
  };

  if (currentUser) {
    return (
      <div className="flex items-center gap-4">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="relative text-white h-8 w-8">
              <Bell size={16} />
              <Badge className="absolute -top-2 -right-2 px-1.5 py-0.5 min-w-[16px] min-h-[16px] text-[10px] bg-nova-yellow text-black flex items-center justify-center">
                0
              </Badge>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-80 bg-black/80 backdrop-blur-md text-white border-white/20">
            <DropdownMenuLabel>{t('notifications')}</DropdownMenuLabel>
            <DropdownMenuSeparator className="bg-white/20" />
            <div className="p-4 text-center">
              <p className="text-sm text-white/70">Vous n'avez aucune notification.</p>
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
        
        <div className="hidden sm:flex">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="pl-2 pr-3 gap-2 text-white h-8 text-xs">
                <Avatar className="h-6 w-6">
                  <AvatarImage src={currentUser.avatar} />
                  <AvatarFallback>{getInitials(currentUser.name)}</AvatarFallback>
                </Avatar>
                <span>{currentUser.name?.split(" ")[0]}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-black/80 backdrop-blur-md text-white border-white/20">
              <DropdownMenuLabel>{t('myAccount')}</DropdownMenuLabel>
              <DropdownMenuSeparator className="bg-white/20" />
              
              <DropdownMenuItem 
                className="cursor-pointer text-white hover:bg-white/10" 
                onClick={() => 
                  navigate(currentUser.role === "admin" 
                    ? "/admin/dashboard" 
                    : currentUser.role === "craftsman" 
                      ? "/dashboard" 
                      : "/dashboard"
                  )
                }
              >
                <Home className="mr-2 h-4 w-4" />
                <span>{t('dashboard')}</span>
              </DropdownMenuItem>
              
              <DropdownMenuItem className="cursor-pointer text-white hover:bg-white/10" onClick={() => navigate("/profile")}>
                <User className="mr-2 h-4 w-4" />
                <span>{t('profile')}</span>
              </DropdownMenuItem>
              
              <DropdownMenuItem className="cursor-pointer text-white hover:bg-white/10" onClick={() => navigate("/settings")}>
                <Settings className="mr-2 h-4 w-4" />
                <span>{t('settings')}</span>
              </DropdownMenuItem>
              
              <DropdownMenuSeparator className="bg-white/20" />
              
              <DropdownMenuItem 
                className="cursor-pointer text-destructive focus:text-destructive hover:bg-white/10" 
                onClick={onLogout}
              >
                <LogOut className="mr-2 h-4 w-4" />
                <span>{t('logOut')}</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-2">
      <Link to="/auth">
        <Button size="sm" className="bg-nova-yellow text-black hover:bg-nova-yellow/90 text-xs h-8 px-3">
          {t('signIn')}
        </Button>
      </Link>
      <Link to="/auth">
        <Button size="sm" className="bg-nova-yellow text-black hover:bg-nova-yellow/90 text-xs h-8 px-3">
          {t('getStarted')}
        </Button>
      </Link>
    </div>
  );
}
