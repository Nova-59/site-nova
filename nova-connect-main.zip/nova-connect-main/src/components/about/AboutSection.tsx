
import { ReactNode } from "react";

interface AboutSectionProps {
  title: string;
  children: ReactNode;
}

export function AboutSection({ title, children }: AboutSectionProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8">
      <h2 className="text-2xl font-semibold mb-4">{title}</h2>
      {children}
    </div>
  );
}
