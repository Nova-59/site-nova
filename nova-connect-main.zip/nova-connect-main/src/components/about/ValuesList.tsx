
interface Value {
  name: string;
  description: string;
}

interface ValuesListProps {
  values: Value[];
}

export function ValuesList({ values }: ValuesListProps) {
  return (
    <ul className="list-disc pl-5 mb-4 text-gray-700 space-y-2">
      {values.map((value, index) => (
        <li key={index}>
          <span className="font-medium">{value.name}</span> - {value.description}
        </li>
      ))}
    </ul>
  );
}
