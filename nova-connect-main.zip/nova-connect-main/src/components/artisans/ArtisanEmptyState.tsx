
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

interface ArtisanEmptyStateProps {
  resetFilters: () => void;
}

export function ArtisanEmptyState({ resetFilters }: ArtisanEmptyStateProps) {
  return (
    <Card className="p-8 text-center">
      <h3 className="text-lg font-medium mb-2">Aucun artisan trouvé</h3>
      <p className="text-muted-foreground mb-4">
        Essayez de modifier vos critères de recherche.
      </p>
      <Button variant="outline" onClick={resetFilters}>
        Réinitialiser les filtres
      </Button>
    </Card>
  );
}
