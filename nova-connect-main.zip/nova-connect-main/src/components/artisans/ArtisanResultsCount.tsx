
interface ArtisanResultsCountProps {
  count: number;
}

export function ArtisanResultsCount({ count }: ArtisanResultsCountProps) {
  return (
    <div className="mb-4">
      <p className="text-sm text-muted-foreground">
        {count} artisan{count !== 1 ? 's' : ''} trouvé{count !== 1 ? 's' : ''}
      </p>
    </div>
  );
}
