
import { ArtisanCard } from "./ArtisanCard";
import { ArtisanEmptyState } from "./ArtisanEmptyState";
import { Skeleton } from "@/components/ui/skeleton";

interface Artisan {
  id: string;
  name: string;
  profession: string;
  rating: number;
  completedProjects: number;
  location: string;
  description: string;
  specialties: string[];
}

interface ArtisanListProps {
  artisans: Artisan[];
  resetFilters: () => void;
  isLoading?: boolean;
}

export function ArtisanList({ artisans, resetFilters, isLoading = false }: ArtisanListProps) {
  // Afficher un skeleton loader pendant le chargement
  if (isLoading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((index) => (
          <div key={index} className="border rounded-lg p-4">
            <div className="flex items-start gap-4">
              <Skeleton className="h-16 w-16 rounded-full" />
              <div className="space-y-2 flex-1">
                <Skeleton className="h-6 w-1/3" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-4 w-full" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // Afficher un état vide si aucun artisan n'est trouvé
  if (artisans.length === 0) {
    return <ArtisanEmptyState resetFilters={resetFilters} />;
  }

  // Afficher la liste des artisans
  return (
    <div className="space-y-6">
      {artisans.map((artisan) => (
        <ArtisanCard key={artisan.id} artisan={artisan} />
      ))}
    </div>
  );
}
