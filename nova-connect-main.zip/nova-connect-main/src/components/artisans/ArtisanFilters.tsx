
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

interface ArtisanFiltersProps {
  searchTerm: string;
  setSearchTerm: (value: string) => void;
  professionFilter: string | "all";
  setProfessionFilter: (value: string) => void;
}

export function ArtisanFilters({
  searchTerm,
  setSearchTerm,
  professionFilter,
  setProfessionFilter
}: ArtisanFiltersProps) {
  const professions = [
    { value: "all", label: "Toutes spécialités" },
    { value: "plombier", label: "Plombier" },
    { value: "électricien", label: "Électricien" },
    { value: "menuisier", label: "Menuisier" },
    { value: "peintre", label: "Peintre" },
    { value: "carreleur", label: "Carreleur" },
    { value: "couvreur", label: "Couvreur" },
    { value: "maçon", label: "Maçon" }
  ];

  return (
    <Card className="mb-8">
      <CardContent className="p-6">
        <div className="grid gap-4 md:grid-cols-2">
          <div>
            <label className="text-sm font-medium mb-2 block">
              Rechercher
            </label>
            <Input
              placeholder="Rechercher un artisan ou une spécialité..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div>
            <label className="text-sm font-medium mb-2 block">
              Spécialité
            </label>
            <Select value={professionFilter} onValueChange={(value) => setProfessionFilter(value)}>
              <SelectTrigger>
                <SelectValue placeholder="Spécialité" />
              </SelectTrigger>
              <SelectContent>
                {professions.map((profession) => (
                  <SelectItem key={profession.value} value={profession.value}>
                    {profession.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
