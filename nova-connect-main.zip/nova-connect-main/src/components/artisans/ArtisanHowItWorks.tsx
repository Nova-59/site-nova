
import { Separator } from "@/components/ui/separator";

export function ArtisanHowItWorks() {
  return (
    <div className="mt-12 rounded-lg border bg-card p-6">
      <h2 className="text-xl font-semibold mb-4">Comment ça marche ?</h2>
      <ol className="space-y-4 text-muted-foreground">
        <li className="flex gap-3">
          <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">1</span>
          <span>Parcourez notre répertoire d'artisans vérifiés par Nova Connect</span>
        </li>
        <li className="flex gap-3">
          <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">2</span>
          <span>Soumettez votre projet en détail</span>
        </li>
        <li className="flex gap-3">
          <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">3</span>
          <span>Un métreur vous contacte pour évaluer précisément vos besoins</span>
        </li>
        <li className="flex gap-3">
          <span className="flex-shrink-0 h-6 w-6 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm">4</span>
          <span>Des artisans qualifiés consultent votre projet et peuvent choisir de le prendre en charge</span>
        </li>
      </ol>
      <Separator className="my-4" />
      <p className="text-sm">
        Tous nos artisans sont vérifiés et s'engagent à respecter les délais et à réaliser un travail de qualité.
        Votre paiement est conservé par Nova Connect et ne sera versé à l'artisan qu'après validation des travaux.
      </p>
    </div>
  );
}
