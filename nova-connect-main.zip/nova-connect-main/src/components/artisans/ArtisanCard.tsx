
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Star, MapPin, Phone, Mail, ThumbsUp } from "lucide-react";

interface Artisan {
  id: string;
  name: string;
  profession: string;
  rating: number;
  completedProjects: number;
  location: string;
  description: string;
  specialties: string[];
}

interface ArtisanCardProps {
  artisan: Artisan;
}

export function ArtisanCard({ artisan }: ArtisanCardProps) {
  return (
    <Card key={artisan.id} className="overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-4">
        <div className="md:col-span-3 p-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-xl font-semibold">{artisan.name}</h3>
            <div className="flex items-center">
              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
              <span className="font-medium">{artisan.rating}</span>
            </div>
          </div>
          <div className="flex items-center text-sm text-muted-foreground mb-4">
            <span className="font-medium mr-4">{artisan.profession}</span>
            <div className="flex items-center">
              <MapPin className="h-3 w-3 mr-1" />
              <span>{artisan.location}</span>
            </div>
          </div>
          <p className="text-sm mb-4">{artisan.description}</p>
          
          <div className="mb-4">
            <h4 className="text-sm font-medium mb-2">Spécialités</h4>
            <div className="flex flex-wrap gap-2">
              {artisan.specialties.map((specialty, index) => (
                <span key={index} className="px-2 py-1 text-xs bg-secondary rounded-md">
                  {specialty}
                </span>
              ))}
            </div>
          </div>
          
          <div className="flex items-center text-sm text-muted-foreground">
            <ThumbsUp className="h-3 w-3 mr-1" />
            <span>{artisan.completedProjects} projets complétés via Nova Connect</span>
          </div>
        </div>
        
        <div className="bg-muted p-6 flex flex-col justify-center space-y-4">
          <Button asChild className="w-full">
            <a href="/projects/submit">Demander un devis à cet artisan en Hauts-de-France</a>
          </Button>
          <Button variant="outline" className="w-full">
            <Mail className="h-4 w-4 mr-2" />
            Contacter ce professionnel
          </Button>
          <Button variant="outline" className="w-full">
            <Phone className="h-4 w-4 mr-2" />
            Appeler cet artisan
          </Button>
        </div>
      </div>
    </Card>
  );
}
