
import { Button } from "@/components/ui/button";

export function ArtisanListingHeader() {
  return (
    <div className="flex flex-col space-y-3 md:flex-row md:justify-between md:space-y-0 mb-6">
      <div>
        <h1 className="text-3xl font-bold">Répertoire des Artisans en Hauts-de-France</h1>
        <p className="text-muted-foreground">
          Découvrez des artisans qualifiés dans toute la région Hauts-de-France, vérifiés par Nova Connect
        </p>
      </div>
      <Button asChild>
        <a href="/projects/submit">Trouver un artisan professionnel en Hauts-de-France</a>
      </Button>
    </div>
  );
}
