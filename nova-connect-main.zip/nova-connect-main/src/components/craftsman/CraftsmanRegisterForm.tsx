
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { Check } from "lucide-react";

const craftTypes = [
  "Peinture",
  "Électricité",
  "Plomberie",
  "Maçonnerie",
  "Menuiserie",
  "Carrelage",
  "Couverture/Toiture",
  "Plâtrerie",
  "Isolation",
  "Chauffage/Climatisation",
  "Aménagement extérieur",
  "Autre"
];

export function CraftsmanRegisterForm() {
  const [businessName, setBusinessName] = useState("");
  const [contactName, setContactName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [craftType, setCraftType] = useState("");
  const [siret, setSiret] = useState("");
  const [experience, setExperience] = useState("");
  const [address, setAddress] = useState("");
  const [description, setDescription] = useState("");
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!termsAccepted) {
      toast({
        title: "Acceptation des conditions requise",
        description: "Veuillez accepter les conditions générales pour continuer.",
        variant: "destructive"
      });
      return;
    }
    
    setIsSubmitting(true);
    
    // Simulate form submission with a delay
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast({
      title: "Inscription envoyée",
      description: "Nous examinerons votre candidature dans les 48 heures.",
    });
    
    setIsSubmitted(true);
    setIsSubmitting(false);
  };

  if (isSubmitted) {
    return (
      <div className="text-center py-8">
        <div className="flex justify-center mb-4">
          <div className="h-16 w-16 rounded-full bg-green-100 flex items-center justify-center">
            <Check className="h-8 w-8 text-green-600" />
          </div>
        </div>
        <h3 className="text-xl font-semibold mb-2">Inscription réussie !</h3>
        <p className="text-muted-foreground mb-4">
          Merci de votre intérêt pour rejoindre notre réseau d'artisans.
          Nous examinerons votre candidature et vous contacterons sous 48 heures.
        </p>
        <Button asChild className="mt-4">
          <a href="/">Retour à l'accueil</a>
        </Button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="businessName">Nom de l'entreprise</Label>
          <Input
            id="businessName"
            placeholder="Nom de votre entreprise"
            value={businessName}
            onChange={(e) => setBusinessName(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="contactName">Nom du contact</Label>
          <Input
            id="contactName"
            placeholder="Votre nom et prénom"
            value={contactName}
            onChange={(e) => setContactName(e.target.value)}
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="email">Email professionnel</Label>
          <Input
            id="email"
            type="email"
            placeholder="votre@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="phone">Téléphone</Label>
          <Input
            id="phone"
            type="tel"
            placeholder="Votre numéro de téléphone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="craftType">Type de métier</Label>
          <Select 
            value={craftType} 
            onValueChange={setCraftType}
            required
          >
            <SelectTrigger id="craftType">
              <SelectValue placeholder="Sélectionnez votre métier" />
            </SelectTrigger>
            <SelectContent>
              {craftTypes.map((type) => (
                <SelectItem key={type} value={type}>
                  {type}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="space-y-2">
          <Label htmlFor="siret">Numéro SIRET</Label>
          <Input
            id="siret"
            placeholder="Votre numéro SIRET"
            value={siret}
            onChange={(e) => setSiret(e.target.value)}
            required
          />
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="address">Adresse professionnelle</Label>
        <Input
          id="address"
          placeholder="Adresse complète"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="experience">Années d'expérience</Label>
        <Input
          id="experience"
          type="number"
          min="0"
          placeholder="Nombre d'années d'expérience"
          value={experience}
          onChange={(e) => setExperience(e.target.value)}
          required
        />
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description de votre activité</Label>
        <Textarea
          id="description"
          placeholder="Décrivez votre spécialité, vos qualifications, certifications..."
          rows={4}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>
      
      <div className="flex items-start space-x-2 pt-2">
        <Checkbox 
          id="terms" 
          checked={termsAccepted} 
          onCheckedChange={(checked) => setTermsAccepted(checked as boolean)}
        />
        <div className="grid gap-1.5 leading-none">
          <label
            htmlFor="terms"
            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
          >
            J'accepte les conditions générales
          </label>
          <p className="text-xs text-muted-foreground">
            En soumettant ce formulaire, vous acceptez nos{" "}
            <a href="#" className="text-primary underline">
              conditions générales
            </a>{" "}
            et notre{" "}
            <a href="#" className="text-primary underline">
              politique de confidentialité
            </a>
            .
          </p>
        </div>
      </div>
      
      <Button 
        type="submit" 
        className="w-full" 
        disabled={isSubmitting}
      >
        {isSubmitting ? "Envoi en cours..." : "Soumettre ma candidature"}
      </Button>
    </form>
  );
}
