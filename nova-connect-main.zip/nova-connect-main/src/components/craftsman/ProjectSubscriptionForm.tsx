
import { useState } from "react";
import { AlertCircle, Bell } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export function ProjectSubscriptionForm() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [preferences, setPreferences] = useState({
    plomberie: false,
    electricite: false,
    maconnerie: false,
    peinture: false,
    carrelage: false,
    menuiserie: false,
    toiture: false,
    isolation: false,
    chauffage: false,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simuler une requête API
    setTimeout(() => {
      console.log("Subscription submitted:", { email, preferences });
      
      toast({
        title: "Abonnement confirmé",
        description: "Vous recevrez des notifications pour les nouveaux projets correspondant à vos préférences.",
      });
      
      setIsLoading(false);
    }, 1000);
  };

  const handlePreferenceChange = (category: keyof typeof preferences) => {
    setPreferences(prev => ({
      ...prev,
      [category]: !prev[category]
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Restez informé des nouveaux projets</CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email pour les notifications</Label>
            <Input
              id="email"
              type="email"
              placeholder="votre-email@exemple.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="space-y-3">
            <h3 className="text-sm font-medium">Types de projets qui vous intéressent :</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {Object.entries(preferences).map(([key, value]) => (
                <div key={key} className="flex items-center space-x-2">
                  <Switch
                    id={key}
                    checked={value}
                    onCheckedChange={() => handlePreferenceChange(key as keyof typeof preferences)}
                  />
                  <Label htmlFor={key} className="capitalize">
                    {key}
                  </Label>
                </div>
              ))}
            </div>
          </div>

          <Alert variant="default" className="bg-muted/50">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs">
              Vous recevrez des notifications uniquement pour les nouveaux projets correspondant à vos préférences. 
              Vous pourrez vous désinscrire à tout moment.
            </AlertDescription>
          </Alert>
        </form>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleSubmit}
          disabled={isLoading} 
          className="w-full"
        >
          <Bell className="mr-2 h-4 w-4" />
          {isLoading ? "Traitement en cours..." : "S'abonner aux notifications"}
        </Button>
      </CardFooter>
    </Card>
  );
}
