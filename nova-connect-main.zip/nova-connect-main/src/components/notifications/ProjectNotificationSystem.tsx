
import { useState, useEffect } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Bell, Mail, MessageSquare, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getCurrentUser } from "@/lib/mock-api";
import { User } from "@/types/user";

type NotificationPreferences = {
  email: boolean;
  browser: boolean;
  newProjects: boolean;
  bids: boolean;
  messages: boolean;
  scheduling: boolean;
  statusUpdates: boolean;
};

export function ProjectNotificationSystem() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const currentUser = getCurrentUser() as User | null;
  const [preferences, setPreferences] = useState<NotificationPreferences>({
    email: true,
    browser: true,
    newProjects: true,
    bids: true,
    messages: true,
    scheduling: true,
    statusUpdates: true,
  });

  const handleTogglePreference = (key: keyof NotificationPreferences) => {
    setPreferences(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const handleSavePreferences = () => {
    setIsLoading(true);
    
    // Simuler une requête API
    setTimeout(() => {
      console.log("Notification preferences saved:", preferences);
      
      toast({
        title: "Préférences enregistrées",
        description: "Vos préférences de notification ont été mises à jour.",
      });
      
      setIsLoading(false);
    }, 1000);
  };

  if (!currentUser) {
    return (
      <Alert>
        <AlertTitle>Connexion requise</AlertTitle>
        <AlertDescription>
          Vous devez être connecté pour gérer vos préférences de notification.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Gérer vos notifications</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-sm font-medium">Canaux de notification</h3>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Mail className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="email-notifications">Notifications par email</Label>
              </div>
              <Switch
                id="email-notifications"
                checked={preferences.email}
                onCheckedChange={() => handleTogglePreference("email")}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="browser-notifications">Notifications dans le navigateur</Label>
              </div>
              <Switch
                id="browser-notifications"
                checked={preferences.browser}
                onCheckedChange={() => handleTogglePreference("browser")}
              />
            </div>
          </div>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-sm font-medium">Types de notifications</h3>
          <div className="space-y-2">
            {currentUser.role === "craftsman" && (
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Bell className="h-4 w-4 text-muted-foreground" />
                  <Label htmlFor="new-projects">Nouveaux projets</Label>
                </div>
                <Switch
                  id="new-projects"
                  checked={preferences.newProjects}
                  onCheckedChange={() => handleTogglePreference("newProjects")}
                />
              </div>
            )}
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="bids-notifications">
                  {currentUser.role === "craftsman" 
                    ? "Acceptation de vos offres" 
                    : "Nouvelles offres d'artisans"}
                </Label>
              </div>
              <Switch
                id="bids-notifications"
                checked={preferences.bids}
                onCheckedChange={() => handleTogglePreference("bids")}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="message-notifications">Nouveaux messages</Label>
              </div>
              <Switch
                id="message-notifications"
                checked={preferences.messages}
                onCheckedChange={() => handleTogglePreference("messages")}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="scheduling-notifications">Mises à jour de planification</Label>
              </div>
              <Switch
                id="scheduling-notifications"
                checked={preferences.scheduling}
                onCheckedChange={() => handleTogglePreference("scheduling")}
              />
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Bell className="h-4 w-4 text-muted-foreground" />
                <Label htmlFor="status-notifications">Changements de statut du projet</Label>
              </div>
              <Switch
                id="status-notifications"
                checked={preferences.statusUpdates}
                onCheckedChange={() => handleTogglePreference("statusUpdates")}
              />
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Button 
          onClick={handleSavePreferences}
          disabled={isLoading}
          className="w-full"
        >
          {isLoading ? "Enregistrement..." : "Enregistrer les préférences"}
        </Button>
      </CardFooter>
    </Card>
  );
}
