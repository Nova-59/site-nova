
import { Bell } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NotificationDropdownProps {
  emptyNotifications?: boolean;
}

export function NotificationDropdown({ emptyNotifications = true }: NotificationDropdownProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative w-10 h-10 text-black">
          <Bell className="h-5 w-5" />
          {!emptyNotifications && (
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-red-500 text-white"
              aria-label="notifications count"
              style={{ transform: "translate(30%, -30%)" }}
            >
              3
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80 bg-white border border-gray-200">
        <DropdownMenuLabel className="text-black">Notifications</DropdownMenuLabel>
        <DropdownMenuSeparator />
        
        {emptyNotifications ? (
          <div className="p-4 text-center">
            <p className="text-sm text-gray-500">Vous n'avez aucune notification.</p>
          </div>
        ) : (
          <DropdownMenuItem className="hover:bg-gray-100">
            <div className="flex items-start gap-2 py-2">
              <div className="h-8 w-8 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Bell className="h-4 w-4 text-primary" />
              </div>
              <div className="space-y-1">
                <p className="text-sm font-medium leading-none text-black">Notification d'exemple</p>
                <p className="text-xs text-gray-500">Ceci est un exemple de notification.</p>
                <p className="text-xs text-gray-500">Il y a 1 heure</p>
              </div>
            </div>
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
