
import React from "react";
import { Eye, CheckCircle, XCircle, MoreHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

interface CraftsmanActionsProps {
  id: string;
  status: string;
  onVerify: (id: string) => void;
  onReject: (id: string) => void;
}

export function CraftsmanActions({ id, status, onVerify, onReject }: CraftsmanActionsProps) {
  return (
    <TooltipProvider>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="icon">
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuLabel>Actions</DropdownMenuLabel>
          <DropdownMenuItem>
            <Eye className="mr-2 h-4 w-4" /> Voir le profil
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          {status === "pending" && (
            <>
              <DropdownMenuItem onClick={() => onVerify(id)}>
                <CheckCircle className="mr-2 h-4 w-4 text-green-600" /> Vérifier
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => onReject(id)}>
                <XCircle className="mr-2 h-4 w-4 text-red-600" /> Rejeter
              </DropdownMenuItem>
            </>
          )}
        </DropdownMenuContent>
      </DropdownMenu>
      
      <Tooltip>
        <TooltipTrigger asChild>
          <Button variant="outline" size="icon" className="ml-2">
            <Eye className="h-4 w-4" />
          </Button>
        </TooltipTrigger>
        <TooltipContent>
          <p>Voir le profil</p>
        </TooltipContent>
      </Tooltip>
      
      {status === "pending" && (
        <>
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="icon" 
                className="ml-2 text-green-600"
                onClick={() => onVerify(id)}
              >
                <CheckCircle className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Vérifier</p>
            </TooltipContent>
          </Tooltip>
          
          <Tooltip>
            <TooltipTrigger asChild>
              <Button 
                variant="outline" 
                size="icon" 
                className="ml-2 text-red-600"
                onClick={() => onReject(id)}
              >
                <XCircle className="h-4 w-4" />
              </Button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Rejeter</p>
            </TooltipContent>
          </Tooltip>
        </>
      )}
    </TooltipProvider>
  );
}
