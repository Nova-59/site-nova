
import React from "react";
import { Table, TableHeader, TableRow, TableHead, TableBody } from "@/components/ui/table";
import { CraftsmanRow } from "./CraftsmanRow";

interface Craftsman {
  id: string;
  name: string;
  avatar?: string;
  specialty: string;
  joinDate: string;
  rating: number;
  jobs: number;
  status: string;
}

interface CraftsmanTableProps {
  craftsmen: Craftsman[];
  onVerify: (id: string) => void;
  onReject: (id: string) => void;
}

export function CraftsmanTable({ craftsmen, onVerify, onReject }: CraftsmanTableProps) {
  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Artisan</TableHead>
          <TableHead>Spécialité</TableHead>
          <TableHead>Date d'inscription</TableHead>
          <TableHead>Rating</TableHead>
          <TableHead>Projets</TableHead>
          <TableHead>Statut</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {craftsmen.map((craftsman) => (
          <CraftsmanRow 
            key={craftsman.id}
            craftsman={craftsman} 
            onVerify={onVerify} 
            onReject={onReject} 
          />
        ))}
      </TableBody>
    </Table>
  );
}
