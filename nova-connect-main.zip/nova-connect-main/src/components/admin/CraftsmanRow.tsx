
import React from "react";
import { TableRow, TableCell } from "@/components/ui/table";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star } from "lucide-react";
import { StatusBadge } from "./StatusBadge";
import { CraftsmanActions } from "./CraftsmanActions";

interface Craftsman {
  id: string;
  name: string;
  avatar?: string;
  specialty: string;
  joinDate: string;
  rating: number;
  jobs: number;
  status: string;
}

interface CraftsmanRowProps {
  craftsman: Craftsman;
  onVerify: (id: string) => void;
  onReject: (id: string) => void;
}

export function CraftsmanRow({ craftsman, onVerify, onReject }: CraftsmanRowProps) {
  return (
    <TableRow key={craftsman.id}>
      <TableCell>
        <div className="flex items-center gap-3">
          <Avatar>
            <AvatarImage src={craftsman.avatar} />
            <AvatarFallback>{craftsman.name.substring(0, 2)}</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-medium">{craftsman.name}</div>
            <div className="text-xs text-muted-foreground">{craftsman.id}</div>
          </div>
        </div>
      </TableCell>
      <TableCell>{craftsman.specialty}</TableCell>
      <TableCell>{new Date(craftsman.joinDate).toLocaleDateString('fr-FR')}</TableCell>
      <TableCell>
        {craftsman.rating > 0 ? (
          <div className="flex items-center">
            <Star className="h-4 w-4 text-yellow-500 mr-1" />
            <span>{craftsman.rating}</span>
          </div>
        ) : (
          <span className="text-muted-foreground text-sm">N/A</span>
        )}
      </TableCell>
      <TableCell>{craftsman.jobs}</TableCell>
      <TableCell><StatusBadge status={craftsman.status} /></TableCell>
      <TableCell className="text-right">
        <CraftsmanActions 
          id={craftsman.id} 
          status={craftsman.status} 
          onVerify={onVerify} 
          onReject={onReject} 
        />
      </TableCell>
    </TableRow>
  );
}
