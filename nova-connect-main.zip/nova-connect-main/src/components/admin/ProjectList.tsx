
import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MoreHorizontal, Eye, CheckCircle, XCircle } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

interface ProjectListProps {
  limit?: number;
}

export function ProjectList({ limit }: ProjectListProps) {
  const { toast } = useToast();
  // Get both demo projects and user-submitted projects
  const [projects, setProjects] = useState<any[]>([]);
  
  useEffect(() => {
    // Get user-submitted projects from localStorage (in a real app, this would be from an API/database)
    const userProjects = JSON.parse(localStorage.getItem('userProjects') || '[]');
    
    // Format user projects for admin display
    const formattedUserProjects = userProjects.map((project: any) => ({
      id: project.id.substring(0, 7),
      title: project.title,
      owner: "Utilisateur",
      date: project.createdAt,
      status: project.status,
      budget: "À déterminer",
      location: `${project.location.city}, ${project.location.postalCode}`
    }));
    
    // Sample admin projects for demo
    const adminProjects = [
      { 
        id: "PRJ-001", 
        title: "[DÉMO] Rénovation salle de bain", 
        owner: "Démo", 
        date: "2023-10-15", 
        status: "pending",
        budget: "2,500 €",
        location: "Paris, 75011"
      }
    ];
    
    setProjects([...formattedUserProjects, ...adminProjects]);
  }, []);

  const statusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700">En attente</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700">Approuvé</Badge>;
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700">En cours</Badge>;
      case "completed":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700">Terminé</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700">Rejeté</Badge>;
      default:
        return <Badge variant="outline">Inconnu</Badge>;
    }
  };

  const handleApprove = (id: string) => {
    // Update projects in state
    setProjects(
      projects.map(project => 
        project.id === id ? { ...project, status: "approved" } : project
      )
    );
    
    // Also update in localStorage if it's a user project
    const userProjects = JSON.parse(localStorage.getItem('userProjects') || '[]');
    const updatedUserProjects = userProjects.map((project: any) => 
      project.id.substring(0, 7) === id ? { ...project, status: "approved", isPublished: true } : project
    );
    localStorage.setItem('userProjects', JSON.stringify(updatedUserProjects));
    
    toast({
      title: "Projet approuvé",
      description: `Le projet ${id} a été approuvé avec succès.`
    });
  };

  const handleReject = (id: string) => {
    // Update projects in state
    setProjects(
      projects.map(project => 
        project.id === id ? { ...project, status: "rejected" } : project
      )
    );
    
    // Also update in localStorage if it's a user project
    const userProjects = JSON.parse(localStorage.getItem('userProjects') || '[]');
    const updatedUserProjects = userProjects.map((project: any) => 
      project.id.substring(0, 7) === id ? { ...project, status: "rejected" } : project
    );
    localStorage.setItem('userProjects', JSON.stringify(updatedUserProjects));
    
    toast({
      title: "Projet rejeté",
      description: `Le projet ${id} a été rejeté.`
    });
  };

  const displayedProjects = limit ? projects.slice(0, limit) : projects;

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>ID</TableHead>
          <TableHead>Projet</TableHead>
          <TableHead>Propriétaire</TableHead>
          <TableHead>Date</TableHead>
          <TableHead>Budget</TableHead>
          <TableHead>Statut</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {displayedProjects.length > 0 ? (
          displayedProjects.map((project) => (
            <TableRow key={project.id}>
              <TableCell className="font-medium">{project.id}</TableCell>
              <TableCell>{project.title}</TableCell>
              <TableCell>{project.owner}</TableCell>
              <TableCell>{new Date(project.date).toLocaleDateString('fr-FR')}</TableCell>
              <TableCell>{project.budget}</TableCell>
              <TableCell>{statusBadge(project.status)}</TableCell>
              <TableCell className="text-right">
                <TooltipProvider>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem>
                        <Eye className="mr-2 h-4 w-4" /> Détails
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      {project.status === "pending" && (
                        <>
                          <DropdownMenuItem onClick={() => handleApprove(project.id)}>
                            <CheckCircle className="mr-2 h-4 w-4 text-green-600" /> Approuver
                          </DropdownMenuItem>
                          <DropdownMenuItem onClick={() => handleReject(project.id)}>
                            <XCircle className="mr-2 h-4 w-4 text-red-600" /> Rejeter
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                  
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <Button variant="outline" size="icon" className="ml-2">
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TooltipTrigger>
                    <TooltipContent>
                      <p>Voir les détails</p>
                    </TooltipContent>
                  </Tooltip>
                  
                  {project.status === "pending" && (
                    <>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="ml-2 text-green-600"
                            onClick={() => handleApprove(project.id)}
                          >
                            <CheckCircle className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Approuver</p>
                        </TooltipContent>
                      </Tooltip>
                      
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="ml-2 text-red-600"
                            onClick={() => handleReject(project.id)}
                          >
                            <XCircle className="h-4 w-4" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Rejeter</p>
                        </TooltipContent>
                      </Tooltip>
                    </>
                  )}
                </TooltipProvider>
              </TableCell>
            </TableRow>
          ))
        ) : (
          <TableRow>
            <TableCell colSpan={7} className="text-center py-4">
              Aucun projet disponible
            </TableCell>
          </TableRow>
        )}
      </TableBody>
    </Table>
  );
}
