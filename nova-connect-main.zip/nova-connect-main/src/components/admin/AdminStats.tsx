
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, LineChart, PieChart, RadarChart } from "@/components/ui/chart";
import { Separator } from "@/components/ui/separator";
import { CircleDollarSign, Users, FileText, TrendingUp } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export function AdminStats() {
  // Mock data for charts and stats
  const projectsData = [
    { name: "Jan", value: 12 },
    { name: "Feb", value: 18 },
    { name: "Mar", value: 15 },
    { name: "Apr", value: 24 },
    { name: "May", value: 32 },
    { name: "Jun", value: 28 },
  ];
  
  const revenueData = [
    { name: "Jan", value: 2400 },
    { name: "Feb", value: 3600 },
    { name: "Mar", value: 3000 },
    { name: "Apr", value: 4800 },
    { name: "May", value: 6400 },
    { name: "Jun", value: 5600 },
  ];
  
  const craftsmensData = {
    labels: ["Plombiers", "Électriciens", "Charpentiers", "Peintres", "Maçons"],
    datasets: [
      {
        data: [25, 18, 15, 22, 12],
        backgroundColor: [
          "rgba(54, 162, 235, 0.6)",
          "rgba(255, 99, 132, 0.6)",
          "rgba(255, 206, 86, 0.6)",
          "rgba(75, 192, 192, 0.6)",
          "rgba(153, 102, 255, 0.6)",
        ]
      }
    ]
  };
  
  // New data for pie chart
  const projectTypesData = [
    { name: "Rénovation", value: 35, color: "#0088FE" },
    { name: "Construction", value: 25, color: "#00C49F" },
    { name: "Plomberie", value: 15, color: "#FFBB28" },
    { name: "Électricité", value: 20, color: "#FF8042" },
    { name: "Peinture", value: 5, color: "#8884d8" }
  ];

  // New data for radar chart
  const skillsDistributionData = [
    { skill: "Technique", plombiers: 9, électriciens: 7, charpentiers: 8, peintres: 5, maçons: 8 },
    { skill: "Ponctualité", plombiers: 8, électriciens: 9, charpentiers: 7, peintres: 8, maçons: 6 },
    { skill: "Communication", plombiers: 7, électriciens: 8, charpentiers: 6, peintres: 9, maçons: 7 },
    { skill: "Qualité", plombiers: 9, électriciens: 8, charpentiers: 9, peintres: 8, maçons: 9 },
    { skill: "Prix", plombiers: 6, électriciens: 7, charpentiers: 7, peintres: 8, maçons: 7 },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Projets</CardTitle>
              <CardDescription className="text-2xl font-bold">127</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground flex items-center">
                <FileText className="inline h-4 w-4 mr-1" /> 
                <span className="text-green-600 font-medium">+24%</span> ce mois
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Artisans</CardTitle>
              <CardDescription className="text-2xl font-bold">92</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground flex items-center">
                <Users className="inline h-4 w-4 mr-1" /> 
                <span className="text-green-600 font-medium">+12%</span> ce mois
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Revenus</CardTitle>
              <CardDescription className="text-2xl font-bold">5,840 €</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground flex items-center">
                <CircleDollarSign className="inline h-4 w-4 mr-1" /> 
                <span className="text-green-600 font-medium">+18%</span> ce mois
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">Taux de conversion</CardTitle>
              <CardDescription className="text-2xl font-bold">32%</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-xs text-muted-foreground flex items-center">
                <TrendingUp className="inline h-4 w-4 mr-1" /> 
                <span className="text-green-600 font-medium">+5%</span> ce mois
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Projets par mois</CardTitle>
            <CardDescription>Nombre de projets soumis mensuellement</CardDescription>
          </CardHeader>
          <CardContent>
            <LineChart 
              data={projectsData} 
              xAxisKey="name" 
              yAxisKey="value"
              height={200}
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Types de projets</CardTitle>
            <CardDescription>Répartition par catégorie</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <PieChart 
              data={projectTypesData}
              height={200}
              outerRadius={90}
              innerRadius={30}
              paddingAngle={2}
              showLabels={true}
            />
          </CardContent>
        </Card>
      </div>
      
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Distribution des artisans</CardTitle>
            <CardDescription>Par spécialité</CardDescription>
          </CardHeader>
          <CardContent>
            <BarChart 
              data={craftsmensData}
              height={200}
            />
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Revenus mensuels</CardTitle>
            <CardDescription>En euros</CardDescription>
          </CardHeader>
          <CardContent>
            <LineChart 
              data={revenueData} 
              xAxisKey="name" 
              yAxisKey="value"
              height={200}
            />
          </CardContent>
        </Card>
        
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Évaluation des compétences</CardTitle>
            <CardDescription>Par type d'artisan (notation /10)</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="radar" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="radar">Radar</TabsTrigger>
                <TabsTrigger value="details">Détails</TabsTrigger>
              </TabsList>
              <TabsContent value="radar">
                <RadarChart 
                  data={skillsDistributionData}
                  dataKey="skill"
                  categories={["plombiers", "électriciens", "charpentiers", "peintres", "maçons"]}
                  height={250}
                />
              </TabsContent>
              <TabsContent value="details">
                <div className="text-sm">
                  <table className="w-full">
                    <thead>
                      <tr>
                        <th className="text-left pb-2">Compétence</th>
                        <th className="text-center pb-2">Plombiers</th>
                        <th className="text-center pb-2">Électriciens</th>
                        <th className="text-center pb-2">Charpentiers</th>
                        <th className="text-center pb-2">Peintres</th>
                        <th className="text-center pb-2">Maçons</th>
                      </tr>
                    </thead>
                    <tbody>
                      {skillsDistributionData.map((item) => (
                        <tr key={item.skill} className="border-t">
                          <td className="py-2">{item.skill}</td>
                          <td className="text-center py-2">{item.plombiers}/10</td>
                          <td className="text-center py-2">{item.électriciens}/10</td>
                          <td className="text-center py-2">{item.charpentiers}/10</td>
                          <td className="text-center py-2">{item.peintres}/10</td>
                          <td className="text-center py-2">{item.maçons}/10</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
