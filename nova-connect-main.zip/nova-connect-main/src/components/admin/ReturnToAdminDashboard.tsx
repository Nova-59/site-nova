
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";

export function ReturnToAdminDashboard() {
  const navigate = useNavigate();
  
  return (
    <Button 
      variant="outline" 
      className="mb-4 flex items-center gap-2" 
      onClick={() => navigate("/admin")}
    >
      <ArrowLeft className="h-4 w-4" />
      Retour au tableau de bord admin
    </Button>
  );
}
