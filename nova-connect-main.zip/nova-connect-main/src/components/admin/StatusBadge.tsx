
import React from "react";
import { Badge } from "@/components/ui/badge";

interface StatusBadgeProps {
  status: string;
}

export function StatusBadge({ status }: StatusBadgeProps) {
  switch (status) {
    case "pending":
      return <Badge variant="outline" className="bg-yellow-50 text-yellow-700">En attente</Badge>;
    case "verified":
      return <Badge variant="outline" className="bg-green-50 text-green-700">Vérifié</Badge>;
    case "rejected":
      return <Badge variant="outline" className="bg-red-50 text-red-700">Rejeté</Badge>;
    default:
      return <Badge variant="outline">Inconnu</Badge>;
  }
}
