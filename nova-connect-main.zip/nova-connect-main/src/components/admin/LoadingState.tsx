
import React from "react";
import { ReturnToAdminDashboard } from "@/components/admin/ReturnToAdminDashboard";
import { Skeleton } from "@/components/ui/skeleton";

interface LoadingStateProps {
  message?: string;
  showReturn?: boolean;
  height?: string;
  skeleton?: boolean;
}

export function LoadingState({ 
  message = "Chargement...", 
  showReturn = true, 
  height = "min-h-[300px]",
  skeleton = false
}: LoadingStateProps) {
  return (
    <div className="container py-8">
      {showReturn && <ReturnToAdminDashboard />}
      <div className={`${height} flex flex-col items-center justify-center`}>
        {skeleton ? (
          <div className="w-full max-w-md space-y-4">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-8 w-2/3 mx-auto" />
          </div>
        ) : (
          <p className="text-muted-foreground">{message}</p>
        )}
      </div>
    </div>
  );
}
