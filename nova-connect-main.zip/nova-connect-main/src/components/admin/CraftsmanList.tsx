
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { CraftsmanTable } from "./CraftsmanTable";
import { EmptyState } from "./EmptyState";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";

interface Craftsman {
  id: string;
  name: string;
  avatar?: string;
  specialty: string;
  joinDate: string;
  rating: number;
  jobs: number;
  status: string;
}

interface CraftsmanListProps {
  limit?: number;
  isLoading?: boolean;
}

export function CraftsmanList({ limit, isLoading = false }: CraftsmanListProps) {
  const { toast } = useToast();
  
  // Tableau vide à la place des données de démonstration
  const [craftsmen, setCraftsmen] = useState<Craftsman[]>([]);
  const [loadingData, setLoadingData] = useState(isLoading);

  const handleRefresh = () => {
    setLoadingData(true);
    // Simuler une requête API pour recharger les données
    setTimeout(() => {
      setLoadingData(false);
      toast({
        title: "Liste rafraîchie",
        description: "La liste des artisans a été mise à jour."
      });
    }, 1000);
  };

  const handleVerify = (id: string) => {
    setCraftsmen(
      craftsmen.map(craftsman => 
        craftsman.id === id ? { ...craftsman, status: "verified" } : craftsman
      )
    );
    toast({
      title: "Artisan vérifié",
      description: `L'artisan ${id} a été vérifié avec succès.`
    });
  };

  const handleReject = (id: string) => {
    setCraftsmen(
      craftsmen.map(craftsman => 
        craftsman.id === id ? { ...craftsman, status: "rejected" } : craftsman
      )
    );
    toast({
      title: "Artisan rejeté",
      description: `L'artisan ${id} a été rejeté.`
    });
  };

  const displayedCraftsmen = limit ? craftsmen.slice(0, limit) : craftsmen;

  // Afficher un squelette pendant le chargement
  if (loadingData) {
    return (
      <div className="space-y-4">
        <div className="flex justify-end">
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled>
            <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Rafraîchir
          </Button>
        </div>
        <div className="rounded-md border">
          <div className="p-4">
            <Skeleton className="h-8 w-full" />
          </div>
          {[1, 2, 3].map((i) => (
            <div key={i} className="border-t p-4">
              <div className="flex justify-between">
                <div className="flex items-center gap-4">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div>
                    <Skeleton className="h-4 w-32 mb-2" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Skeleton className="h-9 w-20" />
                  <Skeleton className="h-9 w-20" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Afficher un état vide s'il n'y a pas d'artisans
  if (displayedCraftsmen.length === 0) {
    return (
      <>
        <div className="flex justify-end mb-4">
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCw className="mr-2 h-4 w-4" /> Rafraîchir
          </Button>
        </div>
        <EmptyState 
          message="Aucun artisan n'est inscrit pour le moment." 
          action={{
            label: "Rafraîchir la liste",
            onClick: handleRefresh
          }}
        />
      </>
    );
  }

  // Afficher la table des artisans
  return (
    <>
      <div className="flex justify-end mb-4">
        <Button variant="outline" size="sm" onClick={handleRefresh}>
          <RefreshCw className="mr-2 h-4 w-4" /> Rafraîchir
        </Button>
      </div>
      <CraftsmanTable 
        craftsmen={displayedCraftsmen} 
        onVerify={handleVerify} 
        onReject={handleReject} 
      />
    </>
  );
}
