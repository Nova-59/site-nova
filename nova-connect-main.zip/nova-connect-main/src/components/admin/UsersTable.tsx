import { UserRole, User } from "@/types/user";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { MoreHorizontal, UserCheck, UserX } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/contexts/AuthContext";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useState } from "react";

interface UsersTableProps {
  users: User[];
  onRoleChange: (userId: string, newRole: UserRole) => void;
  onDeleteUser: (userId: string) => void;
}

export function UsersTable({ users, onRoleChange, onDeleteUser }: UsersTableProps) {
  const { user: currentUser } = useAuth();
  const isAdmin = currentUser?.role === "admin";
  const [userToDelete, setUserToDelete] = useState<string | null>(null);
  
  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case "guest":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Invité</Badge>;
      case "homeowner":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Particulier</Badge>;
      case "craftsman":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Artisan</Badge>;
      case "estimator":
        return <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">Métreur</Badge>;
      case "admin":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Admin</Badge>;
      default:
        return <Badge variant="outline">{role}</Badge>;
    }
  };

  const handleDeleteConfirmed = () => {
    if (userToDelete) {
      onDeleteUser(userToDelete);
      setUserToDelete(null);
    }
  };

  const handleRoleChange = (userId: string, newRole: UserRole) => {
    console.log(`[TABLE] Demande de changement de rôle détectée:`, { userId, newRole });
    
    if (!isAdmin) {
      console.warn("[TABLE] Tentative de changement de rôle par un non-admin");
      return;
    }
    
    console.log("[TABLE] Appel de la fonction onRoleChange depuis UsersTable");
    onRoleChange(userId, newRole);
  };

  return (
    <>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">ID</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Nom</TableHead>
            <TableHead>Rôle</TableHead>
            <TableHead>Adresse</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.length > 0 ? (
            users.map((user) => (
              <TableRow key={user.id}>
                <TableCell className="font-medium">{user.id}</TableCell>
                <TableCell>{user.email}</TableCell>
                <TableCell>{user.firstName} {user.lastName}</TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    {getRoleBadge(user.role)}
                    <Select 
                      value={user.role} 
                      onValueChange={(value) => {
                        console.log("[SELECT] Changement de rôle via Select:", {
                          userId: user.id,
                          oldRole: user.role,
                          newRole: value
                        });
                        if (value !== user.role) {
                          handleRoleChange(user.id, value as UserRole);
                        } else {
                          console.log("[SELECT] Aucun changement détecté, rôle inchangé");
                        }
                      }}
                      disabled={!isAdmin || user.email.includes("admin") || user.role === "admin"}
                    >
                      <SelectTrigger className="w-[180px]">
                        <SelectValue placeholder={user.role} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="guest">Invité</SelectItem>
                        <SelectItem value="homeowner">Particulier</SelectItem>
                        <SelectItem value="craftsman">Artisan</SelectItem>
                        <SelectItem value="estimator">Métreur</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </TableCell>
                <TableCell>
                  {user.address ? (
                    <div className="text-sm">
                      <p>{user.address}</p>
                      <p>{user.postalCode} {user.city}</p>
                    </div>
                  ) : (
                    <span className="text-muted-foreground text-sm">Non spécifiée</span>
                  )}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" className="h-8 w-8 p-0">
                        <span className="sr-only">Ouvrir le menu</span>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuLabel>Actions</DropdownMenuLabel>
                      <DropdownMenuItem 
                        onClick={() => isAdmin && handleRoleChange(user.id, user.role === "guest" ? "homeowner" : user.role)}
                        disabled={!isAdmin || user.role !== "guest" || user.email.includes("admin")}
                        className="flex items-center"
                      >
                        <UserCheck className="h-4 w-4 mr-2" />
                        Valider comme particulier
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => isAdmin && handleRoleChange(user.id, user.role === "guest" ? "craftsman" : user.role)}
                        disabled={!isAdmin || user.role !== "guest" || user.email.includes("admin")}
                        className="flex items-center"
                      >
                        <UserCheck className="h-4 w-4 mr-2" />
                        Valider comme artisan
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => alert(`Détails de l'utilisateur ${user.id}`)}
                      >
                        Voir détails
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => setUserToDelete(user.id)}
                        disabled={!isAdmin || user.role === "admin"}
                        className="text-red-600"
                      >
                        <UserX className="h-4 w-4 mr-2" />
                        Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <TableRow>
              <TableCell colSpan={6} className="text-center py-4">
                Aucun utilisateur trouvé
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>

      <AlertDialog open={!!userToDelete} onOpenChange={(open) => !open && setUserToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer cet utilisateur ? Cette action est irréversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteConfirmed} className="bg-red-600">
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
