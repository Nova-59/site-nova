
import React from "react";
import { Button } from "@/components/ui/button";
import { AlertCircle } from "lucide-react";

interface EmptyStateProps {
  message?: string;
  icon?: React.ReactNode;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function EmptyState({ 
  message = "Aucun artisan n'est inscrit pour le moment.", 
  icon = <AlertCircle className="h-12 w-12 text-muted-foreground" />,
  action
}: EmptyStateProps) {
  return (
    <div className="text-center p-8 bg-muted/20 rounded-md">
      <div className="flex flex-col items-center gap-4">
        {icon}
        <p className="text-muted-foreground">{message}</p>
        {action && (
          <Button onClick={action.onClick} className="mt-2">
            {action.label}
          </Button>
        )}
      </div>
    </div>
  );
}
