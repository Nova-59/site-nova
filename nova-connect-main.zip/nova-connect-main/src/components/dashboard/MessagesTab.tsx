
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export function MessagesTab() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Messages</CardTitle>
        <CardDescription>Vos conversations avec les propriétaires et artisans</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-center py-8">
          <p className="text-muted-foreground">Aucun message disponible.</p>
        </div>
      </CardContent>
    </Card>
  );
}
