
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export function PaymentsTab() {
  const navigate = useNavigate();
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Paiements</CardTitle>
        <CardDescription>Vos paiements reçus et en attente</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="bg-muted p-4 rounded-lg border">
            <h3 className="font-medium mb-2">Information de paiement</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Pour recevoir vos paiements, vous devez renseigner votre IBAN dans votre profil.
              Les paiements sont effectués par Nova Connect une fois que les travaux ont été
              validés par notre équipe.
            </p>
            <Button variant="outline" onClick={() => navigate("/profile")}>
              Mettre à jour mes informations bancaires
            </Button>
          </div>
          
          <div className="space-y-4">
            <h3 className="font-medium">Paiements en attente</h3>
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              Aucun paiement en attente pour le moment.
            </div>
            
            <h3 className="font-medium mt-6">Paiements reçus</h3>
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              Aucun paiement reçu pour le moment.
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
