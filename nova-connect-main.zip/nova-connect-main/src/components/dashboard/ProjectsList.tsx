
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CalendarClock, Wallet, Plus, Hammer, Home, User, AlertCircle, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { ProjectCard } from "./ProjectCard";
import { UserRole } from "@/types/user";
import { Skeleton } from "@/components/ui/skeleton";

interface ProjectsListProps {
  userRole: UserRole;
  isLoading?: boolean;
}

export function ProjectsList({ userRole, isLoading = false }: ProjectsListProps) {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<any[]>([]);
  
  console.log("ProjectsList rendered for role:", userRole);

  // Composant de chargement réutilisable
  const renderSkeleton = () => (
    <div className="space-y-4">
      {[1, 2].map((i) => (
        <div key={i} className="border rounded-lg p-4">
          <div className="flex justify-between items-start">
            <div className="space-y-2">
              <Skeleton className="h-5 w-40" />
              <Skeleton className="h-4 w-60" />
            </div>
            <div>
              <Skeleton className="h-8 w-20" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );

  // État de chargement pour tous les types d'utilisateurs
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              {userRole === "craftsman" ? (
                <Hammer className="mr-2 h-5 w-5 text-blue-500" />
              ) : userRole === "homeowner" ? (
                <Home className="mr-2 h-5 w-5 text-green-500" />
              ) : userRole === "estimator" ? (
                <CalendarClock className="mr-2 h-5 w-5 text-orange-500" />
              ) : (
                <User className="mr-2 h-5 w-5 text-purple-500" />
              )}
              {userRole === "craftsman" ? "Mes Chantiers" : 
               userRole === "homeowner" ? "Mes Projets" :
               userRole === "estimator" ? "Projets à évaluer" : "Tous les Projets"}
            </CardTitle>
            <CardDescription>
              {userRole === "craftsman" ? "Projets que vous avez acceptés et qui sont en cours" : 
               userRole === "homeowner" ? "Tous vos projets en cours et passés" :
               userRole === "estimator" ? "Projets nécessitant une visite et une estimation" : 
               "Liste de tous les projets sur la plateforme"}
            </CardDescription>
          </div>
          
          <Skeleton className="h-9 w-36" />
        </CardHeader>
        <CardContent>
          {renderSkeleton()}
        </CardContent>
      </Card>
    );
  }

  // Interface spécifique pour les artisans
  if (userRole === "craftsman") {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Hammer className="mr-2 h-5 w-5 text-blue-500" />
              Mes Chantiers
            </CardTitle>
            <CardDescription>
              Projets que vous avez acceptés et qui sont en cours
            </CardDescription>
          </div>
          
          <Button size="sm" onClick={() => navigate("/projects/marketplace")}>
            Trouver des projets
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">
              Vous n'avez pas encore de chantiers en cours.
              Consultez la marketplace pour trouver des projets.
            </p>
            <Button onClick={() => navigate("/projects/marketplace")}>
              Accéder à la marketplace
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Interface spécifique pour les propriétaires
  if (userRole === "homeowner") {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <Home className="mr-2 h-5 w-5 text-green-500" />
              Mes Projets
            </CardTitle>
            <CardDescription>
              Tous vos projets en cours et passés
            </CardDescription>
          </div>
          <Button size="sm" onClick={() => navigate("/projects/submit")}>
            <Plus className="mr-2 h-4 w-4" /> Nouveau projet
          </Button>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">Vous n'avez pas encore de projets.</p>
            <Button onClick={() => navigate("/projects/submit")}>
              Soumettre un nouveau projet
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Interface spécifique pour les métreurs
  if (userRole === "estimator") {
    return (
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="flex items-center">
              <CalendarClock className="mr-2 h-5 w-5 text-orange-500" />
              Projets à évaluer
            </CardTitle>
            <CardDescription>
              Projets nécessitant une visite et une estimation
            </CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8">
            <AlertCircle className="h-12 w-12 text-orange-500 mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">
              Aucun projet nécessitant une évaluation pour le moment.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  // Interface par défaut (Admin)
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between">
        <div>
          <CardTitle className="flex items-center">
            <User className="mr-2 h-5 w-5 text-purple-500" />
            Tous les Projets
          </CardTitle>
          <CardDescription>
            Liste de tous les projets sur la plateforme
          </CardDescription>
        </div>
        <Button size="sm" onClick={() => navigate("/admin/projects")}>
          Gérer les projets
        </Button>
      </CardHeader>
      <CardContent>
        <div className="text-center py-8">
          <p className="text-muted-foreground mb-4">
            Consultez le tableau de bord administrateur pour une vue complète des projets.
          </p>
          <Button onClick={() => navigate("/admin/projects")}>
            Gérer les projets
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
