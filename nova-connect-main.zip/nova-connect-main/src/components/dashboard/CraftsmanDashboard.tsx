
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ShoppingBag, 
  Wallet, 
  FileText, 
  CheckCheck,
  Clock,
  CalendarClock,
  Building,
  HardHat,
  Hammer
} from "lucide-react";
import { useNavigate } from "react-router-dom";

export function CraftsmanDashboard() {
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      {/* Titre spécifique pour artisan */}
      <div className="mb-4">
        <h2 className="text-2xl font-semibold mb-2">Espace Artisan</h2>
        <p className="text-muted-foreground">
          Gérez vos chantiers et trouvez de nouveaux projets sur la marketplace
        </p>
      </div>
      
      {/* Stats Overview */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Projets Disponibles</CardTitle>
            <ShoppingBag className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
            <p className="text-xs text-muted-foreground">
              Projets disponibles sur la marketplace
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full"
              onClick={() => navigate("/projects/marketplace")}
            >
              Voir la marketplace
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Chantiers En Cours</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">
              Chantier actuellement en cours
            </p>
          </CardContent>
          <CardFooter>
            <Button 
              className="w-full" 
              variant="outline"
              onClick={() => navigate("/dashboard?tab=projects")}
            >
              Voir mes chantiers
            </Button>
          </CardFooter>
        </Card>
        
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Projets Terminés</CardTitle>
            <CheckCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1</div>
            <p className="text-xs text-muted-foreground">
              Projets terminés ce mois-ci
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Actions rapides */}
      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
          <CardDescription>Accédez rapidement à vos fonctionnalités clés</CardDescription>
        </CardHeader>
        <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button className="w-full flex justify-center items-center gap-2 h-auto py-4"
            onClick={() => navigate("/projects/marketplace")}>
            <ShoppingBag className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span>Marketplace</span>
              <span className="text-xs font-normal text-muted-foreground">Trouver des projets</span>
            </div>
          </Button>
          
          <Button className="w-full flex justify-center items-center gap-2 h-auto py-4"
            variant="outline"
            onClick={() => navigate("/dashboard?tab=projects")}>
            <HardHat className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span>Mes chantiers</span>
              <span className="text-xs font-normal text-muted-foreground">Projets en cours</span>
            </div>
          </Button>
          
          <Button className="w-full flex justify-center items-center gap-2 h-auto py-4"
            variant="outline"
            onClick={() => navigate("/dashboard?tab=payments")}>
            <Wallet className="h-5 w-5" />
            <div className="flex flex-col items-start">
              <span>Paiements</span>
              <span className="text-xs font-normal text-muted-foreground">Suivi financier</span>
            </div>
          </Button>
        </CardContent>
      </Card>

      {/* Payment Information */}
      <Card>
        <CardHeader>
          <CardTitle>Commissions et paiements</CardTitle>
          <CardDescription>Informations importantes sur les commissions</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-start gap-4 p-4 rounded-lg border">
            <Wallet className="h-8 w-8 text-primary" />
            <div>
              <h3 className="font-medium mb-1">Processus de paiement</h3>
              <p className="text-sm text-muted-foreground">
                Les clients paient l'intégralité des travaux en amont, que nous conservons en sécurité.
                Une fois les travaux terminés et validés par notre métreur, Nova Connect vous verse le paiement, 
                après déduction de la commission de 15%.
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-4 p-4 rounded-lg border">
            <FileText className="h-8 w-8 text-primary" />
            <div>
              <h3 className="font-medium mb-1">Documents requis</h3>
              <p className="text-sm text-muted-foreground mb-2">
                Pour recevoir vos paiements, assurez-vous d'avoir fourni les documents suivants:
              </p>
              <ul className="text-sm space-y-1">
                <li className="flex items-center gap-2">
                  <CheckCheck className="h-4 w-4 text-green-500" />
                  <span>RIB pour recevoir vos paiements</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCheck className="h-4 w-4 text-green-500" />
                  <span>Assurance professionnelle</span>
                </li>
                <li className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-orange-500" />
                  <span>Attestation fiscale (en attente)</span>
                </li>
              </ul>
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button 
            variant="outline" 
            className="w-full"
            onClick={() => navigate("/projects/marketplace")}
          >
            Consulter les projets disponibles
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
