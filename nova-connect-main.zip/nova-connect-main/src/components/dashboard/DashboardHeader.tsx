
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { User } from "@/types/user";
import { Briefcase, Plus, LayoutDashboard, HardHat, Home, FileText, Calendar } from "lucide-react";

interface DashboardHeaderProps {
  user: User;
}

export function DashboardHeader({ user }: DashboardHeaderProps) {
  const navigate = useNavigate();

  // Action principale spécifique au rôle
  const renderPrimaryAction = () => {
    if (user.role === "homeowner") {
      return (
        <Button onClick={() => navigate("/projects/submit")}>
          <Plus className="mr-2 h-4 w-4" /> Nouveau projet
        </Button>
      );
    }
    
    if (user.role === "craftsman") {
      return (
        <div className="flex gap-2">
          <Button onClick={() => navigate("/projects/marketplace")}>
            <Briefcase className="mr-2 h-4 w-4" /> Marketplace
          </Button>
          <Button variant="outline" onClick={() => navigate("/profile")}>
            <Calendar className="mr-2 h-4 w-4" /> Disponibilités
          </Button>
        </div>
      );
    }
    
    if (user.role === "estimator") {
      return (
        <div className="flex gap-2">
          <Button onClick={() => navigate("/estimator/pending")}>
            <FileText className="mr-2 h-4 w-4" /> Projets à évaluer
          </Button>
          <Button variant="outline" onClick={() => navigate("/projects/submit")}>
            <Plus className="mr-2 h-4 w-4" /> Créer un projet
          </Button>
        </div>
      );
    }
    
    if (user.role === "admin") {
      return (
        <div className="flex gap-2">
          <Button onClick={() => navigate("/admin")}>
            <LayoutDashboard className="mr-2 h-4 w-4" /> Administration
          </Button>
          <Button variant="outline" onClick={() => navigate("/projects/submit")}>
            <Plus className="mr-2 h-4 w-4" /> Nouveau projet
          </Button>
        </div>
      );
    }
    
    return null;
  };

  // Titre spécifique au rôle
  const getDashboardTitle = () => {
    switch (user.role) {
      case "craftsman":
        return "Espace Artisan";
      case "admin":
        return "Administration";
      case "homeowner":
        return "Espace Propriétaire";
      case "estimator":
        return "Espace Métreur";
      default:
        return "Tableau de Bord";
    }
  };
  
  // Sous-titre spécifique au rôle
  const getDashboardSubtitle = () => {
    switch (user.role) {
      case "craftsman":
        return "Consultez la marketplace et gérez vos chantiers";
      case "admin":
        return "Gérez les utilisateurs et les projets";
      case "homeowner":
        return "Suivez vos projets de rénovation";
      case "estimator":
        return "Évaluez et validez les projets";
      default:
        return "Bienvenue sur Nova Connect";
    }
  };

  // Icône spécifique au rôle
  const getRoleIcon = () => {
    switch (user.role) {
      case "craftsman":
        return <HardHat className="h-8 w-8 text-brand-blue" />;
      case "admin":
        return <LayoutDashboard className="h-8 w-8 text-brand-orange" />;
      case "homeowner":
        return <Home className="h-8 w-8 text-brand-blue" />;
      case "estimator":
        return <FileText className="h-8 w-8 text-brand-orange" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-gradient-to-r from-slate-50 to-slate-100 p-6 rounded-lg shadow-sm border mb-8">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="bg-white p-3 rounded-full shadow-sm">
            {getRoleIcon()}
          </div>
          <div>
            <h1 className="text-3xl font-bold">
              {getDashboardTitle()}
            </h1>
            <p className="text-muted-foreground">
              {getDashboardSubtitle()}
              {user.firstName && <span className="ml-1">, {user.firstName}</span>}
            </p>
          </div>
        </div>
        <div>
          {renderPrimaryAction()}
        </div>
      </div>
    </div>
  );
}
