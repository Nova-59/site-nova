
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Activity, Calendar, Clock, Hammer, MessageSquare, Plus, Star, FileText } from "lucide-react";
import { Link } from "react-router-dom";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { useAuth } from "@/contexts/AuthContext";
import { useState, useEffect } from "react";

export function HomeownerDashboard() {
  const { user } = useAuth();
  const [hasProjects, setHasProjects] = useState(false);
  
  // Détermine si l'utilisateur est nouveau (moins de 24h)
  const isNewUser = user && new Date().getTime() - new Date(user.createdAt).getTime() < 24 * 60 * 60 * 1000;
  
  // Un seul projet de démonstration clairement identifié pour les utilisateurs non nouveaux
  const demoProject = {
    id: "demo-project", 
    title: "[DÉMO] Rénovation Salle de Bain", 
    status: "Recherche d'Artisan", 
    date: "15 Oct 2023", 
    progress: 40
  };
  
  // N'affiche le projet de démonstration que si l'utilisateur n'est pas nouveau
  const activeRequests = hasProjects ? [demoProject] : [];
  const completedRequests = [];
  
  useEffect(() => {
    // Dans une vraie app, on ferait un appel API pour récupérer les projets de l'utilisateur
    setHasProjects(!isNewUser);
  }, [isNewUser]);
  
  return (
    <MainLayoutWithNotifications>
      <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold">Tableau de bord</h1>
          <Button className="btn-primary" asChild>
            <Link to="/submit-project">
              <Plus className="mr-2 h-4 w-4" /> Nouveau Projet
            </Link>
          </Button>
        </div>
        
        {isNewUser && (
          <Card className="my-6">
            <CardContent className="pt-6 flex flex-col items-center text-center p-6">
              <FileText className="h-12 w-12 text-primary mb-4" />
              <h2 className="text-xl font-semibold mb-2">Bienvenue sur votre espace personnel !</h2>
              <p className="text-muted-foreground mb-4">
                Créez votre premier projet pour commencer à trouver un artisan qualifié.
              </p>
              <Button asChild className="mt-2">
                <Link to="/submit-project">
                  <Plus className="mr-2 h-4 w-4" /> Soumettre un projet
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}
        
        {(!isNewUser || hasProjects) && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Projets Actifs</CardTitle>
                  <CardDescription className="text-2xl font-bold">{activeRequests.length}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-muted-foreground">
                    <Activity className="inline h-4 w-4 mr-1" /> Dernière mise à jour il y a 2 heures
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Projets Terminés</CardTitle>
                  <CardDescription className="text-2xl font-bold">{completedRequests.length}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-muted-foreground">
                    <Calendar className="inline h-4 w-4 mr-1" /> Ce mois-ci
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Note Moyenne Artisans</CardTitle>
                  <CardDescription className="text-2xl font-bold">{hasProjects ? "4.9" : "N/A"}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-xs text-muted-foreground">
                    <Star className="inline h-4 w-4 mr-1 text-yellow-500" /> De vos projets
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <Tabs defaultValue="active">
              <TabsList>
                <TabsTrigger value="active">Projets Actifs</TabsTrigger>
                <TabsTrigger value="completed">Terminés</TabsTrigger>
                <TabsTrigger value="saved">Artisans Favoris</TabsTrigger>
              </TabsList>
              
              <TabsContent value="active" className="mt-6 space-y-4">
                {activeRequests.length > 0 ? (
                  activeRequests.map(request => (
                    <Card key={request.id}>
                      <CardContent className="p-4">
                        <div className="flex flex-col md:flex-row justify-between">
                          <div>
                            <h3 className="font-semibold mb-1">{request.title}</h3>
                            <div className="flex items-center gap-4 text-sm">
                              <Badge variant={request.status === "Estimating" ? "secondary" : "default"}>
                                {request.status}
                              </Badge>
                              <span className="text-muted-foreground flex items-center">
                                <Clock className="mr-1 h-4 w-4" /> {request.date}
                              </span>
                            </div>
                          </div>
                          <div className="mt-4 md:mt-0 flex gap-3 md:flex-col md:items-end">
                            <div className="w-full md:w-32">
                              <div className="flex justify-between text-xs mb-1">
                                <span>Progression</span>
                                <span>{request.progress}%</span>
                              </div>
                              <Progress value={request.progress} className="h-2" />
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm" asChild>
                                <Link to={`/projects/${request.id}`}>
                                  Détails
                                </Link>
                              </Button>
                              <Button variant="ghost" size="sm">
                                <MessageSquare className="mr-1 h-4 w-4" /> Messages
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                ) : (
                  <Card className="p-8 text-center">
                    <h3 className="text-lg font-medium mb-2">Aucun projet actif</h3>
                    <p className="text-muted-foreground mb-4">
                      Vous n'avez aucun projet en cours pour le moment.
                    </p>
                    <Button asChild>
                      <Link to="/submit-project">
                        Créer mon premier projet
                      </Link>
                    </Button>
                  </Card>
                )}
              </TabsContent>
              
              <TabsContent value="completed" className="mt-6 space-y-4">
                <Card className="p-8 text-center">
                  <h3 className="text-lg font-medium mb-2">Aucun projet terminé</h3>
                  <p className="text-muted-foreground mb-4">
                    Vos projets terminés apparaîtront ici.
                  </p>
                </Card>
              </TabsContent>
              
              <TabsContent value="saved">
                <div className="py-8 text-center">
                  <Hammer className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-medium mb-2">Pas encore d'artisans favoris</h3>
                  <p className="text-muted-foreground mb-4">Enregistrez vos artisans favoris pour les contacter rapidement pour vos futurs projets</p>
                  <Button asChild>
                    <Link to="/projects/marketplace">Parcourir les artisans</Link>
                  </Button>
                </div>
              </TabsContent>
            </Tabs>
          </>
        )}
      </div>
    </MainLayoutWithNotifications>
  );
}
