
import { Button } from "@/components/ui/button";

interface ProjectCardProps {
  title: string;
  location: string;
  progress: number;
  isCompleted?: boolean;
}

export function ProjectCard({ title, location, progress, isCompleted = false }: ProjectCardProps) {
  return (
    <div className="rounded-lg border p-4">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="font-medium">{title}</h3>
          <p className="text-sm text-muted-foreground">{location}</p>
        </div>
        <Button size="sm" variant="outline">Voir détails</Button>
      </div>
      <div className="mt-2">
        <div className="flex justify-between text-sm">
          <span>Progression:</span>
          <span>{progress}%</span>
        </div>
        <div className="w-full h-2 bg-gray-200 rounded-full mt-1">
          <div 
            className={`h-full ${isCompleted ? 'bg-green-500' : 'bg-primary'} rounded-full`} 
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
}
