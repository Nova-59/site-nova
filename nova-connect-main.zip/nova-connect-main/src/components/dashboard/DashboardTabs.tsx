
import { ReactNode, useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserRole } from "@/types/user";
import { useToast } from "@/hooks/use-toast";
import { InfoAlert } from "@/components/ui/InfoAlert";
import { Skeleton } from "@/components/ui/skeleton";
import { useRlsPolicy } from "@/hooks/useRlsPolicy";

interface DashboardTab {
  id: string;
  label: string;
  content: ReactNode;
  roles?: UserRole[];
}

interface DashboardTabsProps {
  tabs: DashboardTab[];
  activeTab: string;
  onTabChange: (value: string) => void;
  userRole: UserRole;
}

export function DashboardTabs({ tabs, activeTab, onTabChange, userRole }: DashboardTabsProps) {
  const { toast } = useToast();
  
  // Utiliser notre nouveau hook pour vérifier les politiques RLS
  const rlsPolicy = useRlsPolicy({
    tableName: "profiles",
    showToast: false
  });
  
  // Filter tabs based on user role
  const filteredTabs = tabs.filter(tab => !tab.roles || tab.roles.includes(userRole));
  
  // Handle tab change with validation
  const handleTabChange = (value: string) => {
    // Vérifie si l'onglet est autorisé pour le rôle de l'utilisateur
    const requestedTab = tabs.find(tab => tab.id === value);
    
    if (requestedTab && requestedTab.roles && !requestedTab.roles.includes(userRole)) {
      toast({
        variant: "destructive",
        title: "Accès refusé",
        description: `Vous n'avez pas les permissions nécessaires pour accéder à cet onglet.`
      });
      return;
    }
    
    onTabChange(value);
  };
  
  // S'assurer que l'onglet actif est disponible, sinon prendre le premier
  const safeActiveTab = filteredTabs.some(tab => tab.id === activeTab) 
    ? activeTab 
    : (filteredTabs.length > 0 ? filteredTabs[0].id : '');
  
  if (rlsPolicy.isChecking) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (rlsPolicy.error) {
    return (
      <InfoAlert 
        title="Problème d'autorisation" 
        message={`Un problème a été détecté avec les politiques de sécurité: ${rlsPolicy.error.message}. Veuillez contacter l'administrateur.`}
        severity="high"
      />
    );
  }
  
  if (filteredTabs.length === 0) {
    return (
      <InfoAlert 
        title="Aucun contenu disponible" 
        message={`Aucun onglet n'est disponible pour votre niveau d'accès (${userRole}). Veuillez contacter l'administrateur si vous pensez qu'il s'agit d'une erreur.`} 
        severity="medium"
      />
    );
  }
  
  return (
    <Tabs 
      value={safeActiveTab} 
      onValueChange={handleTabChange} 
      className="space-y-6"
    >
      <TabsList>
        {filteredTabs.map(tab => (
          <TabsTrigger key={tab.id} value={tab.id}>
            {tab.label}
          </TabsTrigger>
        ))}
      </TabsList>

      {filteredTabs.map(tab => (
        <TabsContent key={tab.id} value={tab.id} className="space-y-6">
          {tab.content}
        </TabsContent>
      ))}
    </Tabs>
  );
}
