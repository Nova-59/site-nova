
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { 
  CheckSquare, 
  Search,
  ClipboardCheck, 
  FileCheck,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { cn } from "@/lib/utils";
import { StepDisplay, StepItem } from "./StepDisplay";
import { BenefitList, BenefitItem } from "./BenefitList";

interface CraftsmanSectionProps {
  expandedSection: string | null;
  toggleSection: (section: string) => void;
}

const craftsmanSteps: StepItem[] = [
  {
    title: "Parcourir les projets",
    description: "Consultez la marketplace des projets",
    icon: <Search className="h-4 w-4" />
  },
  {
    title: "Consulter les détails",
    description: "Analyser le cahier des charges",
    icon: <FileCheck className="h-4 w-4" />
  },
  {
    title: "Évaluer la faisabilité",
    description: "Vérifier la compatibilité avec votre planning",
    icon: <ClipboardCheck className="h-4 w-4" />
  },
  {
    title: "Prendre en charge le projet",
    description: "S'engager à respecter les délais et la qualité",
    icon: <CheckSquare className="h-4 w-4" />
  }
];

const craftsmanBenefits: BenefitItem[] = [
  {
    description: "Projets déjà validés et chiffrés par nos métreurs experts"
  },
  {
    description: "Clients motivés avec budget alloué validé"
  },
  {
    description: "Économisez du temps sur les visites préalables et les devis"
  }
];

export function CraftsmanSection({ expandedSection, toggleSection }: CraftsmanSectionProps) {
  return (
    <div className="bg-card shadow-lg rounded-lg p-6 hover:shadow-xl transition-all duration-300">
      <div className="flex justify-between items-center cursor-pointer" onClick={() => toggleSection('craftsman')}>
        <h2 className="text-2xl font-bold">Pour les artisans</h2>
        {expandedSection === 'craftsman' ? <ChevronUp /> : <ChevronDown />}
      </div>
      
      <div className={cn(
        "grid md:grid-cols-2 gap-12 overflow-hidden transition-all duration-300",
        expandedSection === 'craftsman' ? 'mt-6 max-h-[1000px]' : 'max-h-0 md:max-h-[1000px]'
      )}>
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Comment prendre en charge des projets</h3>
          <ol className="space-y-3 list-decimal list-inside">
            <li className="hover:bg-muted/30 p-2 rounded-md transition-colors">
              <span className="font-medium">Consultez la marketplace</span>
              <span className="text-muted-foreground block ml-6">
                Parcourez les projets disponibles avec leur description sommaire
              </span>
            </li>
            <li className="hover:bg-muted/30 p-2 rounded-md transition-colors">
              <span className="font-medium">Analysez le cahier des charges</span>
              <span className="text-muted-foreground block ml-6">
                Étudiez les détails complets et le budget validé par notre métreur
              </span>
            </li>
            <li className="hover:bg-muted/30 p-2 rounded-md transition-colors">
              <span className="font-medium">Confirmez votre engagement</span>
              <span className="text-muted-foreground block ml-6">
                Si le projet vous convient, prenez en charge la mission et engagez-vous à respecter les délais
              </span>
            </li>
          </ol>
          
          <div className="bg-muted p-4 rounded-md mt-6 hover:bg-muted/80 transition-colors">
            <h4 className="font-medium mb-2">Avantages pour les artisans</h4>
            <BenefitList items={craftsmanBenefits} className="text-sm" />
          </div>
          
          <div className="mt-4">
            <Button asChild variant="default" className="w-full">
              <Link to="/projects/marketplace">Voir les projets disponibles</Link>
            </Button>
          </div>
        </div>
        <div>
          <StepDisplay steps={craftsmanSteps} />
          <div className="flex justify-center">
            <Button asChild variant="outline" size="lg" className="mt-6 hover-scale">
              <Link to="/craftsman/register">Devenir artisan partenaire</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
