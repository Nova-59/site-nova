
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";

export function ContactSection() {
  return (
    <div className="mt-16 text-center">
      <h2 className="text-2xl font-bold mb-4">Des questions ?</h2>
      <p className="text-muted-foreground mb-8">
        Notre équipe est disponible pour répondre à toutes vos questions sur notre fonctionnement.
      </p>
      <div className="flex justify-center gap-4 flex-wrap">
        <Button asChild className="hover-scale">
          <Link to="/contact">Contactez-nous</Link>
        </Button>
        <Button asChild variant="outline" className="hover-scale">
          <Link to="/faq">Consultez notre FAQ</Link>
        </Button>
      </div>
    </div>
  );
}
