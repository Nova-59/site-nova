
import { useState } from "react";
import { Steps, Step } from "@/components/ui/steps";
import { Button } from "@/components/ui/button";

export interface StepItem {
  title: string;
  description: string;
  icon: React.ReactNode;
}

interface StepDisplayProps {
  steps: StepItem[];
  className?: string;
}

export function StepDisplay({ steps, className }: StepDisplayProps) {
  const [activeStep, setActiveStep] = useState(1);
  
  return (
    <div className={className}>
      <Steps active={activeStep} className="mb-8">
        {steps.map((step, index) => (
          <Step
            key={index}
            title={step.title}
            description={step.description}
            icon={step.icon}
          />
        ))}
      </Steps>
      <div className="flex justify-center space-x-2">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setActiveStep(prev => Math.max(1, prev - 1))}
          disabled={activeStep <= 1}
        >
          Précédent
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={() => setActiveStep(prev => Math.min(steps.length, prev + 1))}
          disabled={activeStep >= steps.length}
        >
          Suivant
        </Button>
      </div>
    </div>
  );
}
