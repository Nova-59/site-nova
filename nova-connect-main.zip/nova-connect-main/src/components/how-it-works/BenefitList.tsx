
import { CheckSquare, Info } from "lucide-react";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export interface BenefitItem {
  title?: string;
  description: string;
  details?: string;
}

interface BenefitListProps {
  items: BenefitItem[];
  className?: string;
}

export function BenefitList({ items, className }: BenefitListProps) {
  const [expandedIndex, setExpandedIndex] = useState<number | null>(null);
  
  const toggleDetails = (index: number) => {
    setExpandedIndex(expandedIndex === index ? null : index);
  };
  
  return (
    <ul className={cn("space-y-3", className)}>
      {items.map((item, index) => (
        <li 
          key={index} 
          className={cn(
            "rounded-md transition-colors", 
            expandedIndex === index 
              ? "bg-muted/50 border border-muted" 
              : "hover:bg-muted/30"
          )}
        >
          <div className="flex items-start gap-2 p-2">
            <CheckSquare className="h-5 w-5 text-primary mt-0.5" />
            <div className="flex-1">
              <div className="flex justify-between items-start">
                <span>
                  {item.title && <strong>{item.title}</strong>}
                  {item.title && " - "}
                  {item.description}
                </span>
                {item.details && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-6 w-6 mt-0 ml-2" 
                    onClick={() => toggleDetails(index)}
                  >
                    <Info className="h-4 w-4" />
                  </Button>
                )}
              </div>
              
              {expandedIndex === index && item.details && (
                <div className="text-sm text-muted-foreground mt-2 pl-1 border-l-2 border-primary/20">
                  {item.details}
                </div>
              )}
            </div>
          </div>
        </li>
      ))}
    </ul>
  );
}
