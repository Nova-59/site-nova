
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { 
  UploadCloud, 
  Calendar, 
  CreditCard, 
  Store, 
  UserCheck,
  ChevronDown,
  ChevronUp
} from "lucide-react";
import { cn } from "@/lib/utils";
import { StepDisplay, StepItem } from "./StepDisplay";
import { BenefitList, BenefitItem } from "./BenefitList";

interface HomeownerSectionProps {
  expandedSection: string | null;
  toggleSection: (section: string) => void;
}

const homeownerSteps: StepItem[] = [
  {
    title: "Dépôt du projet",
    description: "Décrivez votre projet et téléchargez des photos",
    icon: <UploadCloud className="h-4 w-4" />
  },
  {
    title: "Visite du métreur",
    description: "Évaluation professionnelle sur place",
    icon: <Calendar className="h-4 w-4" />
  },
  {
    title: "Validation du devis",
    description: "Paiement des frais de mise en service",
    icon: <CreditCard className="h-4 w-4" />
  },
  {
    title: "Publication par l'administrateur",
    description: "Mise en ligne sur notre marketplace par nos équipes",
    icon: <Store className="h-4 w-4" />
  },
  {
    title: "Sélection de l'artisan",
    description: "Choisissez parmi les artisans intéressés",
    icon: <UserCheck className="h-4 w-4" />
  }
];

const homeownerBenefits: BenefitItem[] = [
  {
    title: "Devis précis et réaliste",
    description: "Chaque projet est évalué par un expert avant d'être proposé"
  },
  {
    title: "Artisans qualifiés et vérifiés",
    description: "Tous nos artisans sont soigneusement sélectionnés"
  },
  {
    title: "Transparence du processus",
    description: "Vous êtes informé à chaque étape de l'avancement"
  },
  {
    title: "Paiements sécurisés",
    description: "Notre système protège toutes les transactions"
  }
];

export function HomeownerSection({ expandedSection, toggleSection }: HomeownerSectionProps) {
  return (
    <div className="bg-card shadow-lg rounded-lg p-6 mb-6 hover:shadow-xl transition-all duration-300">
      <div className="flex justify-between items-center cursor-pointer" onClick={() => toggleSection('homeowner')}>
        <h2 className="text-2xl font-bold">Pour les propriétaires</h2>
        {expandedSection === 'homeowner' ? <ChevronUp /> : <ChevronDown />}
      </div>
      
      <div className={cn(
        "grid md:grid-cols-2 gap-12 overflow-hidden transition-all duration-300",
        expandedSection === 'homeowner' ? 'mt-6 max-h-[1000px]' : 'max-h-0 md:max-h-[1000px]'
      )}>
        <div>
          <StepDisplay steps={homeownerSteps} />
          <div className="flex justify-center">
            <Button asChild size="lg" className="mt-6 hover-scale">
              <Link to="/submit-project">Déposer un projet</Link>
            </Button>
          </div>
        </div>
        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Avantages pour les propriétaires</h3>
          <BenefitList items={homeownerBenefits} />
          
          <div className="bg-muted p-4 rounded-md mt-6 hover:bg-muted/80 transition-colors">
            <h4 className="font-medium mb-2">Frais de mise en service</h4>
            <p className="text-sm text-muted-foreground">
              Après la visite du métreur, un devis précis est établi. Des frais de mise en service 
              proportionnels à l'ampleur du projet vous seront demandés pour la publication 
              de votre projet sur notre marketplace par nos administrateurs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
