
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { Users, Briefcase, User, ClipboardList, RefreshCw } from "lucide-react";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { LoadingState } from "@/components/admin/LoadingState";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { user, loading, refreshSession } = useAuth();
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Debug information
  useEffect(() => {
    console.log("AdminDashboard rendered", { 
      user: user?.email, 
      role: user?.role, 
      loading, 
      path: window.location.pathname 
    });
  }, [user, loading]);
  
  // Force refresh après 5 secondes si toujours en chargement
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (loading) {
      timer = setTimeout(() => {
        console.log("AdminDashboard still loading after 5 seconds, forcing refresh");
        refreshSession();
      }, 5000);
    }
    
    return () => {
      if (timer) clearTimeout(timer);
    };
  }, [loading, refreshSession]);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      await refreshSession();
      toast({
        title: "Session actualisée",
        description: "Les données ont été rechargées avec succès."
      });
    } catch (error) {
      console.error("Error refreshing session:", error);
      toast({
        variant: "destructive",
        title: "Erreur",
        description: "Impossible d'actualiser la session."
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  // Attendre que les données d'authentification soient chargées
  if (loading) {
    return <LoadingState message="Chargement du tableau de bord administrateur..." />;
  }

  // Vérifier si l'utilisateur est connecté
  if (!user) {
    console.log("No user in AdminDashboard, redirecting to auth");
    navigate("/auth");
    return null;
  }

  // Vérifier si l'utilisateur est un administrateur
  if (user.role !== "admin") {
    console.log("Non-admin trying to access /admin, redirecting...");
    toast({
      variant: "destructive",
      title: "Accès non autorisé",
      description: "Vous n'avez pas les permissions pour accéder à cette page."
    });
    
    // Rediriger en fonction du rôle
    if (user.role === "craftsman") {
      navigate("/projects/marketplace");
    } else {
      navigate("/dashboard");
    }
    return null;
  }

  console.log("AdminDashboard rendering content for user:", user.email);

  return (
    <MainLayoutWithNotifications>
      <div className="container p-6 space-y-6">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold">Tableau de Bord Administrateur</h1>
            <p className="text-muted-foreground">Gérez vos utilisateurs, artisans, clients et projets</p>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="bg-blue-50">Admin</Badge>
            <Button 
              variant="outline" 
              size="sm"
              onClick={handleManualRefresh}
              disabled={isRefreshing}
            >
              {isRefreshing ? (
                <>
                  <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                  Actualisation...
                </>
              ) : (
                <>
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Actualiser
                </>
              )}
            </Button>
            <Button variant="outline" onClick={() => navigate("/")}>
              Retour au site
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Users className="h-5 w-5 text-blue-500" /> 
                Gestion des utilisateurs
              </CardTitle>
              <CardDescription>Gérer les autorisations des comptes</CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full" 
                onClick={() => navigate("/admin/users")}
              >
                Accéder
              </Button>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-yellow-500" /> 
                Artisans
              </CardTitle>
              <CardDescription>Voir et référencer les artisans</CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full" 
                onClick={() => navigate("/admin/craftsmen")}
              >
                Accéder
              </Button>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-green-500" /> 
                Clients
              </CardTitle>
              <CardDescription>Voir les clients inscrits</CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full" 
                onClick={() => navigate("/admin/clients")}
              >
                Accéder
              </Button>
            </CardContent>
          </Card>
          
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2">
                <ClipboardList className="h-5 w-5 text-purple-500" /> 
                Projets
              </CardTitle>
              <CardDescription>Voir les projets en cours</CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                className="w-full" 
                onClick={() => navigate("/admin/projects")}
              >
                Accéder
              </Button>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle>Accès rapide</CardTitle>
            <CardDescription>Aperçu des activités récentes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={() => navigate("/admin/users")}>
                  <Users className="mr-2 h-4 w-4" />
                  Utilisateurs récents
                </Button>
                <Button variant="outline" onClick={() => navigate("/admin/projects")}>
                  <ClipboardList className="mr-2 h-4 w-4" />
                  Projets récents
                </Button>
              </div>
              
              <div className="text-center text-sm text-muted-foreground">
                <p>Pour accéder à toutes les fonctionnalités administratives, utilisez les cartes ci-dessus.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </MainLayoutWithNotifications>
  );
};

export default AdminDashboard;
