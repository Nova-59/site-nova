
import { useState, useMemo } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ArtisanFilters } from "@/components/artisans/ArtisanFilters";
import { ArtisanHowItWorks } from "@/components/artisans/ArtisanHowItWorks";
import { ArtisanListingHeader } from "@/components/artisans/ArtisanListingHeader";
import { ArtisanResultsCount } from "@/components/artisans/ArtisanResultsCount";
import { ArtisanList } from "@/components/artisans/ArtisanList";
import { ArtisanPagination } from "@/components/artisans/ArtisanPagination";

interface Artisan {
  id: string;
  name: string;
  profession: string;
  rating: number;
  completedProjects: number;
  location: string;
  description: string;
  specialties: string[];
}

// Tableau vide pour supprimer les artisans de démonstration
const mockArtisans: Artisan[] = [];

export function ArtisanDirectory() {
  const [searchTerm, setSearchTerm] = useState("");
  const [professionFilter, setProfessionFilter] = useState<string | "all">("all");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;
  
  // Filter artisans based on search and profession filter
  const filteredArtisans = useMemo(() => {
    return mockArtisans
      .filter(artisan => 
        (professionFilter === "all" || artisan.profession.toLowerCase() === professionFilter.toLowerCase()) &&
        (artisan.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
         artisan.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
         artisan.specialties.some(s => s.toLowerCase().includes(searchTerm.toLowerCase())))
      );
  }, [mockArtisans, searchTerm, professionFilter]);

  // Calculate pagination values
  const totalPages = Math.max(1, Math.ceil(filteredArtisans.length / itemsPerPage));
  
  // Get current page artisans
  const currentArtisans = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return filteredArtisans.slice(startIndex, startIndex + itemsPerPage);
  }, [filteredArtisans, currentPage, itemsPerPage]);

  const resetFilters = () => {
    setSearchTerm("");
    setProfessionFilter("all");
    setCurrentPage(1);
  };

  // Handle page change
  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    // Scroll to top of results
    window.scrollTo({
      top: document.getElementById('artisan-results')?.offsetTop || 0,
      behavior: 'smooth'
    });
  };

  return (
    <MainLayout>
      <div className="container py-8">
        <ArtisanListingHeader />

        {/* Filters */}
        <ArtisanFilters 
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          professionFilter={professionFilter}
          setProfessionFilter={setProfessionFilter}
        />

        {/* Results */}
        <div id="artisan-results">
          <ArtisanResultsCount count={filteredArtisans.length} />
          
          <ArtisanList 
            artisans={currentArtisans}
            resetFilters={resetFilters}
          />
          
          <ArtisanPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={handlePageChange}
          />
        </div>
        
        <ArtisanHowItWorks />
      </div>
    </MainLayout>
  );
}
