
import { MainLayout } from "@/components/layout/MainLayout";

export function Zinguerie() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Zinguerie</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de zinguerie</h2>
            <p className="mb-4">
              La zinguerie est un élément essentiel pour préserver la durabilité de votre toiture et protéger votre habitation contre les infiltrations d'eau.
              Nos artisans zingueurs réalisent tous types de travaux de zinguerie avec précision et soins.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Installation et remplacement de gouttières</li>
              <li>Pose de descentes d'eau pluviale</li>
              <li>Réalisation de faîtages et de rives</li>
              <li>Habillage de cheminée</li>
              <li>Mise en place de solins et de noues</li>
              <li>Installation de châssis de toit</li>
              <li>Réparation d'éléments de zinguerie endommagés</li>
            </ul>
            
            <p>
              Nous travaillons avec différents matériaux (zinc, cuivre, aluminium) pour s'adapter à vos besoins et au style de votre habitation.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Pourquoi faire appel à nos zingueurs ?</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Savoir-faire technique et artisanal</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Travail soigné et esthétique</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Étanchéité parfaite garantie</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Solutions adaptées à chaque configuration</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Intervention rapide en cas d'urgence</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
