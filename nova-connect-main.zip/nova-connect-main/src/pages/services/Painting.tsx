
import { MainLayout } from "@/components/layout/MainLayout";

export function Painting() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Peinture</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de peinture</h2>
            <p className="mb-4">
              Nos peintres professionnels transforment vos espaces intérieurs et extérieurs avec des finitions 
              impeccables et des solutions adaptées à vos besoins.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Peinture intérieure et extérieure</li>
              <li>Pose de papier peint et revêtements muraux</li>
              <li>Peinture décorative et effets spéciaux</li>
              <li>Traitement des façades</li>
              <li>Imperméabilisation des surfaces</li>
              <li>Ravalement de façade</li>
              <li>Rénovation d'anciens supports</li>
            </ul>
            
            <p>
              Nous utilisons des peintures de qualité, respectueuses de l'environnement et adaptées à chaque type de surface.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Pourquoi choisir nos services de peinture ?</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Préparation soignée des surfaces</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Finitions de haute qualité</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Conseil en décoration et choix des couleurs</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Protection efficace de vos biens pendant les travaux</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Chantier propre et nettoyé à la fin des travaux</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
