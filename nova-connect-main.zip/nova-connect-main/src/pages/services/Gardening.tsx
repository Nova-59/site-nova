
import { MainLayout } from "@/components/layout/MainLayout";

export function Gardening() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Jardinage</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de jardinage</h2>
            <p className="mb-4">
              Nos jardiniers passionnés prennent soin de vos espaces verts et créent des aménagements 
              extérieurs qui valorisent votre propriété tout en respectant l'environnement.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Entretien régulier de jardin</li>
              <li>Tonte de pelouse et taille de haies</li>
              <li>Création et aménagement paysager</li>
              <li>Plantation d'arbres et d'arbustes</li>
              <li>Installation de systèmes d'arrosage</li>
              <li>Création de potagers et jardins fruitiers</li>
              <li>Traitement écologique des nuisibles</li>
            </ul>
            
            <p>
              Nous proposons des solutions adaptées à vos besoins spécifiques et à votre type de jardin pour un entretien optimal.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Notre approche du jardinage</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Respect de la biodiversité</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Pratiques écologiques et durables</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Connaissance approfondie des végétaux</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Interventions selon les saisons</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Conseils personnalisés pour l'entretien</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
