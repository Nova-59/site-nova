
import { MainLayout } from "@/components/layout/MainLayout";

export function Plumbing() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Plomberie dans les Hauts-de-France</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de plomberie en Hauts-de-France</h2>
            <p className="mb-4">
              Nous proposons une gamme complète de services de plomberie pour votre maison ou votre entreprise
              dans toute la région des Hauts-de-France. Nos plombiers qualifiés interviennent rapidement à Lille, 
              Amiens, Arras et dans toutes les communes environnantes.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Installation et réparation de robinetterie</li>
              <li>Détection et réparation de fuites</li>
              <li>Débouchage de canalisations</li>
              <li>Installation de chauffe-eau</li>
              <li>Rénovation complète de plomberie</li>
              <li>Installation de systèmes d'économie d'eau</li>
            </ul>
            
            <p>
              Nous utilisons des matériaux de qualité et garantissons tous nos travaux pour votre tranquillité d'esprit.
              Nos artisans plombiers interviennent dans tout le Nord-Pas-de-Calais, la Somme, l'Aisne et l'Oise.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Pourquoi choisir nos services de plomberie dans les Hauts-de-France ?</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Intervention rapide et efficace dans toute la région</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Plombiers certifiés RGE et expérimentés</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Devis gratuit et transparent</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Garantie sur tous nos travaux</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Artisans plombiers locaux connaissant bien la région</span>
              </li>
            </ul>
            
            <div className="mt-6 p-4 bg-white rounded-lg">
              <h4 className="font-semibold mb-2">Nos zones d'intervention</h4>
              <p className="text-sm">
                Lille, Roubaix, Tourcoing, Dunkerque, Valenciennes, Douai, Cambrai, Arras, Calais, 
                Boulogne-sur-Mer, Lens, Béthune, Amiens, Saint-Quentin, Beauvais, Compiègne et toutes les 
                communes des Hauts-de-France.
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
