
import { MainLayout } from "@/components/layout/MainLayout";

export function Carpentry() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Menuiserie dans les Hauts-de-France</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de menuiserie en Hauts-de-France</h2>
            <p className="mb-4">
              Nos menuisiers expérimentés réalisent tous vos projets sur mesure, de la conception à la pose,
              pour des réalisations de qualité qui s'intègrent parfaitement à votre intérieur. Nous intervenons
              dans toute la région des Hauts-de-France.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Création de meubles sur mesure</li>
              <li>Installation de cuisines et dressings</li>
              <li>Pose de parquet et terrasse en bois</li>
              <li>Fabrication et pose d'escaliers</li>
              <li>Installation de portes et fenêtres</li>
              <li>Rénovation de mobilier ancien</li>
              <li>Aménagement d'espaces intérieurs spécifiques aux habitations de la région</li>
            </ul>
            
            <p>
              Nous travaillons avec des bois sélectionnés et des matériaux de qualité pour des réalisations durables et esthétiques.
              Nos artisans menuisiers connaissent les spécificités des habitations du Nord-Pas-de-Calais et de la Picardie.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">L'expertise de nos menuisiers en Hauts-de-France</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Savoir-faire artisanal et traditionnel</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Étude personnalisée adaptée à l'architecture régionale</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Utilisation de matériaux nobles et durables</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Finitions soignées et précises</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Respect des délais et du budget</span>
              </li>
            </ul>
            
            <div className="mt-6 p-4 bg-white rounded-lg">
              <h4 className="font-semibold mb-2">Nos zones d'intervention</h4>
              <p className="text-sm">
                Nous intervenons dans l'ensemble de la région Hauts-de-France : Métropole de Lille, 
                Bassin minier, Littoral, Artois, Avesnois, Thiérache, Santerre, Baie de Somme et Valois.
                Nos menuisiers sont répartis sur tout le territoire pour garantir une intervention rapide.
              </p>
            </div>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
