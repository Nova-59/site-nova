
import { MainLayout } from "@/components/layout/MainLayout";

export function Electricity() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services d'Électricité</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations d'électricité</h2>
            <p className="mb-4">
              Notre équipe d'électriciens qualifiés intervient pour tous vos besoins en électricité, 
              de l'installation à la réparation, pour un habitat sûr et conforme.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Installation et rénovation électrique</li>
              <li>Mise aux normes de votre installation</li>
              <li>Dépannage et recherche de pannes</li>
              <li>Installation de systèmes domotiques</li>
              <li>Pose de tableaux électriques</li>
              <li>Installation de prises et interrupteurs</li>
              <li>Éclairage intérieur et extérieur</li>
            </ul>
            
            <p>
              Tous nos travaux sont réalisés dans le respect des normes électriques en vigueur pour vous garantir sécurité et fiabilité.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Pourquoi choisir nos services d'électricité ?</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Électriciens certifiés et habilités</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Respect strict des normes de sécurité</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Intervention rapide en cas d'urgence</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Devis détaillé gratuit</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Garantie sur l'ensemble de nos prestations</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
