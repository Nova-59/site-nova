
import { MainLayout } from "@/components/layout/MainLayout";

export function Couverture() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Couverture</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de couverture</h2>
            <p className="mb-4">
              Nous offrons une gamme complète de services de couverture pour assurer l'étanchéité et la durabilité de votre toiture.
              Nos artisans qualifiés mettent leur expertise à votre service pour tous vos projets, qu'il s'agisse d'une nouvelle installation ou d'une réparation.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Installation de toiture neuve</li>
              <li>Réparation de toiture endommagée</li>
              <li>Remplacement de tuiles ou d'ardoises</li>
              <li>Traitement antimousse et imperméabilisation</li>
              <li>Isolation de toiture</li>
              <li>Installation de fenêtres de toit</li>
            </ul>
            
            <p>
              Tous nos travaux sont réalisés selon les normes en vigueur et avec des matériaux de qualité pour vous garantir une toiture durable et performante.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Pourquoi choisir nos services de couverture ?</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Artisans expérimentés et qualifiés</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Matériaux de haute qualité</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Devis détaillé et transparent</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Respect des délais d'intervention</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Garantie sur nos travaux</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
