
import { MainLayout } from "@/components/layout/MainLayout";

export function Charpente() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Charpente</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de charpente</h2>
            <p className="mb-4">
              Notre équipe spécialisée dans les travaux de charpente vous propose son savoir-faire pour tous vos projets de construction ou de rénovation.
              Nous intervenons sur tous types de charpentes traditionnelles ou industrielles.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Construction de charpente traditionnelle</li>
              <li>Pose de fermettes industrielles</li>
              <li>Rénovation de charpente ancienne</li>
              <li>Traitement du bois</li>
              <li>Renforcement de structure</li>
              <li>Extension de toiture</li>
              <li>Création de lucarne ou de fenêtre de toit</li>
            </ul>
            
            <p>
              Nous utilisons des bois de qualité, traités contre les insectes et les champignons, pour vous garantir une charpente solide et durable.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">Notre expertise en charpente</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Étude personnalisée de votre projet</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Réalisation sur mesure</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Respect des normes de construction</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Charpentiers qualifiés et expérimentés</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Intervention sur tout type de bâtiment</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
