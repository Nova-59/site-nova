
import { MainLayout } from "@/components/layout/MainLayout";

export function Tiling() {
  return (
    <MainLayout>
      <div className="container mx-auto px-4 py-10">
        <h1 className="text-3xl font-bold mb-6">Services de Carrelage</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div>
            <h2 className="text-xl font-semibold mb-4">Nos prestations de carrelage</h2>
            <p className="mb-4">
              Nos carreleurs professionnels réalisent tous vos projets de pose de carrelage et de revêtement de sol
              avec précision et savoir-faire pour un résultat durable et esthétique.
            </p>
            
            <ul className="list-disc ml-6 space-y-2 mb-6">
              <li>Pose de carrelage mural et au sol</li>
              <li>Installation de faïence de salle de bain</li>
              <li>Création de douche à l'italienne</li>
              <li>Pose de mosaïque</li>
              <li>Réalisation de plans de travail</li>
              <li>Rénovation de carrelage existant</li>
              <li>Pose de pierre naturelle</li>
            </ul>
            
            <p>
              Nous vous accompagnons dans le choix des matériaux les plus adaptés à votre projet et à votre budget.
            </p>
          </div>
          
          <div className="bg-gray-100 p-6 rounded-lg">
            <h3 className="text-lg font-semibold mb-3">L'expertise de nos carreleurs</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Préparation minutieuse du support</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Pose précise et alignement parfait</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Découpes soignées et ajustées</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Finitions de qualité (joints, plinthes)</span>
              </li>
              <li className="flex items-start">
                <span className="text-nova-gold font-bold mr-2">✓</span>
                <span>Solutions sur mesure pour chaque espace</span>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
