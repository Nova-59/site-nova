
import { MainLayout } from "@/components/layout/MainLayout";
import { ContactForm } from "@/components/contact/ContactForm";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export function Contact() {
  return (
    <MainLayout>
      <div className="container py-12 px-4 md:px-6">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold">Contactez-nous</h1>
          <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
            Notre équipe est disponible pour répondre à toutes vos questions concernant notre service de mise en relation entre propriétaires et artisans.
          </p>
        </div>

        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3 mb-12">
          <Card className="shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Phone className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium text-lg mb-2">Par téléphone</h3>
              <p className="text-muted-foreground mb-2">Lundi au vendredi, 8h-18h</p>
              <a 
                href="tel:+33638443242" 
                className="text-primary hover:underline font-medium"
              >
                06 38 44 32 42
              </a>
            </CardContent>
          </Card>

          <Card className="shadow-md hover:shadow-lg transition-shadow">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Mail className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium text-lg mb-2">Par email</h3>
              <p className="text-muted-foreground mb-2">Réponse sous 24h ouvrées</p>
              <a 
                href="mailto:direction@nova-aps.com" 
                className="text-primary hover:underline font-medium"
              >
                direction@nova-aps.com
              </a>
            </CardContent>
          </Card>

          <Card className="shadow-md hover:shadow-lg transition-shadow md:col-span-2 lg:col-span-1">
            <CardContent className="p-6 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MapPin className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-medium text-lg mb-2">Nos bureaux</h3>
              <p className="text-muted-foreground mb-2">Sur rendez-vous uniquement</p>
              <address className="not-italic text-sm">
                57 rue Victor Baltard<br />
                59200 Tourcoing, France
              </address>
            </CardContent>
          </Card>
        </div>

        <div className="grid gap-10 md:grid-cols-5">
          <div className="md:col-span-2 space-y-4">
            <h2 className="text-2xl font-bold">Envoyez-nous un message</h2>
            <p className="text-muted-foreground">
              Remplissez le formulaire ci-contre et notre équipe vous répondra dans les plus brefs délais.
            </p>
            
            <Separator className="my-6" />
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <h4 className="font-medium">Heures d'ouverture</h4>
                  <p className="text-sm text-muted-foreground">
                    Lundi au vendredi : 8h - 18h<br />
                    Samedi : Fermé<br />
                    Dimanche : Fermé
                  </p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <h4 className="font-medium">Email</h4>
                  <a href="mailto:direction@nova-aps.com" className="text-sm text-primary hover:underline">
                    direction@nova-aps.com
                  </a>
                </div>
              </div>
            </div>
          </div>
          
          <div className="md:col-span-3">
            <ContactForm />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}

export default Contact;
