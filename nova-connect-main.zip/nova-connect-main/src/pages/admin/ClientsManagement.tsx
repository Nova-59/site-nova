
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { ReturnToAdminDashboard } from "@/components/admin/ReturnToAdminDashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { LoadingState } from "@/components/admin/LoadingState";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { RefreshCw } from "lucide-react";
import { useState, useEffect } from "react";
import { User } from "@/types/user";
import { useToast } from "@/hooks/use-toast";

export function ClientsManagement() {
  const { user, loading } = useAuth();
  const [clients, setClients] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const loadClients = () => {
    setIsLoading(true);
    setError(null);
    
    // Simuler un chargement de données
    setTimeout(() => {
      try {
        const mockClients: User[] = [
          {
            id: "usr_002",
            email: "jean.dupont@example.com",
            firstName: "Jean",
            lastName: "Dupont",
            role: "homeowner",
            createdAt: new Date("2023-02-15")
          },
          {
            id: "usr_005",
            email: "marie.martin@example.com",
            firstName: "Marie",
            lastName: "Martin",
            role: "homeowner",
            createdAt: new Date("2023-03-20")
          },
          {
            id: "usr_007",
            email: "pierre.durand@example.com",
            firstName: "Pierre",
            lastName: "Durand",
            role: "homeowner",
            createdAt: new Date("2023-04-10")
          }
        ];
        
        setClients(mockClients);
        setIsLoading(false);
      } catch (err) {
        setError("Une erreur est survenue lors du chargement des clients.");
        setIsLoading(false);
        toast({
          variant: "destructive",
          title: "Erreur de chargement",
          description: "Impossible de récupérer la liste des clients."
        });
      }
    }, 1200);
  };

  useEffect(() => {
    if (user?.role === "admin") {
      loadClients();
    }
  }, [user]);

  // État de chargement de l'authentification
  if (loading) {
    return (
      <MainLayoutWithNotifications>
        <LoadingState 
          message="Authentification en cours..." 
          skeleton={true}
        />
      </MainLayoutWithNotifications>
    );
  }

  // Redirection si l'utilisateur n'est pas un admin
  if (!user || user.role !== "admin") {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <div className="p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">Accès non autorisé</h2>
            <p className="text-muted-foreground">
              Vous n'avez pas les permissions nécessaires pour accéder à cette page.
            </p>
          </div>
        </div>
      </MainLayoutWithNotifications>
    );
  }

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ReturnToAdminDashboard />
        
        <Card className="mt-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Gestion des clients</CardTitle>
              <CardDescription>
                Consultez et gérez les clients inscrits sur la plateforme.
              </CardDescription>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={loadClients}
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="mr-2 h-4 w-4 animate-spin" /> Chargement...
                </>
              ) : (
                <>
                  <RefreshCw className="mr-2 h-4 w-4" /> Actualiser
                </>
              )}
            </Button>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="bg-destructive/10 text-destructive rounded-md p-4 mb-4">
                <p>{error}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={loadClients} 
                  className="mt-2"
                >
                  Réessayer
                </Button>
              </div>
            )}
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[100px]">ID</TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Date d'inscription</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  // Skeletons pendant le chargement
                  Array.from({ length: 3 }).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    </TableRow>
                  ))
                ) : clients.length > 0 ? (
                  // Liste des clients
                  clients.map((client) => (
                    <TableRow key={client.id}>
                      <TableCell className="font-medium">{client.id}</TableCell>
                      <TableCell>{client.firstName} {client.lastName}</TableCell>
                      <TableCell>{client.email}</TableCell>
                      <TableCell>{client.createdAt.toLocaleDateString()}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  // État vide
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-4">
                      Aucun client trouvé
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </MainLayoutWithNotifications>
  );
}
