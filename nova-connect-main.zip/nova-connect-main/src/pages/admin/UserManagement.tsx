
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { ReturnToAdminDashboard } from "@/components/admin/ReturnToAdminDashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useUserManagement } from "@/hooks/useUserManagement";
import { UsersTable } from "@/components/admin/UsersTable";
import { LoadingState } from "@/components/admin/LoadingState";
import { UsersPagination } from "@/components/admin/UsersPagination";
import { Button } from "@/components/ui/button";
import { UserPlus } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserRole } from "@/types/user";
import { EmptyState } from "@/components/admin/EmptyState";

export function UserManagement() {
  const { 
    user, 
    isLoading, 
    handleRoleChange, 
    paginatedUsers, 
    currentPage, 
    totalPages, 
    handlePageChange,
    users,
    handleDeleteUser,
    createUser,
    isAuthorized
  } = useUserManagement();

  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newUserEmail, setNewUserEmail] = useState("");
  const [newUserPassword, setNewUserPassword] = useState("");
  const [newUserRole, setNewUserRole] = useState<UserRole>("guest");

  const handleCreateUser = async () => {
    if (newUserEmail && newUserPassword) {
      await createUser(newUserEmail, newUserPassword, newUserRole);
      setNewUserEmail("");
      setNewUserPassword("");
      setNewUserRole("guest");
      setIsCreateDialogOpen(false);
    }
  };

  if (isLoading) {
    return (
      <MainLayoutWithNotifications>
        <LoadingState message="Chargement des utilisateurs..." />
      </MainLayoutWithNotifications>
    );
  }

  if (!user || user.role !== "admin" || !isAuthorized) {
    return null;
  }

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ReturnToAdminDashboard />
        
        <Card className="mt-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Gestion des utilisateurs</CardTitle>
              <CardDescription>
                Administrez les comptes utilisateurs et leurs rôles. {users.length} utilisateur(s) au total.
              </CardDescription>
            </div>
            <Button onClick={() => setIsCreateDialogOpen(true)} className="ml-auto">
              <UserPlus className="mr-2 h-4 w-4" />
              Nouvel utilisateur
            </Button>
          </CardHeader>
          <CardContent>
            {users.length > 0 ? (
              <>
                <UsersTable 
                  users={paginatedUsers} 
                  onRoleChange={handleRoleChange} 
                  onDeleteUser={handleDeleteUser}
                />
                <div className="mt-4 flex flex-col sm:flex-row justify-between items-center">
                  <div className="text-sm text-muted-foreground mb-2 sm:mb-0">
                    Affichage des utilisateurs {(currentPage - 1) * 5 + 1} à {Math.min(currentPage * 5, users.length)} sur {users.length}
                  </div>
                  <UsersPagination 
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                  />
                </div>
              </>
            ) : (
              <EmptyState 
                message="Aucun utilisateur trouvé" 
                action={{
                  label: "Créer un utilisateur",
                  onClick: () => setIsCreateDialogOpen(true)
                }}
              />
            )}
          </CardContent>
        </Card>
      </div>

      {/* Dialogue pour créer un nouvel utilisateur */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Créer un nouvel utilisateur</DialogTitle>
            <DialogDescription>
              Saisissez les informations pour créer un nouveau compte utilisateur.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={newUserEmail}
                onChange={(e) => setNewUserEmail(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="password" className="text-right">
                Mot de passe
              </Label>
              <Input
                id="password"
                type="password"
                value={newUserPassword}
                onChange={(e) => setNewUserPassword(e.target.value)}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="role" className="text-right">
                Rôle
              </Label>
              <Select
                value={newUserRole}
                onValueChange={(value) => setNewUserRole(value as UserRole)}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Sélectionner un rôle" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="guest">Invité</SelectItem>
                  <SelectItem value="homeowner">Particulier</SelectItem>
                  <SelectItem value="craftsman">Artisan</SelectItem>
                  <SelectItem value="estimator">Métreur</SelectItem>
                  <SelectItem value="admin">Admin</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Annuler
            </Button>
            <Button onClick={handleCreateUser}>
              Créer l'utilisateur
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayoutWithNotifications>
  );
}
