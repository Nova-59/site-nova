
import { useState, useEffect } from "react";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { ReturnToAdminDashboard } from "@/components/admin/ReturnToAdminDashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/admin/EmptyState";
import { useAuth } from "@/contexts/AuthContext";
import { LoadingState } from "@/components/admin/LoadingState";
import { ProjectList } from "@/components/admin/ProjectList";
import { RefreshCw, PlusCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export function ProjectsManagement() {
  const { user, loading } = useAuth();
  const [isDataLoading, setIsDataLoading] = useState(true);
  const [hasProjects, setHasProjects] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  // Simuler le chargement des données
  useEffect(() => {
    if (!loading && user?.role === "admin") {
      setError(null);
      // Simuler un délai de chargement des données et une décision aléatoire d'avoir des projets ou non
      const timer = setTimeout(() => {
        try {
          // Dans un vrai cas, ceci serait une requête API
          setHasProjects(Math.random() > 0.3); // 70% de chance d'avoir des projets pour la démo
          setIsDataLoading(false);
        } catch (err) {
          setError("Impossible de charger les projets. Veuillez réessayer.");
          setIsDataLoading(false);
          toast({
            variant: "destructive",
            title: "Erreur",
            description: "Une erreur est survenue lors du chargement des projets."
          });
        }
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [loading, user, toast]);

  const handleRefresh = () => {
    setIsDataLoading(true);
    setError(null);
    
    // Simuler un rechargement
    setTimeout(() => {
      try {
        setHasProjects(Math.random() > 0.3);
        setIsDataLoading(false);
        toast({
          title: "Liste actualisée",
          description: "La liste des projets a été mise à jour."
        });
      } catch (err) {
        setError("Impossible de charger les projets. Veuillez réessayer.");
        setIsDataLoading(false);
        toast({
          variant: "destructive",
          title: "Erreur",
          description: "Une erreur est survenue lors du chargement des projets."
        });
      }
    }, 1000);
  };

  // État de chargement de l'authentification
  if (loading) {
    return (
      <MainLayoutWithNotifications>
        <LoadingState 
          message="Authentification en cours..." 
          skeleton={true}
        />
      </MainLayoutWithNotifications>
    );
  }

  // Redirection si l'utilisateur n'est pas un admin
  if (!user || user.role !== "admin") {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <div className="p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">Accès non autorisé</h2>
            <p className="text-muted-foreground">
              Vous n'avez pas les permissions nécessaires pour accéder à cette page.
            </p>
          </div>
        </div>
      </MainLayoutWithNotifications>
    );
  }

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ReturnToAdminDashboard />
        
        <Card className="mt-4">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Gestion des projets</CardTitle>
              <CardDescription>
                Consultez et gérez les projets soumis sur la plateforme.
              </CardDescription>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefresh}
                disabled={isDataLoading}
              >
                {isDataLoading ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  <RefreshCw className="h-4 w-4" />
                )}
                <span className="ml-2">Actualiser</span>
              </Button>
              <Button
                size="sm"
                onClick={() => navigate("/projects/submit")}
              >
                <PlusCircle className="h-4 w-4 mr-2" />
                Nouveau projet
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {error && (
              <div className="bg-destructive/10 text-destructive rounded-md p-4 mb-4">
                <p>{error}</p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleRefresh} 
                  className="mt-2"
                >
                  Réessayer
                </Button>
              </div>
            )}
            
            {isDataLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Skeleton className="h-5 w-40" />
                          <Skeleton className="h-5 w-20" />
                        </div>
                        <Skeleton className="h-4 w-60" />
                      </div>
                      <div className="flex gap-2">
                        <Skeleton className="h-9 w-20" />
                        <Skeleton className="h-9 w-20" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : hasProjects ? (
              <ProjectList />
            ) : (
              <EmptyState 
                message="Aucun projet n'a été soumis pour le moment."
                action={{
                  label: "Créer un projet",
                  onClick: () => navigate("/projects/submit")
                }}
              />
            )}
          </CardContent>
        </Card>
      </div>
    </MainLayoutWithNotifications>
  );
}

// Composant Skeleton pour la démonstration
function Skeleton({ className }: { className: string }) {
  return <div className={`animate-pulse bg-muted rounded ${className}`} />;
}
