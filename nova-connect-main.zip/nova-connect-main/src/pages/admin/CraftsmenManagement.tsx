
import { useState, useEffect } from "react";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { ReturnToAdminDashboard } from "@/components/admin/ReturnToAdminDashboard";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { LoadingState } from "@/components/admin/LoadingState";
import { CraftsmanList } from "@/components/admin/CraftsmanList";

export function CraftsmenManagement() {
  const { user, loading } = useAuth();
  const [isDataLoading, setIsDataLoading] = useState(true);

  // Simuler le chargement des données
  useEffect(() => {
    if (!loading && user?.role === "admin") {
      // Simuler un délai de chargement des données
      const timer = setTimeout(() => {
        setIsDataLoading(false);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, [loading, user]);

  // Afficher l'état de chargement si l'authentification est en cours
  if (loading) {
    return (
      <MainLayoutWithNotifications>
        <LoadingState 
          message="Authentification en cours..." 
          skeleton={true}
        />
      </MainLayoutWithNotifications>
    );
  }

  // Rediriger si l'utilisateur n'est pas un admin
  if (!user || user.role !== "admin") {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <div className="p-8 text-center">
            <h2 className="text-xl font-semibold mb-2">Accès non autorisé</h2>
            <p className="text-muted-foreground">
              Vous n'avez pas les permissions nécessaires pour accéder à cette page.
            </p>
          </div>
        </div>
      </MainLayoutWithNotifications>
    );
  }

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ReturnToAdminDashboard />
        
        <Card className="mt-4">
          <CardHeader>
            <CardTitle>Gestion des artisans</CardTitle>
            <CardDescription>
              Consultez et gérez les artisans inscrits sur la plateforme.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <CraftsmanList isLoading={isDataLoading} />
          </CardContent>
        </Card>
      </div>
    </MainLayoutWithNotifications>
  );
}
