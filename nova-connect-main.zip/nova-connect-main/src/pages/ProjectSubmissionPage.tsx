
import { ProjectSubmissionForm } from "@/components/projects/ProjectSubmissionForm";
import { Card, CardContent } from "@/components/ui/card";
import { Steps, Step } from "@/components/ui/steps";
import { MainLayout } from "@/components/layout/MainLayout";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";
import { SupabaseErrorHandler } from "@/components/ui/SupabaseErrorHandler";

export function ProjectSubmissionPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  // Redirect non-homeowners
  useEffect(() => {
    if (user) {
      console.log("ProjectSubmissionPage: User authenticated", user.id, user.email, user.role);
      
      // Consider both homeowner and guest roles as valid (guest will be converted to homeowner in ProtectedRoute)
      const validRoles = ["homeowner", "guest", "admin"];
      
      if (!validRoles.includes(user.role)) {
        console.log("User role not allowed:", user.role);
        toast({
          variant: "destructive",
          title: "Accès non autorisé",
          description: "Seuls les particuliers peuvent soumettre des projets."
        });
        navigate("/dashboard");
      }
    }
  }, [user, navigate, toast]);

  // If user is not logged in, redirect to auth page
  useEffect(() => {
    if (!user) {
      console.log("ProjectSubmissionPage: No authenticated user");
      toast({
        variant: "destructive",
        title: "Connexion requise",
        description: "Vous devez être connecté pour soumettre un projet."
      });
      // Remember the current page to redirect back after login
      navigate("/auth", { state: { from: "/projects/submit" } });
    }
  }, [user, navigate, toast]);

  return (
    <ProtectedRoute roles={["homeowner", "admin", "guest"]}>
      <MainLayout>
        <SupabaseErrorHandler tableName="projects" requireAuth={true}>
          <div className="container max-w-4xl py-10 px-4 md:px-6">
            <h1 className="text-3xl font-bold mb-6 text-center">Soumettre un nouveau projet</h1>
            
            <div className="mb-10">
              <Steps active={1}>
                <Step title="Description du projet" description="Détaillez votre projet" />
                <Step title="Visite du métreur" description="Évaluation sur place" />
                <Step title="Validation et paiement" description="Paiement des travaux" />
                <Step title="Publication" description="Prise en charge par un artisan" />
              </Steps>
            </div>
            
            <div className="space-y-8">
              <ProjectSubmissionForm />
              
              <Card>
                <CardContent className="p-6">
                  <h3 className="text-lg font-medium mb-4">Comment ça fonctionne ?</h3>
                  <ol className="space-y-4 list-decimal list-inside text-muted-foreground">
                    <li><span className="font-medium text-foreground">Soumettez votre projet</span> - Décrivez en détail vos besoins et ajoutez des photos</li>
                    <li><span className="font-medium text-foreground">Un métreur vous contacte</span> - Il planifiera une visite à votre domicile pour évaluer précisément les travaux</li>
                    <li><span className="font-medium text-foreground">Validation du devis</span> - Après la visite, vous recevrez un devis détaillé</li>
                    <li><span className="font-medium text-foreground">Paiement</span> - Vous payez l'intégralité du montant des travaux, que Nova Connect conserve en sécurité</li>
                    <li><span className="font-medium text-foreground">Publication</span> - Votre projet est mis en ligne pour que les artisans puissent le consulter</li>
                    <li><span className="font-medium text-foreground">Prise en charge par un artisan</span> - Un artisan qualifié choisit de prendre en charge votre projet</li>
                    <li><span className="font-medium text-foreground">Suivi et réception</span> - Notre métreur assiste à la réception des travaux pour confirmer leur conformité</li>
                    <li><span className="font-medium text-foreground">Paiement de l'artisan</span> - Nova Connect verse le paiement à l'artisan une fois les travaux validés</li>
                  </ol>
                </CardContent>
              </Card>
            </div>
          </div>
        </SupabaseErrorHandler>
      </MainLayout>
    </ProtectedRoute>
  );
}
