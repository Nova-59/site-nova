
import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BenefitList } from "@/components/how-it-works/BenefitList";

const clientFaqs = [
  {
    question: "Comment fonctionne le processus de dépôt de projet ?",
    answer: "Vous décrivez votre projet en détail sur notre plateforme, en ajoutant des photos si possible. Un métreur se déplacera ensuite chez vous pour évaluer précisément les travaux et établir un devis. Après validation du devis, votre projet sera publié sur notre marketplace pour les artisans."
  },
  {
    question: "Quels sont les frais de mise en service ?",
    answer: "Les frais de mise en service sont proportionnels à l'ampleur de votre projet. Ils couvrent le déplacement du métreur, l'établissement du devis détaillé et la publication de votre projet sur notre marketplace. Vous ne payez ces frais qu'après avoir reçu et validé le devis."
  },
  {
    question: "Comment choisir l'artisan qui réalisera mes travaux ?",
    answer: "Une fois votre projet publié, les artisans qualifiés et intéressés pourront vous contacter. Vous pourrez consulter leurs profils, leurs évaluations et leurs offres avant de faire votre choix. Notre équipe est également disponible pour vous conseiller dans cette sélection."
  },
  {
    question: "Que se passe-t-il si je ne suis pas satisfait du travail de l'artisan ?",
    answer: "Tous nos artisans sont rigoureusement sélectionnés et nous garantissons leur travail. En cas de problème, contactez-nous immédiatement et nous trouverons une solution adaptée à votre situation."
  }
];

const artisanFaqs = [
  {
    question: "Comment accéder aux détails complets d'un projet ?",
    answer: "Pour accéder aux détails complets d'un projet, vous devez acquérir un accès premium à ce projet spécifique. Ce système garantit que seuls les professionnels sérieusement intéressés accèdent aux informations complètes."
  },
  {
    question: "Quel est le coût d'accès aux détails d'un projet ?",
    answer: "Le coût d'accès représente 12% du montant estimé du chantier. Ce montant est déductible de la commission finale si vous êtes sélectionné pour réaliser les travaux."
  },
  {
    question: "Comment être sûr que les projets sont sérieux ?",
    answer: "Tous les projets sur notre plateforme ont été vérifiés sur place par nos métreurs. Ils disposent de devis précis et les clients ont déjà payé des frais de mise en service, ce qui garantit leur engagement réel dans le processus."
  },
  {
    question: "Comment fonctionne le processus de négociation avec le client ?",
    answer: "Après avoir accédé aux détails complets d'un projet, vous pouvez contacter directement le client pour discuter des spécificités du chantier et proposer votre offre. Notre plateforme facilite cette communication tout en vous laissant une autonomie totale dans la négociation."
  }
];

const benefitsClients = [
  {
    title: "Devis précis et réaliste",
    description: "Établi par un expert indépendant",
    details: "Contrairement aux plateformes traditionnelles où les devis peuvent varier considérablement, nos métreurs établissent une évaluation objective et précise qui protège vos intérêts."
  },
  {
    title: "Artisans pré-qualifiés",
    description: "Uniquement des professionnels vérifiés",
    details: "Tous nos artisans sont soigneusement sélectionnés pour leurs compétences, leur expérience et leur fiabilité. Nous vérifions leurs assurances et leurs certifications professionnelles."
  },
  {
    title: "Suivi personnalisé",
    description: "Un accompagnement à chaque étape",
    details: "Notre équipe vous accompagne tout au long du processus, depuis la définition de votre projet jusqu'à sa réalisation complète par l'artisan sélectionné."
  }
];

const benefitsArtisans = [
  {
    title: "Projets vérifiés",
    description: "Uniquement des clients sérieux",
    details: "Tous les projets ont été vérifiés sur place et les clients ont déjà payé des frais de mise en service, vous assurant que vous ne perdez pas de temps avec des demandes non qualifiées."
  },
  {
    title: "Devis déjà établis",
    description: "Transparence totale sur les attentes",
    details: "Chaque projet dispose d'un devis détaillé établi par nos métreurs, ce qui vous donne une vision claire et objective de l'ampleur des travaux avant même de contacter le client."
  },
  {
    title: "Visibilité ciblée",
    description: "Accès à des projets correspondant à vos compétences",
    details: "Notre système vous propose uniquement les projets qui correspondent à votre domaine d'expertise, augmentant significativement vos chances de conversion."
  }
];

export function FAQ() {
  const [activeTab, setActiveTab] = useState("client");
  
  return (
    <MainLayout>
      <div className="container py-10">
        <h1 className="text-4xl font-bold text-center mb-10">Foire Aux Questions</h1>
        
        <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-4xl mx-auto">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="client">Pour les propriétaires</TabsTrigger>
            <TabsTrigger value="artisan">Pour les artisans</TabsTrigger>
          </TabsList>
          
          <TabsContent value="client" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Questions fréquentes</CardTitle>
                <CardDescription>Tout ce que vous devez savoir sur notre service pour les propriétaires</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {clientFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger>{faq.question}</AccordionTrigger>
                      <AccordionContent>{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Avantages de notre service</CardTitle>
                <CardDescription>Pourquoi choisir notre plateforme pour vos projets de rénovation</CardDescription>
              </CardHeader>
              <CardContent>
                <BenefitList items={benefitsClients} />
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="artisan" className="space-y-6 mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Questions fréquentes</CardTitle>
                <CardDescription>Tout ce que vous devez savoir sur notre service pour les artisans</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  {artisanFaqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger>{faq.question}</AccordionTrigger>
                      <AccordionContent>{faq.answer}</AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Avantages de notre service</CardTitle>
                <CardDescription>Pourquoi choisir notre plateforme pour développer votre activité</CardDescription>
              </CardHeader>
              <CardContent>
                <BenefitList items={benefitsArtisans} />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}

export default FAQ;
