
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MainLayout } from '@/components/layout/MainLayout';
import { Button } from '@/components/ui/button';
import { ArrowRight, Hammer, ShieldCheck, MessageSquare, MapPin } from 'lucide-react';
import { t } from '@/lib/i18n';

const Index = () => {
  const navigate = useNavigate();
  
  return (
    <MainLayout>
      <main className="flex-1">
        {/* Hero Section - Changed to white background */}
        <section 
          className="py-20 text-black relative overflow-hidden bg-white"
        >
          <div className="container mx-auto px-4 text-center relative z-10">
            {/* Logo mis à jour */}
            <div className="mb-8 flex justify-center">
              <img 
                src="/lovable-uploads/fac78569-0689-40f5-b7c1-75a36351a493.png" 
                alt="NOVA CONNECT" 
                className="h-60 md:h-80"
              />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6 text-black">Trouvez des artisans qualifiés dans les Hauts-de-France</h1>
            <p className="text-xl mb-8 max-w-3xl mx-auto text-black/80">
              Connectez-vous avec les meilleurs artisans de la région pour vos projets de rénovation à Lille, Amiens, Arras, et partout en Hauts-de-France
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button 
                size="lg" 
                onClick={() => navigate("/auth")}
                className="bg-black text-nova-yellow hover:bg-black/90"
              >
                Soumettre un projet
              </Button>
              <Button 
                variant="outline" 
                size="lg"
                onClick={() => navigate("/auth")}
                className="bg-transparent text-black border-black hover:bg-black/10"
              >
                Devenir artisan partenaire
              </Button>
            </div>
          </div>
        </section>
        
        {/* How It Works */}
        <section className="py-16 bg-muted/50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Comment ça marche</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                  1
                </div>
                <h3 className="font-semibold text-xl mb-2">Soumettez votre demande</h3>
                <p>Décrivez votre projet de rénovation ou réparation dans les Hauts-de-France et obtenez des devis gratuits.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                  2
                </div>
                <h3 className="font-semibold text-xl mb-2">Vérification professionnelle</h3>
                <p>Nos experts évaluent votre projet et vous mettent en relation avec des artisans locaux certifiés.</p>
              </div>
              
              <div className="bg-white p-6 rounded-lg shadow-md">
                <div className="bg-nova-yellow w-12 h-12 rounded-full flex items-center justify-center text-black mb-4">
                  3
                </div>
                <h3 className="font-semibold text-xl mb-2">Connectez avec des artisans</h3>
                <p>Comparez les profils, échangez avec les artisans régionaux et choisissez celui qui vous convient.</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Hauts-de-France Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-6">Votre partenaire de confiance dans les Hauts-de-France</h2>
            <p className="text-center mb-12 max-w-3xl mx-auto">
              Nova Connect vous met en relation avec des artisans qualifiés dans toute la région Hauts-de-France. De Lille à Amiens, d'Arras à Beauvais, nos artisans sont prêts à intervenir rapidement pour tous vos projets.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="flex items-start mb-3">
                  <MapPin className="h-5 w-5 text-nova-yellow mr-2 mt-1" />
                  <h3 className="font-semibold">Nord (59)</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Lille, Roubaix, Tourcoing, Dunkerque, Valenciennes, Douai, Cambrai
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="flex items-start mb-3">
                  <MapPin className="h-5 w-5 text-nova-yellow mr-2 mt-1" />
                  <h3 className="font-semibold">Pas-de-Calais (62)</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Arras, Calais, Boulogne-sur-Mer, Lens, Béthune, Saint-Omer, Montreuil
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="flex items-start mb-3">
                  <MapPin className="h-5 w-5 text-nova-yellow mr-2 mt-1" />
                  <h3 className="font-semibold">Somme (80)</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Amiens, Abbeville, Péronne, Albert, Doullens, Montdidier
                </p>
              </div>
              
              <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
                <div className="flex items-start mb-3">
                  <MapPin className="h-5 w-5 text-nova-yellow mr-2 mt-1" />
                  <h3 className="font-semibold">Aisne (02) et Oise (60)</h3>
                </div>
                <p className="text-sm text-gray-600">
                  Saint-Quentin, Soissons, Laon, Beauvais, Compiègne, Creil, Senlis
                </p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Features */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Pourquoi choisir Nova Connect</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <ShieldCheck className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Artisans vérifiés</h3>
                <p className="text-muted-foreground">Tous nos artisans dans les Hauts-de-France sont certifiés et leurs compétences validées</p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <Hammer className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Projets pré-vérifiés</h3>
                <p className="text-muted-foreground">Nous analysons votre projet pour garantir des devis précis et adaptés à vos besoins</p>
              </div>
              
              <div className="flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-nova-yellow/10 rounded-full flex items-center justify-center mb-4">
                  <MessageSquare className="h-8 w-8 text-nova-yellow" />
                </div>
                <h3 className="text-xl font-semibold mb-2">Communication sécurisée</h3>
                <p className="text-muted-foreground">Échangez facilement avec des artisans locaux dans un environnement sécurisé</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Services Section */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl font-bold text-center mb-12">Nos services dans les Hauts-de-France</h2>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <a href="/services/couverture" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Couverture & Toiture</h3>
                <p className="text-sm text-gray-600">Réparation et installation de toiture, traitement de l'étanchéité</p>
              </a>
              
              <a href="/services/plumbing" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Plomberie</h3>
                <p className="text-sm text-gray-600">Installation, réparation de canalisations, chauffage, sanitaires</p>
              </a>
              
              <a href="/services/electricity" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Électricité</h3>
                <p className="text-sm text-gray-600">Installation électrique, mise aux normes, dépannage</p>
              </a>
              
              <a href="/services/carpentry" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Menuiserie</h3>
                <p className="text-sm text-gray-600">Création sur mesure, pose de fenêtres, portes, aménagements</p>
              </a>
              
              <a href="/services/painting" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Peinture</h3>
                <p className="text-sm text-gray-600">Peinture intérieure et extérieure, revêtements muraux</p>
              </a>
              
              <a href="/services/gardening" className="block p-6 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <h3 className="font-semibold text-lg mb-2">Jardinage</h3>
                <p className="text-sm text-gray-600">Entretien d'espaces verts, aménagement paysager</p>
              </a>
            </div>
          </div>
        </section>
        
        {/* CTA - Removed background image */}
        <section 
          className="py-16 text-black relative bg-nova-yellow"
        >
          <div className="container mx-auto px-4 text-center relative z-10">
            <h2 className="text-3xl font-bold mb-6">Prêt à transformer votre maison dans les Hauts-de-France ?</h2>
            <p className="text-xl mb-8 max-w-2xl mx-auto">Rejoignez des milliers de propriétaires et trouvez l'artisan idéal pour votre projet.</p>
            <Button 
              size="lg" 
              onClick={() => navigate("/auth")}
              className="bg-black text-nova-yellow hover:bg-black/90"
            >
              Commencer maintenant <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
        </section>
      </main>
    </MainLayout>
  );
};

export default Index;
