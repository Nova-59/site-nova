
import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProjectCard } from "@/components/projects/ProjectCard";
import { ProjectCategory } from "@/types/project";
import { mockProjects } from "@/lib/mock-projects";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { ShoppingBag, FileCheck, HandCoins, Clock, CheckCheck, HelpCircle } from "lucide-react";

export function ProjectMarketplace() {
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<ProjectCategory | "all">("all");
  const [sortBy, setSortBy] = useState<"recent" | "budget-high" | "budget-low">("recent");
  const [activeTab, setActiveTab] = useState("marketplace");
  const { user } = useAuth();
  const navigate = useNavigate();
  
  // Redirect homeowners to artisan directory
  if (user?.role === "homeowner") {
    navigate("/artisans");
    return null;
  }
  
  // Filter and sort projects based on search, category, and sort criteria
  const filteredProjects = mockProjects
    .filter(project => 
      project.isPublished && 
      project.status === "verified" &&
      (categoryFilter === "all" || project.category === categoryFilter) &&
      (project.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
       project.shortDescription.toLowerCase().includes(searchTerm.toLowerCase()))
    )
    .sort((a, b) => {
      if (sortBy === "recent") {
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      } else if (sortBy === "budget-high") {
        return b.budget.max - a.budget.max;
      } else { // budget-low
        return a.budget.min - b.budget.min;
      }
    });

  const categories: { value: ProjectCategory | "all", label: string }[] = [
    { value: "all", label: "Toutes catégories" },
    { value: "plumbing", label: "Plomberie" },
    { value: "electrical", label: "Électricité" },
    { value: "carpentry", label: "Menuiserie" },
    { value: "painting", label: "Peinture" },
    { value: "flooring", label: "Revêtement de sol" },
    { value: "roofing", label: "Toiture" },
    { value: "masonry", label: "Maçonnerie" },
    { value: "landscaping", label: "Aménagement extérieur" },
    { value: "renovation", label: "Rénovation complète" },
    { value: "other", label: "Autre" }
  ];

  return (
    <MainLayout>
      <div className="container py-8">
        <div className="flex flex-col space-y-3 md:flex-row md:justify-between md:space-y-0 mb-6">
          <div>
            <h1 className="text-3xl font-bold">Espace Artisan</h1>
            <p className="text-muted-foreground">
              Gérez vos projets et trouvez de nouvelles opportunités
            </p>
          </div>
          <Button onClick={() => navigate("/dashboard")}>
            Retour au tableau de bord
          </Button>
        </div>

        <Tabs 
          defaultValue="marketplace" 
          value={activeTab} 
          onValueChange={setActiveTab} 
          className="space-y-6"
        >
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="marketplace">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Marketplace
            </TabsTrigger>
            <TabsTrigger value="conditions">
              <FileCheck className="mr-2 h-4 w-4" />
              Conditions
            </TabsTrigger>
            <TabsTrigger value="info">
              <HelpCircle className="mr-2 h-4 w-4" />
              Comment ça marche
            </TabsTrigger>
          </TabsList>

          <TabsContent value="marketplace">
            {/* Filters */}
            <Card className="mb-8">
              <CardContent className="p-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Rechercher
                    </label>
                    <Input
                      placeholder="Rechercher un projet..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Catégorie
                    </label>
                    <Select value={categoryFilter} onValueChange={(value) => setCategoryFilter(value as ProjectCategory | "all")}>
                      <SelectTrigger>
                        <SelectValue placeholder="Catégorie" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.value} value={category.value}>
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Trier par
                    </label>
                    <Select value={sortBy} onValueChange={(value) => setSortBy(value as "recent" | "budget-high" | "budget-low")}>
                      <SelectTrigger>
                        <SelectValue placeholder="Trier par" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="recent">Plus récents</SelectItem>
                        <SelectItem value="budget-high">Budget (décroissant)</SelectItem>
                        <SelectItem value="budget-low">Budget (croissant)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Results */}
            <div className="mb-4 flex justify-between items-center">
              <p className="text-sm text-muted-foreground">
                {filteredProjects.length} projet{filteredProjects.length !== 1 ? 's' : ''} trouvé{filteredProjects.length !== 1 ? 's' : ''}
              </p>
              <Badge variant="outline" className="rounded-full px-3 py-1">
                Projets vérifiés ✓
              </Badge>
            </div>

            {filteredProjects.length > 0 ? (
              <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {filteredProjects.map((project) => (
                  <ProjectCard key={project.id} project={project} />
                ))}
              </div>
            ) : (
              <Card className="p-8 text-center">
                <h3 className="text-lg font-medium mb-2">Aucun projet trouvé</h3>
                <p className="text-muted-foreground mb-4">
                  Essayez de modifier vos critères de recherche ou revenez plus tard.
                </p>
                <Button variant="outline" onClick={() => {
                  setSearchTerm("");
                  setCategoryFilter("all");
                }}>
                  Réinitialiser les filtres
                </Button>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="conditions">
            <Card>
              <CardHeader>
                <CardTitle>Conditions et paiements</CardTitle>
                <CardDescription>
                  Tout ce que vous devez savoir sur la collaboration avec Nova Connect
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <HandCoins className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Modèle de paiement sécurisé</h3>
                    <p className="text-muted-foreground text-sm">
                      Nova Connect sécurise les paiements des clients avant le début des travaux. 
                      Une fois les travaux terminés et validés par notre équipe, vous recevez votre paiement 
                      directement sur votre compte bancaire sous 7 jours.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Échéancier de paiement</h3>
                    <p className="text-muted-foreground text-sm">
                      Pour les projets importants, les paiements peuvent être échelonnés selon des jalons prédéfinis.
                      Chaque jalon est validé par notre équipe avant le déclenchement du paiement correspondant.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <CheckCheck className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Critères de qualité</h3>
                    <p className="text-muted-foreground text-sm">
                      Tous les travaux sont vérifiés par nos métreurs experts qui s'assurent 
                      de la conformité aux spécifications initiales. Cela garantit une qualité optimale 
                      pour le client et une transparence totale pour vous.
                    </p>
                  </div>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium mb-3">Documents requis</h3>
                  <ul className="space-y-2">
                    <li className="flex items-start gap-2">
                      <Badge className="mt-0.5">Obligatoire</Badge>
                      <span>Attestation d'assurance professionnelle</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Badge className="mt-0.5">Obligatoire</Badge>
                      <span>RIB pour les paiements</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">Recommandé</Badge>
                      <span>Photos de réalisations précédentes</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <Badge variant="outline" className="mt-0.5">Recommandé</Badge>
                      <span>Témoignages clients</span>
                    </li>
                  </ul>
                </div>
                
                <Separator />
                
                <div>
                  <h3 className="font-medium mb-3">Commissions et frais</h3>
                  <p className="text-muted-foreground text-sm mb-4">
                    Nova Connect prélève une commission de 15% sur le montant total du projet.
                    Cette commission couvre:
                  </p>
                  <ul className="space-y-1 text-sm">
                    <li className="flex items-center gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500" />
                      <span>La mise en relation avec des clients qualifiés</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500" />
                      <span>La sécurisation des paiements</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500" />
                      <span>Le service de métreur expert</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500" />
                      <span>L'assurance complémentaire du chantier</span>
                    </li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="info">
            <Card>
              <CardHeader>
                <CardTitle>Comment ça marche</CardTitle>
                <CardDescription>
                  Guide étape par étape pour les artisans
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div className="relative pl-8 pb-8 border-l border-border">
                    <div className="absolute left-0 top-0 -translate-x-1/2 h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">1</div>
                    <h3 className="font-medium mb-2">Parcourez les projets vérifiés</h3>
                    <p className="text-muted-foreground text-sm">
                      Dans la marketplace, vous trouverez des projets déjà vérifiés par nos métreurs experts. 
                      Tous les projets ont été validés techniquement et financièrement.
                    </p>
                  </div>
                  
                  <div className="relative pl-8 pb-8 border-l border-border">
                    <div className="absolute left-0 top-0 -translate-x-1/2 h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">2</div>
                    <h3 className="font-medium mb-2">Prenez en charge un projet</h3>
                    <p className="text-muted-foreground text-sm">
                      Lorsque vous trouvez un projet qui correspond à vos compétences et disponibilités, 
                      vous pouvez le prendre en charge en quelques clics. Le client est immédiatement notifié.
                    </p>
                  </div>
                  
                  <div className="relative pl-8 pb-8 border-l border-border">
                    <div className="absolute left-0 top-0 -translate-x-1/2 h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">3</div>
                    <h3 className="font-medium mb-2">Réalisez les travaux</h3>
                    <p className="text-muted-foreground text-sm">
                      Suivez les spécifications techniques fournies par notre métreur. 
                      Vous pouvez communiquer avec le client via notre plateforme et mettre à jour 
                      l'avancement du projet régulièrement.
                    </p>
                  </div>
                  
                  <div className="relative pl-8">
                    <div className="absolute left-0 top-0 -translate-x-1/2 h-6 w-6 rounded-full bg-primary flex items-center justify-center text-white">4</div>
                    <h3 className="font-medium mb-2">Recevez votre paiement</h3>
                    <p className="text-muted-foreground text-sm">
                      Une fois les travaux terminés et validés par notre équipe, vous recevez 
                      votre paiement directement sur votre compte bancaire sous 7 jours.
                    </p>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-4 border-t pt-6">
                <div className="bg-muted p-4 rounded-lg w-full">
                  <h3 className="font-medium mb-2">Avantages pour les artisans</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500 mt-0.5" />
                      <span>Projets vérifiés et chiffrés par des experts</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500 mt-0.5" />
                      <span>Paiement sécurisé garanti</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500 mt-0.5" />
                      <span>Aucun coût de prospection ou de publicité</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <CheckCheck className="h-4 w-4 text-green-500 mt-0.5" />
                      <span>Support technique de nos métreurs</span>
                    </li>
                  </ul>
                </div>
                
                <Button className="w-full" onClick={() => setActiveTab("marketplace")}>
                  Voir les projets disponibles
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </MainLayout>
  );
}
