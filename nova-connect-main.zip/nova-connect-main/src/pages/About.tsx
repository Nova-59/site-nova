
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { AboutSection } from "@/components/about/AboutSection";
import { ValuesList } from "@/components/about/ValuesList";
import { MainLayout } from "@/components/layout/MainLayout";

// Company values data
const companyValues = [
  {
    name: "Qualité",
    description: "Nous ne faisons aucun compromis sur la qualité des artisans qui rejoignent notre plateforme."
  },
  {
    name: "Transparence",
    description: "Nous croyons en une communication claire et des prix justes."
  },
  {
    name: "Innovation",
    description: "Nous utilisons la technologie pour améliorer chaque aspect du processus de rénovation."
  },
  {
    name: "Communauté",
    description: "Nous construisons une communauté forte d'artisans et de propriétaires satisfaits."
  }
];

export function About() {
  return (
    <MainLayout>
      <div className="container mx-auto py-12 px-4 max-w-5xl">
        <h1 className="text-4xl font-bold text-center mb-8">À propos de NOVA Connect</h1>
        
        <AboutSection title="Notre mission">
          <p className="text-gray-700 mb-4">
            NOVA Connect est né d'une vision simple mais puissante : connecter les propriétaires avec les meilleurs artisans qualifiés 
            dans les Hauts-de-France, tout en rendant le processus de rénovation transparent, efficace et sans stress.
          </p>
          <p className="text-gray-700 mb-4">
            Nous croyons que chaque projet mérite la meilleure expertise, et chaque artisan mérite d'être mis en relation 
            avec des clients qui valorisent leur savoir-faire.
          </p>
        </AboutSection>
        
        <AboutSection title="Notre histoire">
          <p className="text-gray-700 mb-4">
            Fondée par une équipe passionnée par l'innovation dans le secteur du bâtiment, NOVA Connect a identifié un besoin 
            crucial sur le marché : créer un pont entre l'expertise traditionnelle des artisans et les attentes modernes des propriétaires.
          </p>
          <p className="text-gray-700 mb-4">
            Après plusieurs années à développer notre plateforme en étroite collaboration avec des artisans et des propriétaires, 
            nous sommes fiers de proposer une solution qui répond aux besoins réels du marché.
          </p>
        </AboutSection>
        
        <AboutSection title="Nos valeurs">
          <ValuesList values={companyValues} />
        </AboutSection>
        
        <div className="text-center mt-8">
          <Button asChild size="lg">
            <Link to="/contact">Contactez-nous</Link>
          </Button>
        </div>
      </div>
    </MainLayout>
  );
}
