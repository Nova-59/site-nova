
import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { AvailabilityCalendar } from "@/components/scheduling/AvailabilityCalendar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { Info, Check, Calendar } from "lucide-react";
import { User } from "@/types/user";
import { Project, ProjectStatus, ProjectCategory } from "@/types/project";

// Définition des données de test pour résoudre le problème d'écran blanc
const MOCK_PROJECTS: Project[] = [
  {
    id: "1",
    title: "Rénovation de salle de bain",
    description: "Rénovation complète d'une salle de bain de 5m²",
    shortDescription: "Rénovation salle de bain 5m²",
    category: "plumbing" as ProjectCategory,
    ownerId: "user1",
    status: "assigned" as ProjectStatus,
    location: {
      city: "Paris",
      postalCode: "75011",
      region: "Île-de-France"
    },
    budget: {
      min: 4000,
      max: 5000,
      currency: "EUR"
    },
    images: [
      {
        id: "img1",
        url: "/placeholder.svg",
        alt: "Salle de bain"
      }
    ],
    createdAt: new Date().toISOString(),
    startDate: null,
    endDate: null,
    estimatorId: "estimator1",
    approvedById: "admin1",
    approvedAt: new Date().toISOString(),
    isPublished: true
  },
  {
    id: "2",
    title: "Installation électrique",
    description: "Mise aux normes de l'installation électrique d'un appartement",
    shortDescription: "Mise aux normes électrique",
    category: "electrical" as ProjectCategory,
    ownerId: "user2",
    status: "in_progress" as ProjectStatus,
    location: {
      city: "Lyon",
      postalCode: "69001",
      region: "Auvergne-Rhône-Alpes"
    },
    budget: {
      min: 2000,
      max: 3000,
      currency: "EUR"
    },
    images: [
      {
        id: "img2",
        url: "/placeholder.svg",
        alt: "Installation électrique"
      }
    ],
    createdAt: new Date().toISOString(),
    startDate: null,
    endDate: null,
    estimatorId: "estimator1",
    approvedById: "admin1",
    approvedAt: new Date().toISOString(),
    isPublished: true
  }
];

// Mock user pour les tests
const MOCK_CURRENT_USER: User = {
  id: "user1",
  email: "test@example.com",
  name: "Test User", // We'll keep this for display purposes
  role: "homeowner",
  avatarUrl: "/placeholder.svg", // Modifié de avatar à avatarUrl pour correspondre au type UserProfile
  createdAt: new Date(), // Ajout de createdAt pour satisfaire le type UserProfile
};

export function ProjectSchedulingPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [project, setProject] = useState<Project | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedSlot, setSelectedSlot] = useState<{ date: Date; timeSlot: string } | null>(null);
  
  // Utilisation des données de test au lieu de getCurrentUser
  const currentUser = MOCK_CURRENT_USER;
  
  // Vérifier si l'utilisateur est propriétaire du projet
  const isOwner = currentUser?.id === project?.ownerId;
  const isCraftsman = currentUser?.role === "craftsman";
  
  useEffect(() => {
    // Simuler le chargement du projet
    setIsLoading(true);
    setTimeout(() => {
      const foundProject = MOCK_PROJECTS.find(p => p.id === projectId);
      
      if (foundProject) {
        setProject(foundProject);
      } else {
        toast({
          variant: "destructive",
          title: "Projet introuvable",
          description: "Le projet que vous recherchez n'existe pas.",
        });
        navigate("/projects/marketplace");
      }
      
      setIsLoading(false);
    }, 500);
  }, [projectId, navigate, toast]);
  
  const handleSaveAvailability = (availabilities: any[]) => {
    console.log("Availabilities saved:", availabilities);
    toast({
      title: "Disponibilités enregistrées",
      description: "Vos disponibilités ont été enregistrées avec succès.",
    });
  };
  
  const handleSelectTimeSlot = (date: Date, timeSlot: string) => {
    setSelectedSlot({ date, timeSlot });
    
    toast({
      title: "Créneau sélectionné",
      description: `Vous avez sélectionné le créneau du ${date.toLocaleDateString('fr-FR')} à ${timeSlot}`,
    });
  };
  
  const handleConfirmTimeSlot = () => {
    if (!selectedSlot) return;
    
    toast({
      title: "Rendez-vous confirmé",
      description: `Le rendez-vous a été confirmé pour le ${selectedSlot.date.toLocaleDateString('fr-FR')} à ${selectedSlot.timeSlot}`,
    });
    
    // Naviguer vers la page de détail du projet après confirmation
    setTimeout(() => {
      navigate(`/projects/${projectId}`);
    }, 1500);
  };
  
  if (isLoading) {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <div className="flex items-center justify-center h-60">
            <div className="text-center">
              <p className="text-muted-foreground">Chargement du projet...</p>
            </div>
          </div>
        </div>
      </MainLayoutWithNotifications>
    );
  }
  
  if (!project) {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <Alert variant="destructive">
            <AlertTitle>Projet introuvable</AlertTitle>
            <AlertDescription>
              Le projet que vous recherchez n'existe pas ou a été supprimé.
            </AlertDescription>
          </Alert>
        </div>
      </MainLayoutWithNotifications>
    );
  }
  
  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <h1 className="text-3xl font-bold mb-2">Planification du projet</h1>
        <p className="text-muted-foreground mb-6">
          {project?.title}
        </p>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <AvailabilityCalendar 
              projectId={project?.id || ""}
              isCraftsman={isCraftsman || !isOwner} // Pour tester les deux modes
              onSaveAvailability={handleSaveAvailability}
              onSelectTimeSlot={handleSelectTimeSlot}
              existingAvailabilities={[
                { date: new Date(2024, 6, 15), timeSlots: ["09:00", "10:00", "14:00"] },
                { date: new Date(2024, 6, 16), timeSlots: ["11:00", "15:00"] }
              ]}
            />
          </div>
          
          <div className="lg:col-span-1 space-y-6">
            {/* Instructions pour les utilisateurs */}
            <Card>
              <CardHeader>
                <CardTitle>
                  {isCraftsman && !isOwner 
                    ? "Proposer vos disponibilités" 
                    : "Choisir un rendez-vous"}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isCraftsman && !isOwner ? (
                  <div className="space-y-4">
                    <Alert className="bg-muted/50">
                      <Info className="h-4 w-4" />
                      <AlertDescription>
                        Sélectionnez les dates et les créneaux horaires auxquels vous êtes 
                        disponible pour réaliser ce projet. Le client pourra choisir parmi 
                        ces disponibilités.
                      </AlertDescription>
                    </Alert>
                    
                    <ol className="space-y-2 list-decimal list-inside text-sm">
                      <li>Sélectionnez une date dans le calendrier</li>
                      <li>Cliquez sur les créneaux horaires où vous êtes disponible</li>
                      <li>Enregistrez vos disponibilités</li>
                      <li>Répétez pour chaque jour où vous êtes disponible</li>
                    </ol>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <Alert className="bg-muted/50">
                      <Info className="h-4 w-4" />
                      <AlertDescription>
                        L'artisan a proposé plusieurs créneaux de disponibilité. 
                        Choisissez celui qui vous convient le mieux pour démarrer les travaux.
                      </AlertDescription>
                    </Alert>
                    
                    <ol className="space-y-2 list-decimal list-inside text-sm">
                      <li>Sélectionnez une date marquée dans le calendrier</li>
                      <li>Choisissez un créneau horaire proposé par l'artisan</li>
                      <li>Confirmez votre choix</li>
                    </ol>
                    
                    {selectedSlot && (
                      <div className="mt-4 p-3 bg-muted rounded-md">
                        <h3 className="font-medium mb-2">Créneau sélectionné :</h3>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          <span>{selectedSlot.date.toLocaleDateString('fr-FR')} à {selectedSlot.timeSlot}</span>
                        </div>
                        <Button 
                          onClick={handleConfirmTimeSlot}
                          className="w-full mt-4"
                        >
                          <Check className="mr-2 h-4 w-4" />
                          Confirmer ce rendez-vous
                        </Button>
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayoutWithNotifications>
  );
}
