
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { MainLayout } from "@/components/layout/MainLayout";
import { CraftsmanRegisterForm } from "@/components/craftsman/CraftsmanRegisterForm";

export function CraftsmanRegister() {
  return (
    <MainLayout>
      <div className="container max-w-5xl py-10">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold mb-2">Devenir artisan partenaire</h1>
          <p className="text-muted-foreground">
            Rejoignez notre réseau d'artisans qualifiés et accédez à des projets vérifiés
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Formulaire d'inscription</CardTitle>
            <CardDescription>
              Remplissez ce formulaire pour nous rejoindre. Notre équipe examinera votre candidature
              sous 48h.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <CraftsmanRegisterForm />
          </CardContent>
        </Card>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="text-xl">Projets vérifiés</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Tous nos projets sont évalués par des métreurs experts avant d'être publiés.
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="text-xl">Clients qualifiés</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Des clients avec un budget alloué, prêts à démarrer leur projet rapidement.
              </p>
            </CardContent>
          </Card>

          <Card className="card-hover">
            <CardHeader>
              <CardTitle className="text-xl">Gain de temps</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Plus besoin de déplacements pour des devis sans suite. Concentrez-vous sur les 
                projets qui vous conviennent.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </MainLayout>
  );
}

export default CraftsmanRegister;
