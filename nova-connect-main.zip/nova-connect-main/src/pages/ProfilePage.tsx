
import { useState, useEffect } from "react";
import { Navigate } from "react-router-dom";
import { MainLayout } from "@/components/layout/MainLayout";
import { ProfileForm } from "@/components/profile/ProfileForm";
import { ProfileAvatar } from "@/components/profile/ProfileAvatar";
import { useAuth } from "@/contexts/AuthContext";
import { UserProfile, UserProfileFormValues } from "@/types/user";
import { getCurrentUserProfile, updateUserProfile, uploadAvatar } from "@/services/profileService";

export function ProfilePage() {
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  
  const { user } = useAuth();
  
  useEffect(() => {
    const loadProfile = async () => {
      if (!user) {
        setIsLoading(false);
        return;
      }
      
      try {
        const profile = getCurrentUserProfile();
        setUserProfile(profile);
      } catch (error) {
        console.error("Error loading profile:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    loadProfile();
  }, [user]);
  
  const handleSaveProfile = async (profileData: UserProfileFormValues) => {
    if (!user) return;
    
    try {
      const updatedProfile = await updateUserProfile(profileData);
      setUserProfile(updatedProfile);
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };
  
  const handleAvatarChange = async (file: File) => {
    if (!user) return;
    
    try {
      const avatarUrl = await uploadAvatar(file);
      setUserProfile(prev => prev ? { ...prev, avatarUrl } : null);
    } catch (error) {
      console.error("Error updating avatar:", error);
    }
  };
  
  // Redirect if not logged in
  if (!user && !isLoading) {
    return <Navigate to="/auth" replace />;
  }
  
  if (isLoading) {
    return (
      <MainLayout>
        <div className="container py-8">
          <div className="flex items-center justify-center h-60">
            <div className="text-center">
              <p className="text-muted-foreground">Chargement du profil...</p>
            </div>
          </div>
        </div>
      </MainLayout>
    );
  }
  
  return (
    <MainLayout>
      <div className="container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <ProfileAvatar 
              avatarUrl={userProfile?.avatarUrl} 
              onAvatarChange={handleAvatarChange}
              name={`${userProfile?.firstName || ''} ${userProfile?.lastName || ''}`.trim()}
            />
          </div>
          
          <div className="lg:col-span-3">
            <ProfileForm 
              profile={userProfile || {}}
              onSave={handleSaveProfile}
            />
          </div>
        </div>
      </div>
    </MainLayout>
  );
}
