
import { MainLayout } from "@/components/layout/MainLayout";
import { useState } from "react";
import { HomeownerSection } from "@/components/how-it-works/HomeownerSection";
import { CraftsmanSection } from "@/components/how-it-works/CraftsmanSection";
import { ContactSection } from "@/components/how-it-works/ContactSection";

export function HowItWorks() {
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  const toggleSection = (section: string) => {
    if (expandedSection === section) {
      setExpandedSection(null);
    } else {
      setExpandedSection(section);
    }
  };

  return (
    <MainLayout>
      <div className="container max-w-5xl py-10 px-4 md:px-6">
        <div className="text-center space-y-3 mb-12 animate-fade-in">
          <h1 className="text-3xl font-bold">Comment ça marche ?</h1>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            NOVA est un réseau d'artisans vérifiés qui facilite la réalisation de vos projets de rénovation
            grâce à un processus rigoureux de validation et de mise en relation.
          </p>
        </div>
        
        <div className="grid gap-10">
          <HomeownerSection 
            expandedSection={expandedSection} 
            toggleSection={toggleSection} 
          />
          
          <CraftsmanSection 
            expandedSection={expandedSection} 
            toggleSection={toggleSection} 
          />
        </div>

        <ContactSection />
      </div>
    </MainLayout>
  );
}
