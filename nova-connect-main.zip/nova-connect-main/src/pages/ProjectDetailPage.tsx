
import { useParams, useNavigate, Link } from "react-router-dom";
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { ProjectDetailsCard } from "@/components/projects/ProjectDetailsCard";
import { ProjectDetailTabs } from "@/components/projects/ProjectDetailTabs";
import { CraftsmanProjectTakeoverForm } from "@/components/projects/CraftsmanProjectTakeoverForm";
import { ProjectProgressTracking } from "@/components/projects/ProjectProgressTracking";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Calendar } from "lucide-react";
import { useProjectDetail } from "@/hooks/useProjectDetail";
import { ErrorStateHandler } from "@/components/ui/ErrorStateHandler";

export function ProjectDetailPage() {
  const { projectId } = useParams<{ projectId: string }>();
  const navigate = useNavigate();
  const { 
    project, 
    isLoading, 
    error,
    currentUser, 
    isOwner, 
    isCraftsman, 
    hasAcceptedCraftsman, 
    handleTakeProject,
    defaultTab
  } = useProjectDetail(projectId);

  if (isLoading) {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <div className="flex items-center justify-center h-60">
            <div className="text-center">
              <p className="text-muted-foreground">Chargement du projet...</p>
            </div>
          </div>
        </div>
      </MainLayoutWithNotifications>
    );
  }

  if (!project) {
    return (
      <MainLayoutWithNotifications>
        <div className="container py-8">
          <Alert variant="destructive">
            <AlertTitle>Projet introuvable</AlertTitle>
            <AlertDescription>
              Le projet que vous recherchez n'existe pas ou a été supprimé.
            </AlertDescription>
          </Alert>
        </div>
      </MainLayoutWithNotifications>
    );
  }

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ErrorStateHandler error={error} context="Détails du projet">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Project Details - Left Column */}
            <div className="lg:col-span-2">
              <ProjectDetailsCard project={project} />
              
              {/* Scheduling Button */}
              {hasAcceptedCraftsman && (isOwner || currentUser?.id === project.craftsmanId) && (
                <div className="mt-4">
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => navigate(`/projects/${project.id}/scheduling`)}
                  >
                    <Calendar className="mr-2 h-4 w-4" />
                    {project.status === "pending" 
                      ? "Planifier un rendez-vous" 
                      : "Voir le calendrier du projet"}
                  </Button>
                </div>
              )}
            </div>
            
            {/* Right Column - Take Project Form (for Craftsmen) */}
            <div className="lg:col-span-1">
              {isCraftsman && !isOwner && (
                <CraftsmanProjectTakeoverForm onTakeProject={handleTakeProject} />
              )}
              
              {/* Only show project progress for owners or assigned craftsman */}
              {(isOwner || currentUser?.id === project.craftsmanId) && (
                <div className="mt-6">
                  <ProjectProgressTracking 
                    projectId={project.id}
                    status={project.status}
                    isOwner={isOwner}
                  />
                </div>
              )}
            </div>
          </div>
          
          {/* Tabs for Additional Project Information */}
          <div className="mt-8">
            <ProjectDetailTabs 
              projectId={project.id}
              status={project.status}
              isOwner={isOwner}
              hasAcceptedCraftsman={hasAcceptedCraftsman}
              currentUserId={currentUser?.id}
              craftsmanId={project.craftsmanId}
              defaultTab={defaultTab}
            />
          </div>
        </ErrorStateHandler>
      </div>
    </MainLayoutWithNotifications>
  );
}
