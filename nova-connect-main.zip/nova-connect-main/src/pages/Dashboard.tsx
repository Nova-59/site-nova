
import { MainLayoutWithNotifications } from "@/components/layout/MainLayoutWithNotifications";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { HomeownerDashboard } from "@/components/dashboard/HomeownerDashboard";
import { CraftsmanDashboard } from "@/components/dashboard/CraftsmanDashboard";
import { DashboardHeader } from "@/components/dashboard/DashboardHeader";
import { ProjectsList } from "@/components/dashboard/ProjectsList";
import { MessagesTab } from "@/components/dashboard/MessagesTab";
import { PaymentsTab } from "@/components/dashboard/PaymentsTab";
import { useDashboard } from "@/hooks/useDashboard";
import { ErrorStateHandler } from "@/components/ui/ErrorStateHandler";

export function Dashboard() {
  const { user, loading, activeTab, handleTabChange, error } = useDashboard();

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center">Chargement...</div>;
  }

  if (!user || user.role === "guest") {
    return null;
  }

  // Construction des onglets en fonction du rôle
  const renderTabsBasedOnRole = () => {
    if (user.role === "homeowner") {
      return (
        <>
          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="projects">Mes projets</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
        </>
      );
    } else if (user.role === "craftsman") {
      return (
        <>
          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="projects">Mes chantiers</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
          <TabsTrigger value="payments">Paiements</TabsTrigger>
        </>
      );
    } else {
      // Admin ou autre rôle
      return (
        <>
          <TabsTrigger value="overview">Vue d'ensemble</TabsTrigger>
          <TabsTrigger value="projects">Projets</TabsTrigger>
          <TabsTrigger value="messages">Messages</TabsTrigger>
        </>
      );
    }
  };

  return (
    <MainLayoutWithNotifications>
      <div className="container py-8">
        <ErrorStateHandler error={error} context="Tableau de bord">
          <DashboardHeader user={user} />

          <Tabs 
            defaultValue="overview" 
            value={activeTab} 
            onValueChange={handleTabChange} 
            className="space-y-6"
          >
            <TabsList>
              {renderTabsBasedOnRole()}
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              {user.role === "homeowner" && <HomeownerDashboard />}
              {user.role === "craftsman" && <CraftsmanDashboard />}
              {user.role === "admin" && <div>Vue d'ensemble Admin</div>}
            </TabsContent>

            <TabsContent value="projects">
              <ProjectsList userRole={user.role} />
            </TabsContent>

            <TabsContent value="messages">
              <MessagesTab />
            </TabsContent>

            {user.role === "craftsman" && (
              <TabsContent value="payments">
                <PaymentsTab />
              </TabsContent>
            )}
          </Tabs>
        </ErrorStateHandler>
      </div>
    </MainLayoutWithNotifications>
  );
}
