
import { Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "@/components/ui/toaster";
import Index from "@/pages/Index";
import { HowItWorks } from "@/pages/HowItWorks";
import { ArtisanDirectory } from "@/pages/ArtisanDirectory";
import { ProjectDetailPage } from "@/pages/ProjectDetailPage";
import { ProjectSubmissionPage } from "@/pages/ProjectSubmissionPage";
import { ProjectSchedulingPage } from "@/pages/ProjectSchedulingPage";
import AdminDashboard from "@/pages/AdminDashboard";
import { Dashboard } from "@/pages/Dashboard";
import { ProfilePage } from "@/pages/ProfilePage";
import { Contact } from "@/pages/Contact";
import { FAQ } from "@/pages/FAQ";
import { About } from "@/pages/About";
import NotFound from "@/pages/NotFound";
import { CraftsmanRegister } from "@/pages/CraftsmanRegister";
import { AuthPage } from "@/components/auth/AuthPage";
import { ResetPasswordPage } from "@/components/auth/ResetPasswordPage";
import { Couverture } from "@/pages/services/Couverture";
import { Charpente } from "@/pages/services/Charpente";
import { Zinguerie } from "@/pages/services/Zinguerie";
import { Plumbing } from "@/pages/services/Plumbing";
import { Electricity } from "@/pages/services/Electricity";
import { Carpentry } from "@/pages/services/Carpentry";
import { Painting } from "@/pages/services/Painting";
import { Tiling } from "@/pages/services/Tiling";
import { Gardening } from "@/pages/services/Gardening";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { ProjectMarketplace } from "@/pages/ProjectMarketplace";
import { UserManagement } from "@/pages/admin/UserManagement";
import { CraftsmenManagement } from "@/pages/admin/CraftsmenManagement";
import { ClientsManagement } from "@/pages/admin/ClientsManagement";
import { ProjectsManagement } from "@/pages/admin/ProjectsManagement";

function App() {
  return (
    <AuthProvider>
      <Routes>
        <Route path="/" element={<Index />} />
        <Route path="/how-it-works" element={<HowItWorks />} />
        <Route path="/artisans" element={<ArtisanDirectory />} />
        <Route path="/about" element={<About />} />
        
        {/* Routes protégées pour les artisans */}
        <Route path="/projects/marketplace" element={
          <ProtectedRoute roles={["craftsman", "admin", "estimator"]}>
            <ProjectMarketplace />
          </ProtectedRoute>
        } />
        
        {/* Routes de soumission de projet pour tous les utilisateurs authentifiés, y compris les invités */}
        <Route path="/projects/submit" element={
          <ProtectedRoute>
            <ProjectSubmissionPage />
          </ProtectedRoute>
        } />
        
        {/* Ajouter l'alias "/submit-project" qui redirige vers "/projects/submit" */}
        <Route path="/submit-project" element={<Navigate to="/projects/submit" replace />} />
        
        <Route path="/projects/:projectId" element={<ProjectDetailPage />} />
        <Route path="/projects/:projectId/scheduling" element={<ProjectSchedulingPage />} />
        
        <Route path="/dashboard" element={
          <ProtectedRoute roles={["homeowner", "craftsman", "admin", "estimator"]}>
            <Dashboard />
          </ProtectedRoute>
        } />
        
        <Route path="/profile" element={
          <ProtectedRoute roles={["homeowner", "craftsman", "admin", "estimator"]}>
            <ProfilePage />
          </ProtectedRoute>
        } />
        
        <Route path="/faq" element={<FAQ />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/auth" element={<AuthPage />} />
        
        {/* Route importante: Assurer que la page de réinitialisation est directement accessible */}
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        
        <Route path="/craftsman/register" element={<CraftsmanRegister />} />
        
        {/* Admin routes */}
        <Route path="/admin" element={
          <ProtectedRoute roles={["admin"]}>
            <AdminDashboard />
          </ProtectedRoute>
        } />
        
        {/* Redirect /admin/dashboard to /admin to fix 404 error */}
        <Route path="/admin/dashboard" element={<Navigate to="/admin" replace />} />
        
        <Route path="/admin/users" element={
          <ProtectedRoute roles={["admin"]}>
            <UserManagement />
          </ProtectedRoute>
        } />
        
        {/* Routes d'administration mises à jour */}
        <Route path="/admin/craftsmen" element={
          <ProtectedRoute roles={["admin"]}>
            <CraftsmenManagement />
          </ProtectedRoute>
        } />
        
        <Route path="/admin/clients" element={
          <ProtectedRoute roles={["admin"]}>
            <ClientsManagement />
          </ProtectedRoute>
        } />
        
        <Route path="/admin/projects" element={
          <ProtectedRoute roles={["admin"]}>
            <ProjectsManagement />
          </ProtectedRoute>
        } />
        
        {/* Service routes */}
        <Route path="/services/couverture" element={<Couverture />} />
        <Route path="/services/charpente" element={<Charpente />} />
        <Route path="/services/zinguerie" element={<Zinguerie />} />
        <Route path="/services/plumbing" element={<Plumbing />} />
        <Route path="/services/electricity" element={<Electricity />} />
        <Route path="/services/carpentry" element={<Carpentry />} />
        <Route path="/services/painting" element={<Painting />} />
        <Route path="/services/tiling" element={<Tiling />} />
        <Route path="/services/gardening" element={<Gardening />} />
        
        {/* Fallback route */}
        <Route path="*" element={<NotFound />} />
      </Routes>
      <Toaster />
    </AuthProvider>
  );
}

export default App;
