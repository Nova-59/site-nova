
-- Politiques pour les projets approuvés
-- Permet aux artisans de voir uniquement les projets approuvés et publiés
CREATE POLICY "Craftsmen can only view approved and published projects" 
ON projects
FOR SELECT 
USING (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'craftsman') AND
  status = 'approved' AND
  is_published = true
);

-- Permet aux artisans de mettre à jour leurs projets assignés
CREATE POLICY "Craftsmen can update their assigned projects" 
ON projects
FOR UPDATE 
USING (
  craftsman_id = auth.uid() AND
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'craftsman')
);

-- Politiques pour les soumissions de projets
-- Permet aux artisans de voir leurs propres offres
CREATE POLICY "Craftsmen can view their own bids" 
ON project_bids
FOR SELECT 
USING (
  craftsman_id = auth.uid() OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux artisans de mettre à jour leurs propres offres
CREATE POLICY "Craftsmen can update their own bids" 
ON project_bids
FOR UPDATE 
USING (
  craftsman_id = auth.uid() OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux artisans de supprimer leurs propres offres en attente
CREATE POLICY "Craftsmen can delete their pending bids" 
ON project_bids
FOR DELETE 
USING (
  craftsman_id = auth.uid() AND
  status = 'pending'
);

-- Permet aux propriétaires de voir les offres sur leurs projets
CREATE POLICY "Homeowners can view bids on their projects" 
ON project_bids
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM projects p 
    WHERE p.id = project_id AND p.homeowner_id = auth.uid()
  ) OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux métreurs de voir toutes les offres
CREATE POLICY "Estimators can view all bids" 
ON project_bids
FOR SELECT 
USING (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'estimator') OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux métreurs d'approuver des projets
CREATE POLICY "Estimators can approve projects" 
ON projects
FOR UPDATE 
USING (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'estimator') AND
  (status = 'pending' OR status = 'estimated')
);

-- Permet aux propriétaires d'accepter des offres sur leurs projets
CREATE POLICY "Homeowners can accept bids on their projects" 
ON project_bids
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM projects p 
    WHERE p.id = project_id AND p.homeowner_id = auth.uid()
  )
);
