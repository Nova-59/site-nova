
-- Politique permettant aux administrateurs de mettre à jour n'importe quel profil
CREATE POLICY "Administrators can update any profile" 
ON profiles 
FOR UPDATE 
USING (
  (auth.uid() = id) OR 
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);
