
-- Politiques pour les métreurs (estimators)
-- Permet aux métreurs de voir tous les projets
CREATE POLICY "Estimators can view all projects" 
ON projects
FOR SELECT 
USING (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'estimator') OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux métreurs de mettre à jour les estimations de projets
CREATE POLICY "Estimators can update project estimates" 
ON projects
FOR UPDATE 
USING (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'estimator') OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Politiques pour les artisans
-- Permet aux artisans de voir les projets disponibles 
CREATE POLICY "Craftsmen can view available projects" 
ON projects
FOR SELECT 
USING (
  (status = 'published' AND
   ((SELECT role FROM profiles WHERE id = auth.uid()) = 'craftsman')) OR
  (craftsman_id = auth.uid()) OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux artisans de soumissionner sur les projets
CREATE POLICY "Craftsmen can bid on projects" 
ON project_bids
FOR INSERT 
WITH CHECK (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'craftsman') AND
  auth.uid() = craftsman_id
);

-- Politiques pour les particuliers
-- Permet aux particuliers de voir leurs propres projets
CREATE POLICY "Homeowners can view their own projects" 
ON projects
FOR SELECT 
USING (
  homeowner_id = auth.uid() OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Permet aux particuliers de créer des projets
CREATE POLICY "Homeowners can create projects" 
ON projects
FOR INSERT 
WITH CHECK (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'homeowner') AND
  auth.uid() = homeowner_id
);

-- Permet aux particuliers de mettre à jour leurs propres projets
CREATE POLICY "Homeowners can update their own projects" 
ON projects
FOR UPDATE 
USING (
  homeowner_id = auth.uid() OR
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'admin')
);

-- Politique pour les invités
-- Permet aux invités de créer un projet (soumission uniquement)
CREATE POLICY "Guests can submit projects" 
ON projects
FOR INSERT 
WITH CHECK (
  ((SELECT role FROM profiles WHERE id = auth.uid()) = 'guest') AND
  auth.uid() = homeowner_id
);
